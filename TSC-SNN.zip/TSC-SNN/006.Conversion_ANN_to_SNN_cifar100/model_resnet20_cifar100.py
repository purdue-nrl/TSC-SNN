
import torch
import torch.nn as nn
import math

# Poisson spike generator
#   This module generates spike based on assumption that input is between 1 and -1
#   Positive spike is generated (i.e. 1 is return) if rand()<abs(input) and sign(input)=1
#   Negative spike is generated (i.e. -1 is return) if rand()<abs(input) and sign(input)=-1
#   This method is corresponding to Method 1 on Page 5 of lecture note http://www.cns.nyu.edu/~david/handouts/poisson.pdf
class PoissonGen(nn.Module):
    def __init__(self):
        super(PoissonGen, self).__init__()
    def forward(self, inp, t, N, en_IN):
        # nbits = 32
        # inp_disc= torch.round(inp*(2^nbits-1))/(2^nbits-1)
        if en_IN:
            op=1.0
        else:
            op=0.0
        # return op*torch.mul(torch.le(torch.rand_like(inp), torch.abs(inp_disc)).float(), torch.sign(inp))
        return op*torch.mul(torch.le(torch.rand_like(inp), torch.abs(inp)).float(), torch.sign(inp))


# Temporal spikes generator
class TemporalGen(nn.Module):
    def __init__(self):
        super(TemporalGen, self).__init__()
    def forward(self, inp, t, N, en_IN):
        
        if en_IN:
            op=1.0
        else:
            op=0.0

        outp = op * torch.mul(torch.le(inp*0+t,(N+0.5)*torch.abs(inp)).float(), torch.sign(inp))
        return outp


# Integrate-and-fire neuron (IFNeuron)
#   This module is slightly from IFNeuron module in the script that I have sent to Gopal and Priya earlier.
#   This module models simple IFNeuron without any refractory period
#   This modeule does not have state information, thus allowing it to be parallelized across GPUs when torch.nn.DataParallel is wrapped around
#   As a result, this module takes two arguments: input and previous IFNeuron membrane potential
#   Spike is generated if IFNeuron membrane potential reachs defined threshold
#   Spike output is return with new IFNeuron membrane potential
class IFNeuron(nn.Module):
    # Argument inplace does not have any use. You can ignore it. 
    def __init__(self, inplace=True, thres=1.0):
        super(IFNeuron, self).__init__()
        self.thres = thres
    def forward(self, inp, mem_potential, IF_spiking, IF_residual):
        mem_potential += inp
	outp = mem_potential*0.0
	if IF_spiking:
	    outp = torch.ge(mem_potential, self.thres)
            if IF_residual:
                mem_potential[outp] = (mem_potential[outp] - self.thres)*1.0  # Residual-IF neuron
            else:
                mem_potential[outp] = (mem_potential[outp] - self.thres)*0.0  # IF neuron
        return outp.float(), mem_potential 
    def set_thres(self, thres):
        self.thres = thres
    def get_thres(self):
        return self.thres
    def extra_repr(self):
        return 'thres={}'.format(self.thres)

# Identity module
#   This module returns whatever it recieves
class Identity(nn.Module):
    def __init__(self):
        super(Identity, self).__init__()
    def forward(self, inp):
        return inp

# Following are dummy modules
#   Those modules do not have any function
class DelayMark(nn.Module):
    def __init__(self):
        super(DelayMark, self).__init__()
class ResidueMark(nn.Module):
    def __init__(self):
        super(ResidueMark, self).__init__()
class MergeMark0(nn.Module):
    def __init__(self):
        super(MergeMark0, self).__init__()
class MergeMark1(nn.Module):
    def __init__(self):
        super(MergeMark1, self).__init__()

# Basic block in ResNet-20
class BasicBlock1(nn.Module):
    def __init__(self, in_channels, out_channels, stride, dropout_prob):
        super(BasicBlock1, self).__init__()
        # Construct delay path
        self.delay_path = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=(3,3), stride=(stride,stride), padding=(1,1), bias=False),
            nn.ReLU(),
            nn.Dropout(p=dropout_prob),
            nn.Conv2d(out_channels, out_channels, kernel_size=(3,3), stride=(1,1), padding=(1,1), bias=False)
        )
        # Construt residue path
        self.residual_path = Identity()
        self.relu = nn.ReLU(inplace=True)
    def forward(self, inp):
        # Output of basic block is sum of value from residue path and delay path
        outp = self.delay_path(inp)
        outp += self.residual_path(inp)
        outp = self.relu(outp)
        return outp

class BasicBlock0(nn.Module):
    def __init__(self, in_channels, out_channels, stride, dropout_prob):
        super(BasicBlock0, self).__init__()
        # Construct delay path
        self.delay_path = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=(3,3), stride=(stride,stride), padding=(1,1), bias=False),
            nn.ReLU(),
            nn.Dropout(p=dropout_prob),
            nn.Conv2d(out_channels, out_channels, kernel_size=(3,3), stride=(1,1), padding=(1,1), bias=False)
        )
        # Construt residue path
        self.residual_path = nn.AvgPool2d(kernel_size=(1,1), stride=(stride,stride), padding=(0,0))
        self.relu = nn.ReLU(inplace=True)
        self.pad_channels = out_channels - in_channels
    def forward(self, inp):
        # Output of basic block is sum of value from residue path and delay path
        outp = self.delay_path(inp)
        outp_res = self.delay_path(inp)
        outp += torch.cat((self.residual_path(inp),torch.zeros(inp.size(0), self.pad_channels, outp.size(2), outp.size(3)).cuda()), 1)
        outp = self.relu(outp)
        return outp

# Make basic block in specially for spiking ResNet
#   forward path of ResNet will be automatically generated with script in __main__ 
def make_basic_block(is_spike, in_channels, out_channels, stride, dropout_prob):
    if is_spike:
        delay_path = [nn.Conv2d(in_channels, out_channels, kernel_size=(3,3), stride=(stride,stride), padding=(1,1), bias=False),
                      IFNeuron(inplace=True),
                      nn.Dropout(p=dropout_prob),
                      nn.Conv2d(out_channels, out_channels, kernel_size=(3,3), stride=(1,1), padding=(1,1), bias=False)]
        if in_channels == out_channels:
            residual_path = [Identity()]
            return [ResidueMark()] + delay_path + [DelayMark()] + residual_path + [MergeMark1()] + [IFNeuron(inplace=True)]
        else:
            residual_path = [nn.AvgPool2d(kernel_size=(1,1), stride=(stride,stride), padding=(0,0))]
            return [ResidueMark()] + delay_path + [DelayMark()] + residual_path + [MergeMark0()] + [IFNeuron(inplace=True)]
    else:
        if in_channels == out_channels:
            return [BasicBlock1(in_channels, out_channels, stride, dropout_prob)]
        else:
            return [BasicBlock0(in_channels, out_channels, stride, dropout_prob)]

# Function to create convolutional layer
#   When is_spike=False, this function creates convolutional layer for rate-based ResNet
#   When is_spike=True, this function creates convolutional layer for spiking ResNet
def make_features(is_spike, is_temp, dropout_prob_list):
    list_m = []
    in_channels = 3
    if is_spike:
        if is_temp:
            list_m.append(TemporalGen())
        else:
            list_m.append(PoissonGen())
        act_func = IFNeuron
    else:
        act_func = nn.ReLU

    list_m += [nn.Conv2d(in_channels, 128, kernel_size=(3,3), stride=(1,1), padding=(1,1), bias=False)]
    list_m += [act_func(inplace=True)]
    list_m += [nn.Dropout(p=dropout_prob_list[0])]
    list_m += [nn.Conv2d(128, 128, kernel_size=(3,3), stride=(1,1), padding=(1,1), bias=False)]
    list_m += [act_func(inplace=True)]
    list_m += [nn.Dropout(p=dropout_prob_list[1])]
    list_m += [nn.Conv2d(128, 128, kernel_size=(3,3), stride=(1,1), padding=(1,1), bias=False)]
    list_m += [act_func(inplace=True)]
    list_m += [nn.Dropout(p=dropout_prob_list[2])]
    in_channels = 128

    for out_channels,strides in zip([128, 256, 512],[1, 2, 2]):
        strides = [strides] + [1]*2
        for j,stride in zip(range(3),strides):
            list_m.extend(make_basic_block(is_spike, in_channels, out_channels, stride, dropout_prob_list[3]))
            in_channels = out_channels
    list_m += [nn.AvgPool2d(kernel_size=(8,8), stride=(1,1))]
    return make_hierarchy(list_m,is_spike)

# Make fully connected layer 
#   When is_spike=False, this function creates fully-connected layer for rate-based ResNet network
#   When is_spike=True, this function creates fully-connected layer for spiking ResNet network 
def make_classifier(is_spike):
    list_m = []
    list_m += [nn.Linear(512, 100, bias=False)]
    return make_hierarchy(list_m,is_spike)

# Convert list of modules into torch.nn.ModuleList or torch.nn.Sequentual
#   For spiking simulation, we prefer modules to be stacked in torch.nn.ModuleList because output of modules are accessed at multiple points
#   During threshold balancing, we, for example, need to get maximum input to a particular IFNeuron. Having module in torch.nn.Sequential does allow us to access intermediate values easily 
def make_hierarchy(list_m,is_spike):
    if is_spike:
        return nn.ModuleList(list_m)
    else:
        return nn.Sequential(*list_m)

# Spiking version of simple network
class ResNetSpike(nn.Module):
    def __init__(self, dt=0.001, t_end=2.000, in_coding='temp', snn_mode='snn', if_mode='if', TTS=256, fpi=128, dropout_prob_list=[0.1,0.1,0.1,0.1]):
        super(ResNetSpike, self).__init__()
        # Save network parameters
        self.dt = dt
        self.t_end = t_end
        self.TTS = TTS
        self.fpi = fpi+1
        self.in_coding = in_coding
        self.snn_mode = snn_mode
        self.if_mode = if_mode

        if self.if_mode == 'residual':
            self.is_residual = True
        elif self.if_mode == 'if':
            self.is_residual = False

        if self.in_coding == 'temp':
            is_temp = True
        elif self.in_coding == 'rate':
            is_temp = False

        # Instantiate layers
        self.features = make_features(is_spike=True, is_temp=is_temp, dropout_prob_list=dropout_prob_list)
        self.classifier = make_classifier(is_spike=True)
    def forward(self, inp):
        # Code in this forward function is automatically generated by running this script
        #   $ python model_resnet20_cifar10.py
        # XX_mem_potential stores membrane potential of IFNeuron at layer XX
        # XX_max_inp stores maximum input to IFNeuon at layer XX 
        outp_sum = torch.zeros(inp.size(0),100).cuda()

        l2_mem_potential = torch.zeros(inp.size(0),128,32,32).cuda()
        l2_max_inp = torch.zeros(inp.size(0),1).cuda()
        l2_pre_inp = torch.zeros(inp.size(0),128,32,32).cuda()
        l3_pre_inp = torch.zeros(inp.size(0),128,32,32).cuda()

        l5_mem_potential = torch.zeros(inp.size(0),128,32,32).cuda()
        l5_max_inp = torch.zeros(inp.size(0),1).cuda()
        l5_pre_inp = torch.zeros(inp.size(0),128,32,32).cuda()
        l6_pre_inp = torch.zeros(inp.size(0),128,32,32).cuda()

        l8_mem_potential = torch.zeros(inp.size(0),128,32,32).cuda()
        l8_max_inp = torch.zeros(inp.size(0),1).cuda()
        l8_pre_inp = torch.zeros(inp.size(0),128,32,32).cuda()
        l9_pre_inp = torch.zeros(inp.size(0),128,32,32).cuda()

        l12_mem_potential = torch.zeros(inp.size(0),128,32,32).cuda()
        l12_pre_inp = torch.zeros(inp.size(0),128,32,32).cuda()
        l13_pre_inp = torch.zeros(inp.size(0),128,32,32).cuda()

        l18_mem_potential = torch.zeros(inp.size(0),128,32,32).cuda()
        l18_pre_inp = torch.zeros(inp.size(0),128,32,32).cuda()
        l20_pre_inp = torch.zeros(inp.size(0),128,32,32).cuda()

        l21_mem_potential = torch.zeros(inp.size(0),128,32,32).cuda()
        l21_pre_inp = torch.zeros(inp.size(0),128,32,32).cuda()
        l22_pre_inp = torch.zeros(inp.size(0),128,32,32).cuda()

        l27_mem_potential = torch.zeros(inp.size(0),128,32,32).cuda()
        l27_pre_inp = torch.zeros(inp.size(0),128,32,32).cuda()
        l29_pre_inp = torch.zeros(inp.size(0),128,32,32).cuda()

        l30_mem_potential = torch.zeros(inp.size(0),128,32,32).cuda()
        l30_pre_inp = torch.zeros(inp.size(0),128,32,32).cuda()
        l31_pre_inp = torch.zeros(inp.size(0),128,32,32).cuda()

        l36_mem_potential = torch.zeros(inp.size(0),128,32,32).cuda()
        l36_pre_inp = torch.zeros(inp.size(0),128,32,32).cuda()
        l38_pre_inp = torch.zeros(inp.size(0),128,32,32).cuda()

        l39_mem_potential = torch.zeros(inp.size(0),256,16,16).cuda()
        l39_pre_inp = torch.zeros(inp.size(0),256,16,16).cuda()
        l40_pre_inp = torch.zeros(inp.size(0),256,16,16).cuda()

        l45_mem_potential = torch.zeros(inp.size(0),256,16,16).cuda()
        l45_pre_inp = torch.zeros(inp.size(0),256,16,16).cuda()
        l47_pre_inp = torch.zeros(inp.size(0),256,16,16).cuda()

        l48_mem_potential = torch.zeros(inp.size(0),256,16,16).cuda()
        l48_pre_inp = torch.zeros(inp.size(0),256,16,16).cuda()
        l49_pre_inp = torch.zeros(inp.size(0),256,16,16).cuda()

        l54_mem_potential = torch.zeros(inp.size(0),256,16,16).cuda()
        l54_pre_inp = torch.zeros(inp.size(0),256,16,16).cuda()
        l56_pre_inp = torch.zeros(inp.size(0),256,16,16).cuda()

        l57_mem_potential = torch.zeros(inp.size(0),256,16,16).cuda()
        l57_pre_inp = torch.zeros(inp.size(0),256,16,16).cuda()
        l58_pre_inp = torch.zeros(inp.size(0),256,16,16).cuda()

        l63_mem_potential = torch.zeros(inp.size(0),256,16,16).cuda()
        l63_pre_inp = torch.zeros(inp.size(0),256,16,16).cuda()
        l65_pre_inp = torch.zeros(inp.size(0),256,16,16).cuda()

        l66_mem_potential = torch.zeros(inp.size(0),512,8,8).cuda()
        l66_pre_inp = torch.zeros(inp.size(0),512,8,8).cuda()
        l67_pre_inp = torch.zeros(inp.size(0),512,8,8).cuda()

        l72_mem_potential = torch.zeros(inp.size(0),512,8,8).cuda()
        l72_pre_inp = torch.zeros(inp.size(0),512,8,8).cuda()
        l74_pre_inp = torch.zeros(inp.size(0),512,8,8).cuda()

        l75_mem_potential = torch.zeros(inp.size(0),512,8,8).cuda()
        l75_pre_inp = torch.zeros(inp.size(0),512,8,8).cuda()
        l76_pre_inp = torch.zeros(inp.size(0),512,8,8).cuda()

        l81_mem_potential = torch.zeros(inp.size(0),512,8,8).cuda()
        l81_pre_inp = torch.zeros(inp.size(0),512,8,8).cuda()
        l83_pre_inp = torch.zeros(inp.size(0),512,8,8).cuda()

        l84_mem_potential = torch.zeros(inp.size(0),512,8,8).cuda()
        l84_pre_inp = torch.zeros(inp.size(0),512,8,8).cuda()
        l85_pre_inp = torch.zeros(inp.size(0),512,8,8).cuda()

        l90_mem_potential = torch.zeros(inp.size(0),512,8,8).cuda()
        l90_pre_inp = torch.zeros(inp.size(0),512,8,8).cuda()
        l91_pre_inp = torch.zeros(inp.size(0),512,8,8).cuda()

        classifier_pre_inp = torch.zeros(inp.size(0),512,1,1).cuda()

        spike_count = torch.zeros(1,200).cuda()
        # Simulating spiking network over time inside the module, thus allow simulation to be parallelized across GPUs when torch.nn.DataParallel is wrapped around
        
        count = torch.zeros(1).cuda()

        self.en_IN = True
        self.en_IF = True
        l2_on = True
        l5_on = True
        l8_on = True

        l18_on = True
        l27_on = True
        l36_on = True
        
        l45_on = True
        l54_on = True
        l63_on = True

        l72_on = True
        l81_on = True
        l90_on = True


        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            # generate delta-frame inputs to synapse of layer 1
            if count == 1:
                outp = self.features[0](inp, count, self.fpi, self.en_IN) # spike-input
            else:
                outp = self.features[0](inp, count, self.fpi, self.en_IN) - self.features[0](inp, count-1, self.fpi, self.en_IN)
            spike_count[0,101] += torch.sum(torch.abs(outp))
            spike_count[0,1] += torch.sum(torch.abs(self.features[0](inp, count, self.fpi, self.en_IN)))
            # print(count, spike_count[0,101], spike_count[0,1])
            outp = self.features[1](outp) # synapse
            # reconstruct spiking neuron full-frame inputs to layer 2
            if count == 1:
                l2_pre_inp = outp
            else:
                outp += l2_pre_inp
                l2_pre_inp = outp
            l2_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l2_max_inp)
            outp,l2_mem_potential = self.features[2](outp,l2_mem_potential, False, self.is_residual)
            # print('        layer 2, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l2_mem_potential), torch.min(l2_mem_potential), l2_mem_potential.shape))
            spike_count[0,2] += torch.sum(outp)

         
        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp = 0*l2_mem_potential
            outp,l2_mem_potential = self.features[2](outp,l2_mem_potential, True, self.is_residual)
            # print('        layer 2, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l2_mem_potential), torch.min(l2_mem_potential), l2_mem_potential.shape))
            spike_count[0,2] += torch.sum(torch.abs(outp))
            # generate delta-frame inputs to synapse of layer 4 
            if count == 1:
                l3_pre_inp = outp
            else:
                outp = outp - l3_pre_inp
                l3_pre_inp = l3_pre_inp + outp
            spike_count[0,102] += torch.sum(torch.abs(outp))
            outp = self.features[3](outp) # dropout
            outp = self.features[4](outp) # synapse
            # reconstruct spiking neuron full-frame inputs to layer 5
            if count == 1:
                l5_pre_inp = outp
            else:
                outp += l5_pre_inp
                l5_pre_inp = outp
            l5_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l5_max_inp)
            outp,l5_mem_potential = self.features[5](outp,l5_mem_potential, False, self.is_residual)
            # print('        layer 5, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l5_mem_potential), torch.min(l5_mem_potential), l5_mem_potential.shape))
            spike_count[0,5] += torch.sum(outp)


        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp = 0*l5_mem_potential
            outp,l5_mem_potential = self.features[5](outp,l5_mem_potential, True, self.is_residual)
            # print('        layer 5, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l5_mem_potential), torch.min(l5_mem_potential), l5_mem_potential.shape))
            spike_count[0,5] += torch.sum(torch.abs(outp))
            # generate delta-frame inputs to synapse of layer 7      
            if count == 1:
                l6_pre_inp = outp
            else:
                outp = outp - l6_pre_inp
                l6_pre_inp = l6_pre_inp + outp
            spike_count[0,105] += torch.sum(torch.abs(outp))
            outp = self.features[6](outp) # pooling
            outp = self.features[7](outp) # synapse
            # reconstruct spiking neuron full-frame inputs to layer 8
            if count == 1:
                l8_pre_inp = outp
            else:
                outp += l8_pre_inp
                l8_pre_inp = outp
            l8_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l8_max_inp)
            outp,l8_mem_potential = self.features[8](outp,l8_mem_potential, False, self.is_residual)
            # print('        layer 8, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l8_mem_potential), torch.min(l8_mem_potential), l8_mem_potential.shape))
            spike_count[0,8] += torch.sum(outp)
        
        #++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++#
        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp = 0*l8_mem_potential
            outp,l8_mem_potential = self.features[8](outp,l8_mem_potential, True, self.is_residual)
            # print('        layer 8, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l8_mem_potential), torch.min(l8_mem_potential), l8_mem_potential.shape))
            spike_count[0,8] += torch.sum(outp)
            # generate delta-frame inputs to synapse of layer 11
            if count == 1:
                l9_pre_inp = outp
            else:
                outp = outp - l9_pre_inp
                l9_pre_inp = l9_pre_inp + outp
            spike_count[0,108] += torch.sum(torch.abs(outp))
            outp = self.features[9](outp)      # dropout
            outp_r = self.features[11](outp)   # synapse  <-------
            # reconstruct spiking neuron full-frame inputs to layer 12
            if count == 1:
                l12_pre_inp = outp_r
            else:
                outp_r += l12_pre_inp
                l12_pre_inp = outp_r
            outp_r,l12_mem_potential = self.features[12](outp_r,l12_mem_potential, False, self.is_residual)
            # print('        layer 12, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l12_mem_potential), torch.min(l12_mem_potential), l12_mem_potential.shape))
            spike_count[0,12] += torch.sum(outp_r)
            outp_d = self.features[16](outp)   # identity <-------
            # reconstruct spiking neuron full-frame inputs to layer 18
            if count == 1:
                l18_pre_inp = outp_d
            else:
                outp_d += l18_pre_inp
                l18_pre_inp = outp_d
            outp_d,l18_mem_potential = self.features[18](outp_d,l18_mem_potential, False, self.is_residual)
            # print('        layer 18, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l18_mem_potential), torch.min(l18_mem_potential), l18_mem_potential.shape))

        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp_r = 0*l12_mem_potential
            outp_r,l12_mem_potential = self.features[12](outp_r,l12_mem_potential, True, self.is_residual)
            # print('        layer 12, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l12_mem_potential), torch.min(l12_mem_potential), l12_mem_potential.shape))
            spike_count[0,12] += torch.sum(outp_r)
             # generate delta-frame inputs to synapse of layer 13
            if count == 1:
                l13_pre_inp = outp_r
            else:
                outp_r = outp_r - l13_pre_inp
                l13_pre_inp = l13_pre_inp + outp_r
            spike_count[0,112] += torch.sum(torch.abs(outp_r))
            outp_r = self.features[13](outp_r) # dropout
            outp_r = self.features[14](outp_r) # synapse  <-------
             # reconstruct spiking neuron full-frame inputs to layer 18
            if count == 1:
                l18_pre_inp = outp_r
            else:
                outp_r += l18_pre_inp
                l18_pre_inp = outp_r
            outp_r,l18_mem_potential = self.features[18](outp_r,l18_mem_potential, False, self.is_residual)
            spike_count[0,18] += torch.sum(outp_r)


            # outp_r = self.features[11](outp)   # <-------
            # outp_r,l12_mem_potential = self.features[12](outp_r,l12_mem_potential, self.en_IF, self.is_residual)
            # spike_count[0,12] += torch.sum(outp_r)
            # outp_r = self.features[14](self.features[13](outp_r))
            # outp_d = self.features[16](outp)   # <-------
            # outp = torch.add(outp_d, outp_r)   # ------->
            # outp,l18_mem_potential = self.features[18](outp,l18_mem_potential, True, self.is_residual)
            # spike_count[0,18] += torch.sum(outp)

        #++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++#
        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp_r = 0*l18_mem_potential
            outp,l18_mem_potential = self.features[18](outp_r,l18_mem_potential, True, self.is_residual)
            spike_count[0,18] += torch.sum(outp)
            # print(spike_count[0,18])
            # print('        layer 18, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l18_mem_potential), torch.min(l18_mem_potential), l18_mem_potential.shape))
            # generate delta-frame inputs to synapse of layer 20
            if count == 1:
                l20_pre_inp = outp
            else:
                outp = outp - l20_pre_inp
                l20_pre_inp = l20_pre_inp + outp
            spike_count[0,118] += torch.sum(torch.abs(outp))
            # print(spike_count[0,118])
            outp_r = self.features[20](outp)   # synapse  <-------
            # reconstruct spiking neuron full-frame inputs to layer 21
            if count == 1:
                l21_pre_inp = outp_r
            else:
                outp_r += l21_pre_inp
                l21_pre_inp = outp_r
            outp_r,l21_mem_potential = self.features[21](outp_r,l21_mem_potential, False, self.is_residual)
            # print('        layer 21, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l21_mem_potential), torch.min(l21_mem_potential), l21_mem_potential.shape))
            spike_count[0,21] += torch.sum(outp_r)
            outp_d = self.features[25](outp)   # identity <-------
            # reconstruct spiking neuron full-frame inputs to layer 27
            if count == 1:
                l27_pre_inp = outp_d
            else:
                outp_d += l27_pre_inp
                l27_pre_inp = outp_d
            outp_d,l27_mem_potential = self.features[27](outp_d,l27_mem_potential, False, self.is_residual)
            # print('        layer 27, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l27_mem_potential), torch.min(l27_mem_potential), l27_mem_potential.shape))

        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp_r = 0*l21_mem_potential
            outp_r,l21_mem_potential = self.features[21](outp_r,l21_mem_potential, True, self.is_residual)
            # print('        layer 21, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l21_mem_potential), torch.min(l21_mem_potential), l21_mem_potential.shape))
            spike_count[0,21] += torch.sum(outp_r)
             # generate delta-frame inputs to synapse of layer 22
            if count == 1:
                l22_pre_inp = outp_r
            else:
                outp_r = outp_r - l22_pre_inp
                l22_pre_inp = l22_pre_inp + outp_r
            spike_count[0,121] += torch.sum(torch.abs(outp_r))
            outp_r = self.features[22](outp_r) # dropout
            outp_r = self.features[23](outp_r) # synapse  <-------
             # reconstruct spiking neuron full-frame inputs to layer 27
            if count == 1:
                l27_pre_inp = outp_r
            else:
                outp_r += l27_pre_inp
                l27_pre_inp = outp_r
            outp_r,l27_mem_potential = self.features[27](outp_r,l27_mem_potential, False, self.is_residual)
            # print('        layer 27, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l27_mem_potential), torch.min(l27_mem_potential), l27_mem_potential.shape))
            spike_count[0,27] += torch.sum(outp_r)        

            # outp_r = self.features[20](outp)  # <-------
            # outp_r,l21_mem_potential = self.features[21](outp_r,l21_mem_potential, self.en_IF, self.is_residual)
            # spike_count[0,21] += torch.sum(outp_r)
            # outp_r = self.features[23](self.features[22](outp_r))
            # outp_d = self.features[25](outp)  # <-------
            # outp = torch.add(outp_d, outp_r)  # ------->
            # outp,l27_mem_potential = self.features[27](outp,l27_mem_potential, True, self.is_residual)
            # spike_count[0,27] += torch.sum(outp)

        #++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++#
        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp_r = 0*l27_mem_potential
            outp,l27_mem_potential = self.features[27](outp_r,l27_mem_potential, True, self.is_residual)
            spike_count[0,27] += torch.sum(outp)
            # print('        layer 27, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l27_mem_potential), torch.min(l27_mem_potential), l27_mem_potential.shape))
            # generate delta-frame inputs to synapse of layer 29
            if count == 1:
                l29_pre_inp = outp
            else:
                outp = outp - l29_pre_inp
                l29_pre_inp = l29_pre_inp + outp
            spike_count[0,127] += torch.sum(torch.abs(outp))
            outp_r = self.features[29](outp)   # synapse  <-------
            # reconstruct spiking neuron full-frame inputs to layer 30
            if count == 1:
                l30_pre_inp = outp_r
            else:
                outp_r += l30_pre_inp
                l30_pre_inp = outp_r
            outp_r,l30_mem_potential = self.features[30](outp_r,l30_mem_potential, False, self.is_residual)
            # print('        layer 30, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l30_mem_potential), torch.min(l30_mem_potential), l30_mem_potential.shape))
            spike_count[0,30] += torch.sum(outp_r)
            outp_d = self.features[34](outp)   # identity <-------
            # reconstruct spiking neuron full-frame inputs to layer 36
            if count == 1:
                l36_pre_inp = outp_d
            else:
                outp_d += l36_pre_inp
                l36_pre_inp = outp_d
            outp_d,l36_mem_potential = self.features[36](outp_d,l36_mem_potential, False, self.is_residual)
            # print('        layer 36, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l36_mem_potential), torch.min(l36_mem_potential), l36_mem_potential.shape))

        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp_r = 0*l30_mem_potential
            outp_r,l30_mem_potential = self.features[30](outp_r,l30_mem_potential, True, self.is_residual)
            # print('        layer 30, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l30_mem_potential), torch.min(l30_mem_potential), l30_mem_potential.shape))
            spike_count[0,30] += torch.sum(outp_r)
             # generate delta-frame inputs to synapse of layer 31
            if count == 1:
                l31_pre_inp = outp_r
            else:
                outp_r = outp_r - l31_pre_inp
                l31_pre_inp = l31_pre_inp + outp_r
            spike_count[0,130] += torch.sum(torch.abs(outp_r))
            outp_r = self.features[31](outp_r) # dropout
            outp_r = self.features[32](outp_r) # synapse  <-------
             # reconstruct spiking neuron full-frame inputs to layer 36
            if count == 1:
                l36_pre_inp = outp_r
            else:
                outp_r += l36_pre_inp
                l36_pre_inp = outp_r
            outp_r,l36_mem_potential = self.features[36](outp_r,l36_mem_potential, False, self.is_residual)
            # print('        layer 36, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l36_mem_potential), torch.min(l36_mem_potential), l36_mem_potential.shape))
            spike_count[0,36] += torch.sum(outp_r)


            # outp_r = self.features[29](outp)  # <-------
            # outp_r,l30_mem_potential = self.features[30](outp_r,l30_mem_potential, self.en_IF, self.is_residual)
            # spike_count[0,30] += torch.sum(outp_r)
            # outp_r = self.features[32](self.features[31](outp_r))
            # outp_d = self.features[34](outp)  # <-------
            # outp = torch.add(outp_d, outp_r)  # ------->
            # outp,l36_mem_potential = self.features[36](outp,l36_mem_potential, True, self.is_residual)
            # spike_count[0,36] += torch.sum(outp)
            # if torch.sum(outp) == 0 and l36_on == True and ts > self.fpi:
            #     print('     layer 36 is turned off at timestep: {}'.format(ts))
            #     l36_on = False

        #++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++#
        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp_r = 0*l36_mem_potential
            outp,l36_mem_potential = self.features[36](outp_r,l36_mem_potential, True, self.is_residual)
            spike_count[0,36] += torch.sum(outp)
            # print('        layer 36, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l36_mem_potential), torch.min(l36_mem_potential), l36_mem_potential.shape))
            # generate delta-frame inputs to synapse of layer 38
            if count == 1:
                l38_pre_inp = outp
            else:
                outp = outp - l38_pre_inp
                l38_pre_inp = l38_pre_inp + outp
            spike_count[0,136] += torch.sum(torch.abs(outp))
            outp_r = self.features[38](outp)   # synapse  <-------
            # reconstruct spiking neuron full-frame inputs to layer 39
            if count == 1:
                l39_pre_inp = outp_r
            else:
                outp_r += l39_pre_inp
                l39_pre_inp = outp_r
            outp_r,l39_mem_potential = self.features[39](outp_r,l39_mem_potential, False, self.is_residual)
            # print('        layer 39, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l39_mem_potential), torch.min(l39_mem_potential), l39_mem_potential.shape))
            spike_count[0,39] += torch.sum(outp_r)
            outp_d = torch.cat((self.features[43](outp),torch.zeros(outp_r.size(0),128,outp_r.size(2),outp_r.size(3)).cuda()),1) # identity <-------
            # reconstruct spiking neuron full-frame inputs to layer 45
            if count == 1:
                l45_pre_inp = outp_d
            else:
                outp_d += l45_pre_inp
                l45_pre_inp = outp_d
            outp_d,l45_mem_potential = self.features[45](outp_d,l45_mem_potential, False, self.is_residual)
            # print('        layer 45, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l45_mem_potential), torch.min(l45_mem_potential), l45_mem_potential.shape))

        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp_r = 0*l39_mem_potential
            outp_r,l39_mem_potential = self.features[39](outp_r,l39_mem_potential, True, self.is_residual)
            # print('        layer 39, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l39_mem_potential), torch.min(l39_mem_potential), l39_mem_potential.shape))
            spike_count[0,39] += torch.sum(outp_r)
             # generate delta-frame inputs to synapse of layer 40
            if count == 1:
                l40_pre_inp = outp_r
            else:
                outp_r = outp_r - l40_pre_inp
                l40_pre_inp = l40_pre_inp + outp_r
            spike_count[0,139] += torch.sum(torch.abs(outp_r))
            outp_r = self.features[40](outp_r) # dropout
            outp_r = self.features[41](outp_r) # synapse  <-------
             # reconstruct spiking neuron full-frame inputs to layer 45
            if count == 1:
                l45_pre_inp = outp_r
            else:
                outp_r += l45_pre_inp
                l45_pre_inp = outp_r
            outp_r,l45_mem_potential = self.features[45](outp_r,l45_mem_potential, False, self.is_residual)
            # print('        layer 45, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l45_mem_potential), torch.min(l45_mem_potential), l45_mem_potential.shape))
            spike_count[0,45] += torch.sum(outp_r)


            # outp_r = self.features[38](outp)
            # outp_r,l39_mem_potential = self.features[39](outp_r,l39_mem_potential, self.en_IF, self.is_residual)
            # spike_count[0,39] += torch.sum(outp_r)
            # outp_r = self.features[41](self.features[40](outp_r))
            # outp_d = torch.cat((self.features[43](outp),torch.zeros(outp_r.size(0),128,outp_r.size(2),outp_r.size(3)).cuda()),1)
            # outp = torch.add(outp_d, outp_r)
            # outp,l45_mem_potential = self.features[45](outp,l45_mem_potential, True, self.is_residual)
            # spike_count[0,45] += torch.sum(outp)

        #++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++#
        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp_r = 0*l45_mem_potential
            outp,l45_mem_potential = self.features[45](outp_r,l45_mem_potential, True, self.is_residual)
            spike_count[0,45] += torch.sum(outp)
            # print('        layer 45, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l45_mem_potential), torch.min(l45_mem_potential), l45_mem_potential.shape))
            # generate delta-frame inputs to synapse of layer 47
            if count == 1:
                l47_pre_inp = outp
            else:
                outp = outp - l47_pre_inp
                l47_pre_inp = l47_pre_inp + outp
            spike_count[0,145] += torch.sum(torch.abs(outp))
            outp_r = self.features[47](outp)   # synapse  <-------
            # reconstruct spiking neuron full-frame inputs to layer 48
            if count == 1:
                l48_pre_inp = outp_r
            else:
                outp_r += l48_pre_inp
                l48_pre_inp = outp_r
            outp_r,l48_mem_potential = self.features[48](outp_r,l48_mem_potential, False, self.is_residual)
            # print('        layer 48, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l48_mem_potential), torch.min(l48_mem_potential), l48_mem_potential.shape))
            spike_count[0,48] += torch.sum(outp_r)
            outp_d = self.features[52](outp)   # identity <-------
            # reconstruct spiking neuron full-frame inputs to layer 54
            if count == 1:
                l54_pre_inp = outp_d
            else:
                outp_d += l54_pre_inp
                l54_pre_inp = outp_d
            outp_d,l54_mem_potential = self.features[54](outp_d,l54_mem_potential, False, self.is_residual)
            # print('        layer 54, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l54_mem_potential), torch.min(l54_mem_potential), l54_mem_potential.shape))

        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp_r = 0*l48_mem_potential
            outp_r,l48_mem_potential = self.features[48](outp_r,l48_mem_potential, True, self.is_residual)
            # print('        layer 48, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l48_mem_potential), torch.min(l48_mem_potential), l48_mem_potential.shape))
            spike_count[0,48] += torch.sum(outp_r)
             # generate delta-frame inputs to synapse of layer 49
            if count == 1:
                l49_pre_inp = outp_r
            else:
                outp_r = outp_r - l49_pre_inp
                l49_pre_inp = l49_pre_inp + outp_r
            spike_count[0,148] += torch.sum(torch.abs(outp_r))
            outp_r = self.features[49](outp_r) # dropout
            outp_r = self.features[50](outp_r) # synapse  <-------
             # reconstruct spiking neuron full-frame inputs to layer 54
            if count == 1:
                l54_pre_inp = outp_r
            else:
                outp_r += l54_pre_inp
                l54_pre_inp = outp_r
            outp_r,l54_mem_potential = self.features[54](outp_r,l54_mem_potential, False, self.is_residual)
            # print('        layer 54, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l54_mem_potential), torch.min(l54_mem_potential), l54_mem_potential.shape))
            spike_count[0,54] += torch.sum(outp_r)


            # outp_r = self.features[47](outp)
            # outp_r,l48_mem_potential = self.features[48](outp_r,l48_mem_potential, self.en_IF, self.is_residual)
            # spike_count[0,48] += torch.sum(outp_r)
            # outp_r = self.features[50](self.features[49](outp_r))
            # outp_d = self.features[52](outp)
            # outp = torch.add(outp_d, outp_r)
            # outp,l54_mem_potential = self.features[54](outp,l54_mem_potential, True, self.is_residual)
            # spike_count[0,54] += torch.sum(outp)

        #++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++#
        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp_r = 0*l54_mem_potential
            outp,l54_mem_potential = self.features[54](outp_r,l54_mem_potential, True, self.is_residual)
            spike_count[0,54] += torch.sum(outp)
            # print('        layer 54, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l54_mem_potential), torch.min(l54_mem_potential), l54_mem_potential.shape))
            # generate delta-frame inputs to synapse of layer 56
            if count == 1:
                l56_pre_inp = outp
            else:
                outp = outp - l56_pre_inp
                l56_pre_inp = l56_pre_inp + outp
            spike_count[0,154] += torch.sum(torch.abs(outp))
            outp_r = self.features[56](outp)   # synapse  <-------
            # reconstruct spiking neuron full-frame inputs to layer 57
            if count == 1:
                l57_pre_inp = outp_r
            else:
                outp_r += l57_pre_inp
                l57_pre_inp = outp_r
            outp_r,l57_mem_potential = self.features[57](outp_r,l57_mem_potential, False, self.is_residual)
            # print('        layer 57, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l57_mem_potential), torch.min(l57_mem_potential), l57_mem_potential.shape))
            spike_count[0,57] += torch.sum(outp_r)
            outp_d = self.features[61](outp)   # identity <-------
            # reconstruct spiking neuron full-frame inputs to layer 63
            if count == 1:
                l63_pre_inp = outp_d
            else:
                outp_d += l63_pre_inp
                l63_pre_inp = outp_d
            outp_d,l63_mem_potential = self.features[63](outp_d,l63_mem_potential, False, self.is_residual)
            # print('        layer 63, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l63_mem_potential), torch.min(l63_mem_potential), l63_mem_potential.shape))

        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp_r = 0*l57_mem_potential
            outp_r,l57_mem_potential = self.features[57](outp_r,l57_mem_potential, True, self.is_residual)
            # print('        layer 57, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l57_mem_potential), torch.min(l57_mem_potential), l57_mem_potential.shape))
            spike_count[0,57] += torch.sum(outp_r)
             # generate delta-frame inputs to synapse of layer 58
            if count == 1:
                l58_pre_inp = outp_r
            else:
                outp_r = outp_r - l58_pre_inp
                l58_pre_inp = l58_pre_inp + outp_r
            spike_count[0,157] += torch.sum(torch.abs(outp_r))
            outp_r = self.features[58](outp_r) # dropout
            outp_r = self.features[59](outp_r) # synapse  <-------
             # reconstruct spiking neuron full-frame inputs to layer 63
            if count == 1:
                l63_pre_inp = outp_r
            else:
                outp_r += l63_pre_inp
                l63_pre_inp = outp_r
            outp_r,l63_mem_potential = self.features[63](outp_r,l63_mem_potential, False, self.is_residual)
            # print('        layer 63, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l63_mem_potential), torch.min(l63_mem_potential), l63_mem_potential.shape))
            spike_count[0,63] += torch.sum(outp_r)


            # outp_r = self.features[56](outp)
            # outp_r,l57_mem_potential = self.features[57](outp_r,l57_mem_potential, self.en_IF, self.is_residual)
            # spike_count[0,57] += torch.sum(outp_r)
            # outp_r = self.features[59](self.features[58](outp_r))
            # outp_d = self.features[61](outp)
            # outp = torch.add(outp_d, outp_r)
            # outp,l63_mem_potential = self.features[63](outp,l63_mem_potential, True, self.is_residual)
            # spike_count[0,63] += torch.sum(outp)
            # if torch.sum(outp) == 0 and l63_on == True and ts > self.fpi:
            #     print('     layer 63 is turned off at timestep: {}'.format(ts))
            #     l63_on = False

        #++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++#
        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp_r = 0*l63_mem_potential
            outp,l63_mem_potential = self.features[63](outp_r,l63_mem_potential, True, self.is_residual)
            spike_count[0,63] += torch.sum(outp)
            # print('        layer 63, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l63_mem_potential), torch.min(l63_mem_potential), l63_mem_potential.shape))
            # generate delta-frame inputs to synapse of layer 65
            if count == 1:
                l65_pre_inp = outp
            else:
                outp = outp - l65_pre_inp
                l65_pre_inp = l65_pre_inp + outp
            spike_count[0,163] += torch.sum(torch.abs(outp))
            outp_r = self.features[65](outp)   # synapse  <-------
            # reconstruct spiking neuron full-frame inputs to layer 66
            if count == 1:
                l66_pre_inp = outp_r
            else:
                outp_r += l66_pre_inp
                l66_pre_inp = outp_r
            outp_r,l66_mem_potential = self.features[66](outp_r,l66_mem_potential, False, self.is_residual)
            # print('        layer 66, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l66_mem_potential), torch.min(l66_mem_potential), l66_mem_potential.shape))
            spike_count[0,66] += torch.sum(outp_r)
            outp_d = torch.cat((self.features[70](outp),torch.zeros(outp_r.size(0),256,outp_r.size(2),outp_r.size(3)).cuda()),1) # identity <-------
            # reconstruct spiking neuron full-frame inputs to layer 72
            if count == 1:
                l72_pre_inp = outp_d
            else:
                outp_d += l72_pre_inp
                l72_pre_inp = outp_d
            outp_d,l72_mem_potential = self.features[72](outp_d,l72_mem_potential, False, self.is_residual)
            # print('        layer 72, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l72_mem_potential), torch.min(l72_mem_potential), l72_mem_potential.shape))

        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp_r = 0*l66_mem_potential
            outp_r,l66_mem_potential = self.features[66](outp_r,l66_mem_potential, True, self.is_residual)
            # print('        layer 66, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l66_mem_potential), torch.min(l66_mem_potential), l66_mem_potential.shape))
            spike_count[0,66] += torch.sum(outp_r)
             # generate delta-frame inputs to synapse of layer 67
            if count == 1:
                l67_pre_inp = outp_r
            else:
                outp_r = outp_r - l67_pre_inp
                l67_pre_inp = l67_pre_inp + outp_r
            spike_count[0,166] += torch.sum(torch.abs(outp_r))
            outp_r = self.features[67](outp_r) # dropout
            outp_r = self.features[68](outp_r) # synapse  <-------
             # reconstruct spiking neuron full-frame inputs to layer 72
            if count == 1:
                l72_pre_inp = outp_r
            else:
                outp_r += l72_pre_inp
                l72_pre_inp = outp_r
            outp_r,l72_mem_potential = self.features[72](outp_r,l72_mem_potential, False, self.is_residual)
            # print('        layer 72, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l72_mem_potential), torch.min(l72_mem_potential), l72_mem_potential.shape))
            spike_count[0,72] += torch.sum(outp_r)


            # outp_r = self.features[65](outp)
            # outp_r,l66_mem_potential = self.features[66](outp_r,l66_mem_potential, self.en_IF, self.is_residual)
            # spike_count[0,66] += torch.sum(outp_r)
            # outp_r = self.features[68](self.features[67](outp_r))
            # outp_d = torch.cat((self.features[70](outp),torch.zeros(outp_r.size(0),256,outp_r.size(2),outp_r.size(3)).cuda()),1)
            # outp = torch.add(outp_d, outp_r)
            # outp,l72_mem_potential = self.features[72](outp,l72_mem_potential, True, self.is_residual)
            # spike_count[0,72] += torch.sum(outp)

        #++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++#
        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp_r = 0*l72_mem_potential
            outp,l72_mem_potential = self.features[72](outp_r,l72_mem_potential, True, self.is_residual)
            spike_count[0,72] += torch.sum(outp)
            # print('        layer 72, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l72_mem_potential), torch.min(l72_mem_potential), l72_mem_potential.shape))
            # generate delta-frame inputs to synapse of layer 74
            if count == 1:
                l74_pre_inp = outp
            else:
                outp = outp - l74_pre_inp
                l74_pre_inp = l74_pre_inp + outp
            spike_count[0,172] += torch.sum(torch.abs(outp))
            outp_r = self.features[74](outp)   # synapse  <-------
            # reconstruct spiking neuron full-frame inputs to layer 75
            if count == 1:
                l75_pre_inp = outp_r
            else:
                outp_r += l75_pre_inp
                l75_pre_inp = outp_r
            outp_r,l75_mem_potential = self.features[75](outp_r,l75_mem_potential, False, self.is_residual)
            # print('        layer 75, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l75_mem_potential), torch.min(l75_mem_potential), l75_mem_potential.shape))
            spike_count[0,75] += torch.sum(outp_r)
            outp_d = self.features[79](outp)   # identity <-------
            # reconstruct spiking neuron full-frame inputs to layer 81
            if count == 1:
                l81_pre_inp = outp_d
            else:
                outp_d += l81_pre_inp
                l81_pre_inp = outp_d
            outp_d,l81_mem_potential = self.features[81](outp_d,l81_mem_potential, False, self.is_residual)
            # print('        layer 81, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l81_mem_potential), torch.min(l81_mem_potential), l81_mem_potential.shape))

        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp_r = 0*l75_mem_potential
            outp_r,l75_mem_potential = self.features[75](outp_r,l75_mem_potential, True, self.is_residual)
            # print('        layer 75, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l75_mem_potential), torch.min(l75_mem_potential), l75_mem_potential.shape))
            spike_count[0,75] += torch.sum(outp_r)
             # generate delta-frame inputs to synapse of layer 76
            if count == 1:
                l76_pre_inp = outp_r
            else:
                outp_r = outp_r - l76_pre_inp
                l76_pre_inp = l76_pre_inp + outp_r
            spike_count[0,175] += torch.sum(torch.abs(outp_r))
            outp_r = self.features[76](outp_r) # dropout
            outp_r = self.features[77](outp_r) # synapse  <-------
             # reconstruct spiking neuron full-frame inputs to layer 81
            if count == 1:
                l81_pre_inp = outp_r
            else:
                outp_r += l81_pre_inp
                l81_pre_inp = outp_r
            outp_r,l81_mem_potential = self.features[81](outp_r,l81_mem_potential, False, self.is_residual)
            # print('        layer 81, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l81_mem_potential), torch.min(l81_mem_potential), l81_mem_potential.shape))
            spike_count[0,81] += torch.sum(outp_r)
        

            # outp_r = self.features[74](outp)
            # outp_r,l75_mem_potential = self.features[75](outp_r,l75_mem_potential, self.en_IF, self.is_residual)
            # spike_count[0,75] += torch.sum(outp_r)
            # outp_r = self.features[77](self.features[76](outp_r))
            # outp_d = self.features[79](outp)
            # outp = torch.add(outp_d, outp_r)
            # outp,l81_mem_potential = self.features[81](outp,l81_mem_potential, True, self.is_residual)
            # spike_count[0,81] += torch.sum(outp)

        #++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++#
        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp_r = 0*l81_mem_potential
            outp,l81_mem_potential = self.features[81](outp_r,l81_mem_potential, True, self.is_residual)
            spike_count[0,81] += torch.sum(outp)
            # print('        layer 81, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l81_mem_potential), torch.min(l81_mem_potential), l81_mem_potential.shape))
            # generate delta-frame inputs to synapse of layer 83
            if count == 1:
                l83_pre_inp = outp
            else:
                outp = outp - l83_pre_inp
                l83_pre_inp = l83_pre_inp + outp
            spike_count[0,181] += torch.sum(torch.abs(outp))
            outp_r = self.features[83](outp)   # synapse  <-------
            # reconstruct spiking neuron full-frame inputs to layer 84
            if count == 1:
                l84_pre_inp = outp_r
            else:
                outp_r += l84_pre_inp
                l84_pre_inp = outp_r
            outp_r,l84_mem_potential = self.features[84](outp_r,l84_mem_potential, False, self.is_residual)
            # print('        layer 84, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l84_mem_potential), torch.min(l84_mem_potential), l84_mem_potential.shape))
            spike_count[0,84] += torch.sum(outp_r)
            outp_d = self.features[88](outp)   # identity <-------
            # reconstruct spiking neuron full-frame inputs to layer 90
            if count == 1:
                l90_pre_inp = outp_d
            else:
                outp_d += l90_pre_inp
                l90_pre_inp = outp_d
            outp_d,l90_mem_potential = self.features[90](outp_d,l90_mem_potential, False, self.is_residual)
            # print('        layer 90, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l90_mem_potential), torch.min(l90_mem_potential), l90_mem_potential.shape))

        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp_r = 0*l84_mem_potential
            outp_r,l84_mem_potential = self.features[84](outp_r,l84_mem_potential, True, self.is_residual)
            # print('        layer 84, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l84_mem_potential), torch.min(l84_mem_potential), l84_mem_potential.shape))
            spike_count[0,84] += torch.sum(outp_r)
             # generate delta-frame inputs to synapse of layer 85
            if count == 1:
                l85_pre_inp = outp_r
            else:
                outp_r = outp_r - l85_pre_inp
                l85_pre_inp = l85_pre_inp + outp_r
            spike_count[0,184] += torch.sum(torch.abs(outp_r))
            outp_r = self.features[85](outp_r) # dropout
            outp_r = self.features[86](outp_r) # synapse  <-------
             # reconstruct spiking neuron full-frame inputs to layer 90
            if count == 1:
                l90_pre_inp = outp_r
            else:
                outp_r += l90_pre_inp
                l90_pre_inp = outp_r
            outp_r,l90_mem_potential = self.features[90](outp_r,l90_mem_potential, False, self.is_residual)
            # print('        layer 90, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l90_mem_potential), torch.min(l90_mem_potential), l90_mem_potential.shape))
            spike_count[0,90] += torch.sum(outp_r)


            # outp_r = self.features[83](outp)
            # outp_r,l84_mem_potential = self.features[84](outp_r,l84_mem_potential, self.en_IF, self.is_residual)
            # spike_count[0,84] += torch.sum(outp_r)
            # outp_r = self.features[86](self.features[85](outp_r))
            # outp_d = self.features[88](outp)
            # outp = torch.add(outp_d, outp_r)
            # outp,l90_mem_potential = self.features[90](outp,l90_mem_potential, self.en_IF, self.is_residual)
            # spike_count[0,90] += torch.sum(outp)
            # if torch.sum(outp) == 0 and l90_on == True and ts > self.fpi:
            #     print('     layer 90 is turned off at timestep: {}'.format(ts))
            #     l90_on = False

        
        #++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++#
        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp_r = 0*l90_mem_potential
            outp,l90_mem_potential = self.features[90](outp_r,l90_mem_potential, True, self.is_residual)
            spike_count[0,90] += torch.sum(outp)
            #------------------------------------------------------------
            # generate delta-frame inputs to synapse of layer 91
            if count == 1:
                l91_pre_inp = outp
            else:
                outp = outp - l91_pre_inp
                l91_pre_inp = l91_pre_inp + outp
            spike_count[0,190] += torch.sum(torch.abs(outp))
            outp = self.features[91](outp)
            # reconstruct spiking neuron full-frame inputs to classifier
            if count == 1:
                classifier_pre_inp = outp
            else:
                outp += classifier_pre_inp
                classifier_pre_inp = outp
            #------------------------------------------------------------
            outp = outp.view(outp.size(0), -1)
            outp = self.classifier[0](outp)
            outp_sum += outp
        return outp_sum, l2_max_inp,l5_max_inp,l8_max_inp, spike_count
    

# Rate version of simple network
class ResNetRate(nn.Module):
    def __init__(self, dropout_prob_list=[0.1,0.1,0.1,0.1]):
        super(ResNetRate, self).__init__()
        # Instantiate layers
        self.features = make_features(is_spike=False, is_temp=False, dropout_prob_list=dropout_prob_list)
        self.classifier = make_classifier(is_spike=False)
        print('Dropout Probability: {}'.format(dropout_prob_list))
        # Initialize weights in the MSR style (http://arxiv.org/pdf/1502.01852v1.pdf) which is more suitable for deep network than Xavier initialization (default initialization of convolutional layer in PyTorch)
        self.initialize_weights()
    def forward(self, inp):
        outp = self.features(inp)
        outp = outp.view(outp.size(0), -1)
        outp = self.classifier(outp)
        return outp
    def initialize_weights(self):
        # Initialize all convolutional layers
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                m.weight.data.normal_(0, math.sqrt(2./n))
                if m.bias is not None:
                    m.bias.data.zero_()
        # Reinitialize convolutional residual layer 
        for m in self.modules():
            if isinstance(m, BasicBlock0) or isinstance(m, BasicBlock1):
                for sm in m.modules():
                    if isinstance(sm, nn.Conv2d):
                        n = sm.kernel_size[0] * sm.kernel_size[1] * sm.out_channels
                        sm.weight.data.normal_(0, math.sqrt(2.)/float(n))
                        if sm.bias is not None:
                            sm.bias.data.zero_()

if __name__ == '__main__':

    # Test rate model with random input (batchsize of 4)
    inp = torch.rand(4,3,32,32) 
    print('-'*40)
    # Instantiate rate-baed ResNet model and parallelize model across GPUs, but only for convolutional layers (check this out https://arxiv.org/pdf/1404.5997.pdf)
    model_rate = ResNetRate()
    model_rate = torch.nn.DataParallel(model_rate).cuda()
    # Print model
    print(model_rate)
    # Compute output
    # outp = model_rate(inp)
    # print('Test successful!')
    # input('...')
    
    # Test spiking model with random input (batchsize of 4)
    print('-'*40)
    # Instantiate spiking ResNet model and parallel model across multiple GPUs
    model_spike = ResNetSpike()
    model_spike = torch.nn.DataParallel(model_spike).cuda()
    # Print model
    print(model_spike)
    # Compute output
    model_spike.eval()
    # with torch.no_grad():
    #     outp = model_spike(inp)
    # print('Test successful!')
    # Automatically generate weight mapping list and forward statement
    print('-'*40)
    # After training rate-based model, weight of convolutional layers in the rate-based model is copied to that in the spiking model
    print(len(list(model_rate.state_dict().keys())))
    print(len(list(model_spike.state_dict().keys())))
    print(list(zip(list(model_rate.state_dict().keys()),list(model_spike.state_dict().keys()))))
    # Forward statement for spiking model
    print()
    print('    for j in range(int(self.t_end/self.dt)):')
    inp_dim = 3
    inp_size = 32
    pad_dim = None
    outstr = 'inp'
    initstr1 = '    outp_sum = torch.zeros(inp.size(0),10).cuda()\n'
    initstr2 = ''
    returnstr = '    return outp_sum'
    set1str = '    outp'
    set2str = []
    conv_count = 0
    delay_path = False
    residue_path = False
    # Forward statement for convolutional layers
    for i,m in enumerate(model_spike.module.features):
        if isinstance(m,PoissonGen):
            outstr = 'self.features[{}]({})'.format(i,outstr)
        elif isinstance(m,ResidueMark):
            if outstr != 'outp':
                print('        outp = {}'.format(outstr))
                outstr = 'outp'
            residue_path = True
            rpathstr = 'outp'
        elif isinstance(m,DelayMark):
            residue_path = False
            delay_path = True
            dpathstr = 'outp'
        elif isinstance(m,MergeMark1):
            delay_path = False
            print('        outp_r = {}'.format(rpathstr))
            print('        outp_d = {}'.format(dpathstr))
            print('        outp = torch.add(outp_d, outp_r)')
        elif isinstance(m,MergeMark0):
            delay_path = False
            print('        outp_r = {}'.format(rpathstr))
            print('        outp_d = torch.cat(({},torch.zeros(outp_r.size(0),{},outp_r.size(2),outp_r.size(3)).cuda()),1)'.format(dpathstr,pad_dim))
            print('        outp = torch.add(outp_d, outp_r)')
        elif isinstance(m,nn.Conv2d):
            if residue_path:
                if int(m.in_channels) != int(m.out_channels):
                    pad_dim = int(m.out_channels) - int(m.in_channels)
                inp_dim = int(m.out_channels)
                inp_size = math.floor((inp_size-m.kernel_size[0]+2*m.padding[0])/m.stride[0])+1
                rpathstr = 'self.features[{}]({})'.format(i,rpathstr)
            else:
                inp_dim = int(m.out_channels)
                inp_size = math.floor((inp_size-m.kernel_size[0]+2*m.padding[0])/m.stride[0])+1
                outstr = 'self.features[{}]({})'.format(i,outstr)
        elif isinstance(m,Identity):
            dpathstr = 'self.features[{}]({})'.format(i,dpathstr)
        elif isinstance(m,nn.Dropout):
            if residue_path: 
                rpathstr = 'self.features[{}]({})'.format(i,rpathstr)
            else: 
                outstr = 'self.features[{}]({})'.format(i,outstr)
        elif isinstance(m,nn.AvgPool2d):
            if delay_path: 
                dpathstr = 'self.features[{}]({})'.format(i,dpathstr)
            else:
                outstr = 'self.features[{}]({})'.format(i,outstr)
                inp_size = int((inp_size-m.kernel_size[0])/m.stride[0]+1)
        elif isinstance(m,IFNeuron):
            if residue_path: 
                # rpathstr = 'self.features[{}]({})'.format(i,rpathstr)
                print('        outp_r = {}'.format(rpathstr))
                rpathstr = 'outp_r'
                print('        outp_r,l{}_mem_potential = self.features[{}](outp_r,l{}_mem_potential)'.format(i,i,i))
                initstr1 += '    l{}_mem_potential = torch.zeros(inp.size(0),{},{},{}).cuda()\n'.format(i,inp_dim,inp_size,inp_size)
            else:
                if outstr != 'outp':
                    print('        outp = {}'.format(outstr))
                    outstr = 'outp'
                if conv_count < 3:
                    print('        l{}_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l{}_max_inp)'.format(i,i))
                    print('        outp,l{}_mem_potential = self.features[{}](outp,l{}_mem_potential)'.format(i,i,i))
                    initstr1 += '    l{}_mem_potential = torch.zeros(inp.size(0),{},{},{}).cuda()\n'.format(i,inp_dim,inp_size,inp_size)
                    initstr1 += '    l{}_max_inp = torch.zeros(inp.size(0),1).cuda()\n'.format(i)
                    initstr2 += '    l{}_max_inp_ = torch.zeros(1).cuda()\n'.format(i)
                    returnstr += ',l{}_max_inp'.format(i) 
                    set1str += ',l{}_max_inp'.format(i) 
                    # set2str.append('model_spike.module.features[{}].set_thres(float(torch.max(l{}_max_inp)))\n'.format(i,i))
                    set2str.append('    l{}_max_inp_ = torch.max(l{}_max_inp_,torch.max(l{}_max_inp))\nmodel_spike.module.features[{}].set_thres(float(l{}_max_inp_))\n'.format(i,i,i,i,i))
                    conv_count += 1
                else:
                    print('        outp,l{}_mem_potential = self.features[{}](outp,l{}_mem_potential)'.format(i,i,i))
                    initstr1 += '    l{}_mem_potential = torch.zeros(inp.size(0),{},{},{}).cuda()\n'.format(i,inp_dim,inp_size,inp_size)

        else: 
            assert False, 'Unrecognized module {}'.format(m)
    print('        outp = {}'.format(outstr))
    # Forward statement for reshaping
    outstr = 'outp'
    print('        outp = outp.view(outp.size(0), -1)')
    inp_dim = (inp_dim * inp_size * inp_size)
    # Forward statement for fully connected-layer
    for i,m in enumerate(model_spike.module.classifier):
        if isinstance(m,nn.Linear):
            outstr = 'self.classifier[{}]({})'.format(i,outstr)
        else: 
            assert False, 'Unrecognized module {}'.format(m)
    print('        outp = {}'.format(outstr))
    print('        outp_sum += outp')
    print()
    print(returnstr)
    # Print initialization statement
    print(initstr1)
    print()
    print(initstr2)
    set1str += ' = model_spike(inp)'
    for each in set2str:
        print(set1str)
        print(each)
