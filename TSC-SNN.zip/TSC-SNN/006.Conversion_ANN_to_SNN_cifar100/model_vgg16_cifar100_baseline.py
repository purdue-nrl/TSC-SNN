
import torch
import torch.nn as nn
import math

# Function to create convolutional layer
#   When is_spike=False, this function creates convolutional layer for rate-based VGG network
#   When is_spike=True, this function creates convolutional layer for spiking VGG network 
#   Convolutional layer structure follows model from https://github.com/szagoruyko/cifar.torch/blob/master/models/vgg_bn_drop.lua w/o batch normalization and bias
def make_features(is_spike):

    batch_norm = False
    list_m = []
    in_channels = 3
    if is_spike:
        list_m.append(PoissonGen())
        act_func = IFNeuron
    else:
        act_func = nn.ReLU
    for out_channels in [64, 'D', 64, 'A', 128, 'D', 128, 'A', 256, 'D', 256, 'D', 256, 'A', 512, 'D', 512, 'D', 512, 'A', 512, 'D', 512, 'D', 512, 'A']:
        if out_channels == 'A':
            list_m += [nn.AvgPool2d(kernel_size=(2,2), stride=(2,2))]
        elif out_channels == 'M':
                list_m += [nn.MaxPool2d(kernel_size=(2,2), stride=(2,2))]
        elif out_channels == 'D':
                    list_m += [nn.Dropout(p=0.2)]
        else:
            list_m += [nn.Conv2d(in_channels, out_channels, kernel_size=(3,3), stride=(1,1), padding=(1,1), bias=False)]
            if batch_norm:
                list_m += [nn.BatchNorm2d(out_channels), act_func(inplace=True)]
            else:
                list_m += [act_func(inplace=True)]
            in_channels = out_channels
    return make_hierarchy(list_m,is_spike)

# Make fully connected layer 
#   When is_spike=False, this function creates fully-connected layer for rate-based VGG network
#   When is_spike=True, this function creates fully-connected layer for spiking VGG network 
#   Convolutional layer structure follows model from https://github.com/szagoruyko/cifar.torch/blob/master/models/vgg_bn_drop.lua w/o batch normalization and bias

def make_classifier(is_spike):
    list_m = []
    # list_m += [nn.Dropout(p=0.2)]
    list_m += [nn.Linear(512, 100, bias=False)]
    return make_hierarchy(list_m,is_spike)

# Convert list of modules into torch.nn.ModuleList or torch.nn.Sequentual
#   For spiking simulation, we prefer modules to be stacked in torch.nn.ModuleList because output of modules are accessed at multiple points
#   During threshold balancing, we, for example, need to get maximum input to a particular IFNeuron. Having module in torch.nn.Sequential does allow us to access intermediate values easily 
def make_hierarchy(list_m,is_spike):
    # In Peter Diehl algorithm, we only return stacked module so that we can maximum activation of ReLU during forward path
    return nn.ModuleList(list_m)
    # if is_spike:
    #     return nn.ModuleList(list_m)
    # else:
    #     return nn.Sequential(*list_m)

# Rate version of simple network
class VGGRate(nn.Module):
    def __init__(self):
        super(VGGRate, self).__init__()
        # Instantiate layers
        self.features = make_features(is_spike=False)
        # self.classifier = make_classifier(is_spike=False)
        self.classifier = nn.Linear(512, 100, bias=False)
        # Initialize weights in the MSR style (http://arxiv.org/pdf/1502.01852v1.pdf) which is more suitable for deep network than Xavier initialization (default initialization of convolutional layer in PyTorch)
        self.initialize_weights()
    def forward(self, inp):
         # Forward statement here is based on forward path of spiking net work in model_vgg16_cifar10.py
        l1_max_outp = torch.zeros(inp.size(0),1).cuda()
        l4_max_outp = torch.zeros(inp.size(0),1).cuda()
        l7_max_outp = torch.zeros(inp.size(0),1).cuda()
        l10_max_outp = torch.zeros(inp.size(0),1).cuda()
        l13_max_outp = torch.zeros(inp.size(0),1).cuda()
        l16_max_outp = torch.zeros(inp.size(0),1).cuda()
        l19_max_outp = torch.zeros(inp.size(0),1).cuda()
        l22_max_outp = torch.zeros(inp.size(0),1).cuda()
        l25_max_outp = torch.zeros(inp.size(0),1).cuda()
        l28_max_outp = torch.zeros(inp.size(0),1).cuda()
        l31_max_outp = torch.zeros(inp.size(0),1).cuda()
        l34_max_outp = torch.zeros(inp.size(0),1).cuda()
        l37_max_outp = torch.zeros(inp.size(0),1).cuda()
        c_max_outp = torch.zeros(inp.size(0),1).cuda()
        outp = self.features.module[1](self.features.module[0](inp))
        l1_max_outp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l1_max_outp)
        outp = self.features.module[4](self.features.module[3](self.features.module[2](outp)))
        l4_max_outp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l4_max_outp)
        outp = self.features.module[7](self.features.module[6](self.features.module[5](outp)))
        l7_max_outp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l7_max_outp)
        outp = self.features.module[10](self.features.module[9](self.features.module[8](outp)))
        l10_max_outp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l10_max_outp)
        outp = self.features.module[13](self.features.module[12](self.features.module[11](outp)))
        l13_max_outp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l13_max_outp)
        outp = self.features.module[16](self.features.module[15](self.features.module[14](outp)))
        l16_max_outp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l16_max_outp)
        outp = self.features.module[19](self.features.module[18](self.features.module[17](outp)))
        l19_max_outp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l19_max_outp)
        outp = self.features.module[22](self.features.module[21](self.features.module[20](outp)))
        l22_max_outp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l22_max_outp)
        outp = self.features.module[25](self.features.module[24](self.features.module[23](outp)))
        l25_max_outp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l25_max_outp)
        outp = self.features.module[28](self.features.module[27](self.features.module[26](outp)))
        l28_max_outp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l28_max_outp)
        outp = self.features.module[31](self.features.module[30](self.features.module[29](outp)))
        l31_max_outp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l31_max_outp)
        outp = self.features.module[34](self.features.module[33](self.features.module[32](outp)))
        l34_max_outp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l34_max_outp)
        outp = self.features.module[37](self.features.module[36](self.features.module[35](outp)))
        l37_max_outp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l37_max_outp)
        outp = self.features.module[38](outp)
        outp = outp.view(outp.size(0), -1)
        outp = self.classifier(outp)
        
        # loss = criterion(outp, target)
        # # measure accuracy and record loss
        # prec1, prec5 = accuracy(outp, target, topk=(1, 5))
        # acc_top1.append(float(prec1))
        # acc_top5.append(float(prec5))

        return outp,l1_max_outp,l4_max_outp,l7_max_outp,l10_max_outp,l13_max_outp,l16_max_outp,l19_max_outp,l22_max_outp,l25_max_outp,l28_max_outp,l31_max_outp,l34_max_outp,l37_max_outp,c_max_outp 

    def initialize_weights(self):
        for m in self.modules():
            # Only reinitialize for spatial convolutional layer
            if isinstance(m, nn.Conv2d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                m.weight.data.normal_(0, math.sqrt(2. / n))
                if m.bias is not None:
                    m.bias.data.zero_()
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                if m.bias is not None:
                    m.bias.data.zero_()
            elif isinstance(m, nn.Linear):
                n = m.weight.size(1)
                m.weight.data.normal_(0, 0.01)
                if m.bias is not None:
                    m.bias.data.zero_() 






if __name__ == '__main__':

    # Test rate model with random input (batchsize of 4)
    inp = torch.rand(4,3,32,32).cuda() 
    print('-'*40)
    # Instantiate rate-baed VGG model and parallelize model across GPUs, but only for convolutional layers (check this out https://arxiv.org/pdf/1404.5997.pdf)
    model_rate = VGGRate()
    model_rate.features = torch.nn.DataParallel(model_rate.features)
    model_rate.cuda()
    # Print model
    print(model_rate)
    # Compute output
    outp = model_rate(inp)
    print(list(model_rate.state_dict().keys()))
    print('Test successful!')
    
