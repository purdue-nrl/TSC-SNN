
import torch
import torch.nn as nn
import math

# Poisson spike generator
#   This module generates spike based on assumption that input is between 1 and -1
#   Positive spike is generated (i.e. 1 is return) if rand()<abs(input) and sign(input)=1
#   Negative spike is generated (i.e. -1 is return) if rand()<abs(input) and sign(input)=-1
#   This method is corresponding to Method 1 on Page 5 of lecture note http://www.cns.nyu.edu/~david/handouts/poisson.pdf
class PoissonGen(nn.Module):
    def __init__(self):
        super(PoissonGen, self).__init__()
    def forward(self, inp, t, N, en_IN):
        # nbits = 32
        # inp_disc= torch.round(inp*(2^nbits-1))/(2^nbits-1)
        if en_IN:
            op=1.0
        else:
            op=0.0
        # return op*torch.mul(torch.le(torch.rand_like(inp), torch.abs(inp_disc)).float(), torch.sign(inp))
        return op*torch.mul(torch.le(torch.rand_like(inp), torch.abs(inp)).float(), torch.sign(inp))


# Temporal spikes generator
class TemporalGen(nn.Module):
    def __init__(self):
        super(TemporalGen, self).__init__()
    def forward(self, inp, t, N, en_IN):
        
        if en_IN:
            op=1.0
        else:
            op=0.0
        
        outp = op * torch.mul(torch.mul( torch.ge(inp*0+t, shift_pos + ((N+1)/2)*(1-torch.abs(inp))).float(),
                                         torch.le(inp*0+t, shift_neg + ((N+1)/2)*(1+torch.abs(inp))).float()), torch.sign(inp))
        return outp

# Integrate-and-fire neuron (IFNeuron)
#   This module is slightly from IFNeuron module in the script that I have sent to Gopal and Priya earlier.
#   This module models simple IFNeuron without any refractory period
#   This modeule does not have state information, thus allowing it to be parallelized across GPUs when torch.nn.DataParallel is wrapped around
#   As a result, this module takes two arguments: input and previous IFNeuron membrane potential
#   Spike is generated if IFNeuron membrane potential reachs defined threshold
#   Spike output is return with new IFNeuron membrane potential
class IFNeuron(nn.Module):
    # Argument inplace does not have any use. You can ignore it. 
    def __init__(self, inplace=True, thres=1.0):
        super(IFNeuron, self).__init__()
        self.thres = thres
    def forward(self, inp, mem_potential, IF_spiking, IF_residual):
        mem_potential += inp
        outp = mem_potential*0.0
        if IF_spiking:
            outp = torch.ge(mem_potential, self.thres)
            if IF_residual:
                mem_potential[outp] = (mem_potential[outp] - self.thres)*1.0  # Residual-IF neuron
            else:
                mem_potential[outp] = (mem_potential[outp] - self.thres)*0.0  # IF neuron
        return outp.float(), mem_potential
    def set_thres(self, thres):
        self.thres = thres
    def get_thres(self):
        return self.thres
    def extra_repr(self):
        return 'thres={}'.format(self.thres)

# Function to create convolutional layer
#   When is_spike=False, this function creates convolutional layer for rate-based VGG network
#   When is_spike=True, this function creates convolutional layer for spiking VGG network 
#   Convolutional layer structure follows model from https://github.com/szagoruyko/cifar.torch/blob/master/models/vgg_bn_drop.lua w/o batch normalization and bias
def make_features(is_spike, is_temp):
    batch_norm = False
    list_m = []
    in_channels = 3

    if is_spike:
        if is_temp:
            list_m.append(TemporalGen())
        else:
            list_m.append(PoissonGen())
        act_func = IFNeuron
    else:
        act_func = nn.ReLU

    for out_channels in [64, 'D', 64, 'A', 128, 'D', 128, 'A', 256, 'D', 256, 'D', 256, 'A', 512, 'D', 512, 'D', 512, 'A', 512, 'D', 512, 'D', 512, 'A']: 
        if out_channels == 'A':
            list_m += [nn.AvgPool2d(kernel_size=(2,2), stride=(2,2))]
        elif out_channels == 'M':
            list_m += [nn.MaxPool2d(kernel_size=(2,2), stride=(2,2))]
        elif out_channels == 'D':
                list_m += [nn.Dropout(p=0.3)]
        else:
            list_m += [nn.Conv2d(in_channels, out_channels, kernel_size=(3,3), stride=(1,1), padding=(1,1), bias=False)]
            if batch_norm:
                list_m += [nn.BatchNorm2d(out_channels), act_func(inplace=True)]
            else:
                list_m += [act_func(inplace=True)]
            in_channels = out_channels
    return make_hierarchy(list_m,is_spike)


# Make fully connected layer 
#   When is_spike=False, this function creates fully-connected layer for rate-based VGG network
#   When is_spike=True, this function creates fully-connected layer for spiking VGG network 
#   Convolutional layer structure follows model from https://github.com/szagoruyko/cifar.torch/blob/master/models/vgg_bn_drop.lua w/o batch normalization and bias

def make_classifier(is_spike):
    list_m = []
    # list_m += [nn.Dropout(p=0.2)]
    list_m += [nn.Linear(512, 100, bias=False)]  
    return make_hierarchy(list_m,is_spike)


# Convert list of modules into torch.nn.ModuleList or torch.nn.Sequentual
#   For spiking simulation, we prefer modules to be stacked in torch.nn.ModuleList because output of modules are accessed at multiple points
#   During threshold balancing, we, for example, need to get maximum input to a particular IFNeuron. Having module in torch.nn.Sequential does allow us to access intermediate values easily 
def make_hierarchy(list_m,is_spike):
     if is_spike:
         return nn.ModuleList(list_m)
     else:
         return nn.Sequential(*list_m)

# Spiking version of simple network
class VGGSpike(nn.Module):
    def __init__(self, dt=0.001, t_end=0.128, in_coding='temp', snn_mode='full', if_mode='if', TTS=256, fpi=128):
        super(VGGSpike, self).__init__()
        # Save network parameters

        self.dt = dt
        self.t_end = t_end
        self.TTS = TTS
        self.fpi = fpi+1
        self.in_coding = in_coding
        self.snn_mode = snn_mode
        self.if_mode = if_mode

        if self.if_mode == 'residual':
            self.is_residual = True
        elif self.if_mode == 'if':
            self.is_residual = False

        if self.in_coding == 'temp':
            is_temp = True
        elif self.in_coding == 'rate':
            is_temp = False

        # Instantiate layers
        self.features = make_features(is_spike=True, is_temp=is_temp)
        self.classifier = nn.Linear(512, 100, bias=False)
        # self.classifier = make_classifier(is_spike=True)
        # self.initialize_weights()
        # self.initialize_thresholds()


    def initialize_thresholds(self):
        th = 1.0
        self.features[2].set_thres(th)
        self.features[5].set_thres(th)
        self.features[8].set_thres(th)
        self.features[11].set_thres(th)
        self.features[14].set_thres(th)
        self.features[17].set_thres(th)
        self.features[20].set_thres(th)
        self.features[23].set_thres(th)
        self.features[26].set_thres(th)
        self.features[29].set_thres(th)
        self.features[32].set_thres(th)
        self.features[35].set_thres(th)
        self.features[38].set_thres(th)
     

    def initialize_weights(self):
        for m in self.modules():
            # Only reinitialize for spatial convolutional layer
            if isinstance(m, nn.Conv2d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                m.weight.data.normal_(0, math.sqrt(2. / n))
                if m.bias is not None:
                    m.bias.data.zero_()
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                if m.bias is not None:
                    m.bias.data.zero_()
            elif isinstance(m, nn.Linear):
                n = m.weight.size(1)
                m.weight.data.normal_(0, 0.01)
                if m.bias is not None:
                    m.bias.data.zero_()

    def forward(self, inp):
        # Code in this forward function is automatically generated by running this script
        #   $ python model_vgg16_cifar10.py
        # XX_mem_potential stores membrane potential of IFNeuron at layer XX
        # XX_max_inp stores maximum input to IFNeuon at layer XX 

        outp_sum = torch.zeros(inp.size(0),100).cuda()
        l2_mem_potential = torch.zeros(inp.size(0),64,32,32).cuda()
        l2_max_inp = torch.zeros(inp.size(0),1).cuda()
        l2_pre_inp = torch.zeros(inp.size(0),64,32,32).cuda()
        l3_pre_inp = torch.zeros(inp.size(0),64,32,32).cuda()

        l5_mem_potential = torch.zeros(inp.size(0),64,32,32).cuda()
        l5_max_inp = torch.zeros(inp.size(0),1).cuda()
        l5_pre_inp = torch.zeros(inp.size(0),64,32,32).cuda()
        l6_pre_inp = torch.zeros(inp.size(0),64,32,32).cuda()

        l8_mem_potential = torch.zeros(inp.size(0),128,16,16).cuda()
        l8_max_inp = torch.zeros(inp.size(0),1).cuda()
        l8_pre_inp = torch.zeros(inp.size(0),128,16,16).cuda()
        l9_pre_inp = torch.zeros(inp.size(0),128,16,16).cuda()

        l11_mem_potential = torch.zeros(inp.size(0),128,16,16).cuda()
        l11_max_inp = torch.zeros(inp.size(0),1).cuda()
        l11_pre_inp = torch.zeros(inp.size(0),128,16,16).cuda()
        l12_pre_inp = torch.zeros(inp.size(0),128,16,16).cuda()

        l14_mem_potential = torch.zeros(inp.size(0),256,8,8).cuda()
        l14_max_inp = torch.zeros(inp.size(0),1).cuda()
        l14_pre_inp = torch.zeros(inp.size(0),256,8,8).cuda()
        l15_pre_inp = torch.zeros(inp.size(0),256,8,8).cuda()

        l17_mem_potential = torch.zeros(inp.size(0),256,8,8).cuda()
        l17_max_inp = torch.zeros(inp.size(0),1).cuda()
        l17_pre_inp = torch.zeros(inp.size(0),256,8,8).cuda()
        l18_pre_inp = torch.zeros(inp.size(0),256,8,8).cuda()

        l20_mem_potential = torch.zeros(inp.size(0),256,8,8).cuda()
        l20_max_inp = torch.zeros(inp.size(0),1).cuda()
        l20_pre_inp = torch.zeros(inp.size(0),256,8,8).cuda()
        l21_pre_inp = torch.zeros(inp.size(0),256,8,8).cuda()

        l23_mem_potential = torch.zeros(inp.size(0),512,4,4).cuda()
        l23_max_inp = torch.zeros(inp.size(0),1).cuda()
        l23_pre_inp = torch.zeros(inp.size(0),512,4,4).cuda()
        l24_pre_inp = torch.zeros(inp.size(0),512,4,4).cuda()

        l26_mem_potential = torch.zeros(inp.size(0),512,4,4).cuda()
        l26_max_inp = torch.zeros(inp.size(0),1).cuda()
        l26_pre_inp = torch.zeros(inp.size(0),512,4,4).cuda()
        l27_pre_inp = torch.zeros(inp.size(0),512,4,4).cuda()

        l29_mem_potential = torch.zeros(inp.size(0),512,4,4).cuda()
        l29_max_inp = torch.zeros(inp.size(0),1).cuda()
        l29_pre_inp = torch.zeros(inp.size(0),512,4,4).cuda()
        l30_pre_inp = torch.zeros(inp.size(0),512,4,4).cuda()

        l32_mem_potential = torch.zeros(inp.size(0),512,2,2).cuda()
        l32_max_inp = torch.zeros(inp.size(0),1).cuda()
        l32_pre_inp = torch.zeros(inp.size(0),512,2,2).cuda()
        l33_pre_inp = torch.zeros(inp.size(0),512,2,2).cuda()

        l35_mem_potential = torch.zeros(inp.size(0),512,2,2).cuda()
        l35_max_inp = torch.zeros(inp.size(0),1).cuda()
        l35_pre_inp = torch.zeros(inp.size(0),512,2,2).cuda()
        l36_pre_inp = torch.zeros(inp.size(0),512,2,2).cuda()

        l38_mem_potential = torch.zeros(inp.size(0),512,2,2).cuda()
        l38_max_inp = torch.zeros(inp.size(0),1).cuda()
        l38_pre_inp = torch.zeros(inp.size(0),512,2,2).cuda()
        l39_pre_inp = torch.zeros(inp.size(0),512,2,2).cuda()
        
        # c1_mem_potential = torch.zeros(inp.size(0),100).cuda()
        # c1_max_inp = torch.zeros(inp.size(0),1).cuda()

        spike_count = torch.zeros(1,200).cuda()
        # Simulating spiking network over time inside the module, thus allow simulation to be parallelized across GPUs when torch.nn.DataParallel is wrapped around


        self.en_IN = True
        self.en_IF = True
        l2_on = True
        l5_on = True
        l8_on = True

        l11_on = True
        l14_on = True
        l17_on = True

        l20_on = True
        l23_on = True
        l26_on = True

        l29_on = True
        l32_on = True
        l35_on = True
        l38_on = True

        for ts in range(self.TTS):

            count = count + 1
            if count%self.fpi==0:
                count = 1

            # print(count)
            
            # print('timestep {}, en_IN = {}, en_IF = {}, fpi = {}, TTS = {}'.format(ts, self.en_IN, self.en_IF, self.fpi, self.TTS))  
            # print('count = {}, count_pre = {}'.format(count, count_pre))    

            # generate delta-frame inputs to synapse of layer 1
            if count == 1:
                outp = self.features[0](inp, count, self.fpi, self.en_IN)
            else:
                outp = self.features[0](inp, count, self.fpi, self.en_IN) - self.features[0](inp, count-1, self.fpi, self.en_IN)
            spike_count[0,101] += torch.sum(torch.abs(outp))
            spike_count[0,1] += torch.sum(torch.abs(self.features[0](inp, count, self.fpi, self.en_IN)))
            # print('spike_count_full = {}, spike_count_delt = {}'.format(torch.sum(torch.abs(self.features[0](inp, count, self.fpi, self.en_IN))), torch.sum(torch.abs(outp))))  
            outp = self.features[1](outp) # synapse
            # reconstruct spiking neuron full-frame inputs to layer 2
            if count == 1:
                l2_pre_inp = outp
            else:
                outp += l2_pre_inp
                l2_pre_inp = outp
            l2_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l2_max_inp)
            outp,l2_mem_potential = self.features[2](outp,l2_mem_potential, self.en_IF, self.is_residual)
            spike_count[0,2] += torch.sum(torch.abs(outp))

            
        count = 1
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp = 0*l2_mem_potential
            outp,l2_mem_potential = self.features[2](outp,l2_mem_potential, True, self.is_residual)
            spike_count[0,2] += torch.sum(torch.abs(outp))

            # generate delta-frame inputs to synapse of layer 4 
            if count == 1:
                l3_pre_inp = outp
            else:
                outp = outp - l3_pre_inp
                l3_pre_inp = l3_pre_inp + outp

            spike_count[0,102] += torch.sum(torch.abs(outp))
            outp = self.features[3](outp) # dropout
            outp = self.features[4](outp) # synapse
            # reconstruct spiking neuron full-frame inputs to layer 5
            if count == 1:
                l5_pre_inp = outp
            else:
                outp += l5_pre_inp
                l5_pre_inp = outp
            l5_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l5_max_inp)
            outp,l5_mem_potential = self.features[5](outp,l5_mem_potential, self.en_IF, self.is_residual)
            # print('        layer 5, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l5_mem_potential), torch.min(l5_mem_potential), l5_mem_potential.shape))
            spike_count[0,5] += torch.sum(outp)


            # if torch.sum(outp) == 0 and l5_on == True and ts > self.fpi:
            # print('       layer 5 is turned off at timestep: {}'.format(ts))
            #     l5_on = False
            outp = self.features[7](self.features[6](outp))

            l8_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l8_max_inp)
            outp,l8_mem_potential = self.features[8](outp,l8_mem_potential, self.en_IF, self.is_residual)
            # print('        layer 8, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l8_mem_potential), torch.min(l8_mem_potential), l8_mem_potential.shape))
            spike_count[0,8] += torch.sum(outp)
            if torch.sum(outp) == 0 and l8_on == True and ts > self.fpi:
                print('     layer 8 is turned off at timestep: {}'.format(ts))
                l8_on = False
            outp = self.features[10](self.features[9](outp))

            l11_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l11_max_inp)
            outp,l11_mem_potential = self.features[11](outp,l11_mem_potential, self.en_IF, self.is_residual)
            # print('        layer 11, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l11_mem_potential), torch.min(l11_mem_potential), l11_mem_potential.shape))
            spike_count[0,11] += torch.sum(outp)            
            outp = self.features[13](self.features[12](outp))

            l14_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l14_max_inp)
            outp,l14_mem_potential = self.features[14](outp,l14_mem_potential, self.en_IF, self.is_residual)
            # print('        layer 14, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l14_mem_potential), torch.min(l14_mem_potential), l14_mem_potential.shape))
            spike_count[0,14] += torch.sum(outp)
            outp = self.features[16](self.features[15](outp))

            l17_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l17_max_inp)
            outp,l17_mem_potential = self.features[17](outp,l17_mem_potential, self.en_IF, self.is_residual)
            # print('        layer 17, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l17_mem_potential), torch.min(l17_mem_potential), l17_mem_potential.shape))
            spike_count[0,17] += torch.sum(outp)
            if torch.sum(outp) == 0 and l17_on == True and ts > self.fpi:
                print('     layer 17 is turned off at timestep: {}'.format(ts))
                l17_on = False           
            outp = self.features[19](self.features[18](outp))

	    l20_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l20_max_inp)
	    outp,l20_mem_potential = self.features[20](outp,l20_mem_potential, self.en_IF, self.is_residual)
            # print('        layer 20, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l20_mem_potential), torch.min(l20_mem_potential), l20_mem_potential.shape))
            spike_count[0,20] += torch.sum(outp)
            outp = self.features[22](self.features[21](outp))

	    l23_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l23_max_inp)
	    outp,l23_mem_potential = self.features[23](outp,l23_mem_potential, self.en_IF, self.is_residual)
            # print('        layer 23, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l23_mem_potential), torch.min(l23_mem_potential), l23_mem_potential.shape))
            spike_count[0,23] += torch.sum(outp)	    
	    outp = self.features[25](self.features[24](outp))

	    l26_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l26_max_inp)
	    outp,l26_mem_potential = self.features[26](outp,l26_mem_potential, self.en_IF, self.is_residual)
            # print('        layer 26, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l26_mem_potential), torch.min(l26_mem_potential), l26_mem_potential.shape))
            spike_count[0,26] += torch.sum(outp)
            if torch.sum(outp) == 0 and l26_on == True and ts > self.fpi:
                print('     layer 26 is turned off at timestep: {}'.format(ts))
                l26_on = False
	    outp = self.features[28](self.features[27](outp))

	    l29_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l29_max_inp)
	    outp,l29_mem_potential = self.features[29](outp,l29_mem_potential, self.en_IF, self.is_residual)
            # print('        layer 29, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l29_mem_potential), torch.min(l29_mem_potential), l29_mem_potential.shape))
            spike_count[0,29] += torch.sum(outp)	    
	    outp = self.features[31](self.features[30](outp))

	    l32_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l32_max_inp)
	    outp,l32_mem_potential = self.features[32](outp,l32_mem_potential, self.en_IF, self.is_residual)
            # print('        layer 32, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l32_mem_potential), torch.min(l32_mem_potential), l32_mem_potential.shape))
            spike_count[0,32] += torch.sum(outp)	    
	    outp = self.features[34](self.features[33](outp))

	    l35_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l35_max_inp)
	    outp,l35_mem_potential = self.features[35](outp,l35_mem_potential, self.en_IF, self.is_residual)
            # print('        layer 35, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l35_mem_potential), torch.min(l35_mem_potential), l35_mem_potential.shape))
            spike_count[0,35] += torch.sum(outp)	    
	    outp = self.features[37](self.features[36](outp))

	    l38_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l38_max_inp)
	    outp,l38_mem_potential = self.features[38](outp,l38_mem_potential, self.en_IF, self.is_residual)
            # print('        layer 38, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l38_mem_potential), torch.min(l38_mem_potential), l38_mem_potential.shape))
            spike_count[0,38] += torch.sum(outp)
            if torch.sum(outp) == 0 and l38_on == True and ts > self.fpi:
                print('     layer 38 is turned off at timestep: {}'.format(ts))
                l38_on = False	    

            outp = self.features[39](outp)
            outp = outp.view(outp.size(0), -1)
            outp = self.classifier(outp)
            outp_sum += outp
          
        return outp_sum,l2_max_inp,l5_max_inp,l8_max_inp,l11_max_inp,l14_max_inp,l17_max_inp,l20_max_inp,l23_max_inp,l26_max_inp,l29_max_inp,l32_max_inp,l35_max_inp,l38_max_inp,spike_count

# Rate version of simple network
class VGGRate(nn.Module):
    
    def __init__(self):
        super(VGGRate, self).__init__()
        # Instantiate layers
        self.features = make_features(is_spike=False, is_temp=False)
        self.classifier = nn.Linear(512, 100, bias=False)
        # self.classifier = make_classifier(is_spike=False)
        # Initialize weights in the MSR style (http://arxiv.org/pdf/1502.01852v1.pdf) which is more suitable for deep network than Xavier initialization (default initialization of convolutional layer in PyTorch)
        self.initialize_weights()

    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                m.weight.data.normal_(0, math.sqrt(2. / n))
                if m.bias is not None:
                    m.bias.data.zero_()
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                if m.bias is not None:
                    m.bias.data.zero_()
            elif isinstance(m, nn.Linear):
                n = m.weight.size(1)
                m.weight.data.normal_(0, 0.01)
                if m.bias is not None:
                    m.bias.data.zero_()

    def forward(self, inp):
        # outp = self.features(inp)
        # outp = outp.view(outp.size(0), -1)
        # outp = self.classifier(outp)

        # print('inp_batch_img', inp.shape, torch.max(inp), torch.min(inp))

        # compute outp
        # outp = model(inp)

        outp = self.features.module[0](inp)
        # print('l0_max_outp_pre', torch.max(outp), torch.min(outp))
        outp = self.features.module[1](outp)
        outp = self.features.module[2](outp)

        outp = self.features.module[3](outp)
        # print('l3_max_outp_pre', torch.max(outp), torch.min(outp))
        outp = self.features.module[4](outp)
        outp = self.features.module[5](outp)

        outp = self.features.module[6](outp)
        # print('l6_max_outp', torch.max(outp), torch.min(outp))
        outp = self.features.module[7](outp)
        outp = self.features.module[8](outp)

        outp = self.features.module[9](outp)
        # print('l9_max_outp', torch.max(outp), torch.min(outp))
        outp = self.features.module[10](outp)
        outp = self.features.module[11](outp)

        outp = self.features.module[12](outp)
        # print('l12_max_outp', torch.max(outp), torch.min(outp))
        outp = self.features.module[13](outp)
        outp = self.features.module[14](outp)

        outp = self.features.module[15](outp)
        # print('l15_max_outp', torch.max(outp), torch.min(outp))
        outp = self.features.module[16](outp)
        outp = self.features.module[17](outp)

        outp = self.features.module[18](outp)
        # print('l18_max_outp', torch.max(outp), torch.min(outp))
        outp = self.features.module[19](outp)
        outp = self.features.module[20](outp)

        outp = self.features.module[21](outp)
        # print('l21_max_outp', torch.max(outp), torch.min(outp))
        outp = self.features.module[22](outp)
        outp = self.features.module[23](outp)

        outp = self.features.module[24](outp)
        # print('l24_max_outp', torch.max(outp), torch.min(outp))
        outp = self.features.module[25](outp)
        outp = self.features.module[26](outp) 

        outp = self.features.module[27](outp)
        # print('l27_max_outp', torch.max(outp), torch.min(outp))
        outp = self.features.module[28](outp)
        outp = self.features.module[29](outp)

        outp = self.features.module[30](outp)
        # print('l30_max_outp', torch.max(outp), torch.min(outp))
        outp = self.features.module[31](outp)
        outp = self.features.module[32](outp)

        outp = self.features.module[33](outp)
        # print('l33_max_outp', torch.max(outp), torch.min(outp))
        outp = self.features.module[34](outp)
        outp = self.features.module[35](outp)

        outp = self.features.module[36](outp)
        # print('l36_max_outp', torch.max(outp), torch.min(outp))
        outp = self.features.module[37](outp)
        outp = self.features.module[38](outp)

        outp = outp.view(outp.size(0), -1)
        outp = self.classifier(outp)
        
        return outp


    def initialize_weights(self):
        for m in self.modules():
            # Only reinitialize for spatial convolutional layer
            if isinstance(m, nn.Conv2d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                m.weight.data.normal_(0, math.sqrt(2. / n))
                if m.bias is not None:
                    m.bias.data.zero_()
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                if m.bias is not None:
                    m.bias.data.zero_()
            elif isinstance(m, nn.Linear):
                n = m.weight.size(1)
                m.weight.data.normal_(0, 0.01)
                if m.bias is not None:
                    m.bias.data.zero_() 


if __name__ == '__main__':

    # Test rate model with random input (batchsize of 4)
    inp = torch.rand(4,3,32,32) 
    print('-'*40)
    # Instantiate rate-baed VGG model and parallelize model across GPUs, but only for convolutional layers (check this out https://arxiv.org/pdf/1404.5997.pdf)
    model_rate = VGGRate()
    model_rate.features = torch.nn.DataParallel(model_rate.features)
    model_rate.cuda()
    # Print model
    print(model_rate)
    # Compute output
    # outp = model_rate(inp)
    # print('Test successful!')
    # input('...')
    sys.exit(0)
    
    # Test spiking model with random input (batchsize of 4)
    print('-'*40)
    # Instantiate spiking VGG model and parallel model across multiple GPUs
    model_spike = VGGSpike()
    model_spike = torch.nn.DataParallel(model_spike).cuda()
    # Print model
    print(model_spike)
    # Compute output
    model_spike.eval()
    # with torch.no_grad():
    #     outp = model_spike(inp)
    # print('Test successful!')

    # Automatically generate weight mapping list and forward statement
    print('-'*40)
    # After training rate-based model, weight of convolutional layers in the rate-based model is copied to that in the spiking model
    print(list(zip(list(model_rate.state_dict().keys()),list(model_spike.state_dict().keys()))))
    # Forward statement for spiking model
    print()
    print('    for j in range(int(self.t_end/self.dt)):')
    inp_dim = 3
    inp_size = 32
    outstr = 'inp'
    initstr1 = '    outp_sum = torch.zeros(inp.size(0),100).cuda()\n'
    initstr2 = ''
    returnstr = '    return outp_sum'
    set1str = '    outp'
    set2str = []
    # Forward statement for convolutional layers
    for i,m in enumerate(model_spike.module.features):
        if isinstance(m,PoissonGen) or isinstance(m,nn.Dropout):
            outstr = 'self.features[{}]({})'.format(i,outstr)
        elif isinstance(m,nn.Conv2d):
            outstr = 'self.features[{}]({})'.format(i,outstr)
            inp_dim = int(m.out_channels)
            inp_size = int((inp_size-m.kernel_size[0]+2*m.padding[0])/m.stride[0]+1)
        elif isinstance(m,nn.AvgPool2d):
            outstr = 'self.features[{}]({})'.format(i,outstr)
            inp_size = int((inp_size-m.kernel_size[0])/m.stride[0]+1)
        elif isinstance(m,IFNeuron):
            print('        outp = {}'.format(outstr))
            outstr = 'outp'
            print('        l{}_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l{}_max_inp)'.format(i,i))
            print('        outp,l{}_mem_potential = self.features[{}](outp,l{}_mem_potential)'.format(i,i,i))
            initstr1 += '    l{}_mem_potential = torch.zeros(inp.size(0),{},{},{}).cuda()\n'.format(i,inp_dim,inp_size,inp_size)
            initstr1 += '    l{}_max_inp = torch.zeros(inp.size(0),1).cuda()\n'.format(i)
            initstr2 += '    l{}_max_inp_ = torch.zeros(1).cuda()\n'.format(i)
            returnstr += ',l{}_max_inp'.format(i) 
            set1str += ',l{}_max_inp'.format(i) 
            # set2str.append('model_spike.module.features[{}].set_thres(float(torch.max(l{}_max_inp)))\n'.format(i,i))
            set2str.append('    l{}_max_inp_ = torch.max(l{}_max_inp_,torch.max(l{}_max_inp))\nmodel_spike.module.features[{}].set_thres(float(l{}_max_inp_))\n'.format(i,i,i,i,i))
        else: 
            assert False, 'Unrecognized module {}'.format(m)
    print('        outp = {}'.format(outstr))
    outstr = 'outp'
    # Forward statement for reshaping
    print('        outp = outp.view(outp.size(0), -1)')
    inp_dim = (inp_dim * inp_size * inp_size)
    # Forward statement for fully connected-layer
    for i,m in enumerate(model_spike.module.classifier):
        if isinstance(m,nn.Dropout):
            outstr = 'self.classifier[{}]({})'.format(i,outstr)
        elif isinstance(m,nn.Linear):
            outstr = 'self.classifier[{}]({})'.format(i,outstr)
        elif isinstance(m,IFNeuron):
            print('        outp = {}'.format(outstr))
            outstr = 'outp'
            print('        c{}_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],c{}_max_inp)'.format(i,i))
            print('        outp,c{}_mem_potential = self.classifier[{}](outp,c{}_mem_potential)'.format(i,i,i))
            initstr1 += '    c{}_mem_potential = torch.zeros(inp.size(0),{}).cuda()\n'.format(i,inp_dim)
            initstr1 += '    c{}_max_inp = torch.zeros(inp.size(0),1).cuda()\n'.format(i)
            initstr2 += '    c{}_max_inp = torch.zeros(1).cuda()\n'.format(i)
            returnstr += ',c{}_max_inp'.format(i) 
            set1str += ',c{}_max_inp'.format(i) 
            # set2str.append('model_spike.module.classifier[{}].set_thres(float(torch.max(c{}_max_inp)))\n'.format(i,i))
            set2str.append('    c{}_max_inp_ = torch.max(c{}_max_inp_,torch.max(c{}_max_inp))\nmodel_spike.module.classifier[{}].set_thres(float(c{}_max_inp_))\n'.format(i,i,i,i,i))
        else: 
            assert False, 'Unrecognized module {}'.format(m)
    print('        outp = {}'.format(outstr))
    print('        outp_sum += outp')
    print()
    print(returnstr)
    # Print initialization statement
    print(initstr1)
    print()
    print(initstr2)
    set1str += ' = model_spike(inp)'
    for each in set2str:
        print(set1str)
        print(each)

    # # Generate code for baseline comparison
    # inp_dim = 3
    # inp_size = 32
    # outstr = 'inp'
    # initstr = ''
    # returnstr = '        return outp'
    # set1str = '    outp'
    # set2str = []
    # set3str = ['    prev_factor = 1']
    # # Forward statement for convolutional layers
    # for i,m in enumerate(model_rate.features.module):
    #     if isinstance(m,PoissonGen) or isinstance(m,nn.Dropout):
    #         outstr = 'self.features.module[{}]({})'.format(i,outstr)
    #     elif isinstance(m,nn.Conv2d):
    #         outstr = 'self.features.module[{}]({})'.format(i,outstr)
    #         inp_dim = int(m.out_channels)
    #         inp_size = int((inp_size-m.kernel_size[0]+2*m.padding[0])/m.stride[0]+1)
    #         set3str += ['    l{}_maxw = torch.max(model_seq.features.module[{}].weight)'.format(i,i)]
    #         set3str += ['    scale_factor = torch.max(l{}_hmax_outp, l{}_maxw)'.format(i+1,i)]
    #         set3str += ['    apply_factor = torch.div(scale_factor, prev_factor)']
    #         set3str += ['    model_seq.features.module[{}].weight.data = torch.div(model_seq.features.module[{}].weight, apply_factor)'.format(i,i)]
    #         set3str += ['    prev_factor = scale_factor']
    #     elif isinstance(m,nn.AvgPool2d):
    #         outstr = 'self.features.module[{}]({})'.format(i,outstr)
    #         inp_size = int((inp_size-m.kernel_size[0])/m.stride[0]+1)
    #     elif isinstance(m,nn.ReLU):
    #         outstr = 'self.features.module[{}]({})'.format(i,outstr)
    #         print('        outp = {}'.format(outstr))
    #         outstr = 'outp'
    #         print('        l{}_max_outp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l{}_max_outp)'.format(i,i))
    #         initstr += '        l{}_max_outp = torch.zeros(inp.size(0),1).cuda()\n'.format(i)
    #         returnstr += ',l{}_max_outp'.format(i) 
    #         set1str += ',l{}_max_outp'.format(i) 
    #     else: 
    #         assert False, 'Unrecognized module {}'.format(m)
    # print('        outp = {}'.format(outstr))
    # outstr = 'outp'
    # # Forward statement for reshaping
    # print('        outp = outp.view(outp.size(0), -1)')
    # inp_dim = (inp_dim * inp_size * inp_size)
    # # Forward statement for fully connected-layer
    # for i,m in enumerate(model_rate.classifier):
    #     if isinstance(m,nn.Dropout):
    #         outstr = 'self.classifier[{}]({})'.format(i,outstr)
    #     elif isinstance(m,nn.Linear):
    #         outstr = 'self.classifier[{}]({})'.format(i,outstr)
    #         set3str += ['    c{}_maxw = torch.max(model_seq.classifier[{}].weight)'.format(i,i)]
    #         set3str += ['    scale_factor = torch.max(c{}_hmax_outp, c{}_maxw)'.format(i+1,i)]
    #         set3str += ['    apply_factor = torch.div(scale_factor, prev_factor)']
    #         set3str += ['    model_seq.classifier[{}].weight.data = torch.div(model_seq.classifier[{}].weight, apply_factor)'.format(i,i)]
    #         set3str += ['    prev_factor = scale_factor']
    #     elif isinstance(m,nn.ReLU):
    #         outstr = 'self.classifier[{}]({})'.format(i,outstr)
    #         print('        outp = {}'.format(outstr))
    #         outstr = 'outp'
    #         print('        c{}_max_outp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],c{}_max_outp)'.format(i,i))
    #         initstr += '        c{}_max_outp = torch.zeros(inp.size(0),1).cuda()\n'.format(i)
    #         returnstr += ',c{}_max_outp'.format(i) 
    #         set1str += ',c{}_max_outp'.format(i) 
    #     else: 
    #         assert False, 'Unrecognized module {}'.format(m)
    # print('        outp = {}'.format(outstr))
    # print(returnstr)
    # # Print initialization statement
    # print(initstr)
    # set1str += ' = model_seq(inp)'
    # for each in set2str:
    #     print(set1str)
    # for each in set3str:
    #     print(each)
    # print(list(model_rate.state_dict().keys()))
    # import sys
    # sys.exit(0)

