import argparse
import os
import time
import sys

import numpy as np

import torch
import torch.nn as nn
import torch.nn.parallel
import torch.backends.cudnn as cudnn
import torch.optim
from torchvision import datasets, transforms
from tqdm import tqdm

parser = argparse.ArgumentParser(description='PyTorch Implementation of Abhronil ANN-SNN Conversion Technique - ResNet34 with CIFAR100', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
parser.add_argument('--start_epoch', default=1, type=int, help='starting epoch number (this value is set automatically if resume)')
parser.add_argument('--max_epoch', default=600, type=int, help='number of total epochs to run')
parser.add_argument('--batch_size', default=256, type=int, help='batch size')
parser.add_argument('--learning_rate', default=0.1, type=float, help='initial learning rate')
parser.add_argument('--momentum', default=0.9, type=float, help='momentum')
parser.add_argument('--num_workers', default=40, type=int, help='number of workers')
parser.add_argument('--weight_decay', default=1e-4, type=float, help='weight decay')
parser.add_argument('--resume', default='', type=str, help='path to latest checkpoint')
parser.add_argument('--evaluate', dest='evaluate', action='store_true', help='evaluate model on validation set')
parser.add_argument('--seed', default=10, type=int, help='random seed')
parser.add_argument('--log', default=None, help='log file location')
parser.add_argument('--save_dir', default=None, help='saved directory location')
parser.add_argument('--dt', default=0.001, type=float, help='simulation timestep')
parser.add_argument('--t_end', default=2.500, type=float, help='single example simulation time')
parser.add_argument('--dropout_prob_0', default=0.3, type=float, help='dropout probability of 1st feature')
parser.add_argument('--dropout_prob_1', default=0.3, type=float, help='dropout probability of 2nd feature')
parser.add_argument('--dropout_prob_2', default=0.3, type=float, help='dropout probability of 3rd feature')
parser.add_argument('--dropout_prob_3', default=0.3, type=float, help='dropout probability of other features')
parser.add_argument('--testing', dest='not_testing', action='store_false', help='performa ANN-SNN conversion and spiking simulation if specified')

def main():
    start_time = time.time()

    # Parse argument
    global args
    args = parser.parse_args()
   
    if args.log is None:
        f = sys.stdout
    else:
        f = open(args.log, 'w', buffering=1)

    # Initialize seed and best accuracy
    torch.manual_seed(args.seed)
    torch.cuda.manual_seed_all(args.seed)
    best_prec1 = 0

    # Check the save_dir exists or not
    if (not args.save_dir is None) and (not os.path.exists(args.save_dir)):
        os.makedirs(args.save_dir)

    # Load model and parallelize on GPU
    import model_resnet34_cifar100
    model_rate = model_resnet34_cifar100.ResNetRate([args.dropout_prob_0,args.dropout_prob_1,args.dropout_prob_2,args.dropout_prob_3])
    model_rate = torch.nn.DataParallel(model_rate).cuda()
    f.write(str(model_rate)+'\n')

    # Define loss function (criterion) and optimizer
    criterion = nn.CrossEntropyLoss().cuda()
    optimizer = torch.optim.SGD(model_rate.parameters(), lr=args.learning_rate,
                                momentum=args.momentum,
                                weight_decay=args.weight_decay)

    # Optionally resume from checkpoint
    if args.resume:
        if os.path.isfile(args.resume):
            checkpoint = torch.load(args.resume)
            args.start_epoch = checkpoint['epoch']
            best_prec1 = checkpoint['best_prec1']
            model_rate.load_state_dict(checkpoint['state_dict'])
            optimizer.load_state_dict(checkpoint['optimizer'])
            f.write("=> Load checkpoint from {} (start_epoch={})\n".format(args.resume, checkpoint['epoch']))
        else:
            f.write("=> No checkpoint found at {}\n".format(args.resume))
            sys.exit(0)

    # Set CUDNN to look for optimal running alogrithm 
    cudnn.benchmark = True

    # Normalization function
    class normalize(object):
        def __init__(self, mean, absmax):
            self.mean = mean
            self.absmax = absmax
        def __call__(self, tensor):
            # Args: tensor (Tensor): Tensor image of size (C, H, W) to be normalized.
            # Returns: Tensor: Normalized image.
            for t, m, am in zip(tensor, self.mean, self.absmax):
                t.sub_(m).div_(am)
            return tensor

    # Mean and SD are calculuated by get_dataset_stat.py
    train_transform = transforms.Compose([
        transforms.RandomHorizontalFlip(p=0.5),
        transforms.ToTensor(),
        normalize(mean=[0.4914, 0.4821, 0.4465],absmax=[0.5086, 0.5179, 0.5535])
        ])
    train_set = datasets.CIFAR100(root='./dataset/cifar100', train=True, download=True, transform=train_transform)
    train_loader = torch.utils.data.DataLoader(train_set, batch_size=args.batch_size, shuffle=True, num_workers=args.num_workers, pin_memory=True)
    test_transform = transforms.Compose([
        transforms.ToTensor(),
        normalize(mean=[0.4914, 0.4821, 0.4465],absmax=[0.5086, 0.5179, 0.5535])
        ])
    test_set = datasets.CIFAR100(root='./dataset/cifar100', train=False, transform=test_transform)
    test_loader = torch.utils.data.DataLoader(test_set, batch_size=args.batch_size, shuffle=False, num_workers=args.num_workers, pin_memory=True)
 
    if args.evaluate:
        best_prec1 = 0
        prec1 = validate_rate(test_loader, model_rate, criterion, f)
        is_best = prec1 > best_prec1
        best_prec1 = max(prec1, best_prec1)
    else:
        for epoch in range(args.start_epoch, args.max_epoch+1):
            adjust_learning_rate(optimizer, epoch)

            # Train for one epoch
            train_rate(train_loader, model_rate, criterion, optimizer, epoch, f)
            
            # Evaluate on validation set
            prec1 = validate_rate(test_loader, model_rate, criterion, f)

            # Save checkpoint
            is_best = prec1 > best_prec1
            best_prec1 = max(prec1, best_prec1)
            if (epoch % 50 == 0) and (not args.save_dir is None):
                save_checkpoint({
                    'epoch': epoch + 1,
                    'state_dict': model_rate.state_dict(),
                    'best_prec1': best_prec1,
                    'optimizer' : optimizer.state_dict(),            
                }, is_best, filename=os.path.join(args.save_dir, 'checkpoint_{}.tar'.format(epoch)))

        best_prec1 = 0
        prec1 = validate_rate(test_loader, model_rate, criterion, f)
        is_best = prec1 > best_prec1
        best_prec1 = max(prec1, best_prec1)

    f.write('Summary\t/\tTotal time {:.3f}\t/\tBest prec@1 {:.3f}\n'.format(time.time()-start_time, best_prec1))
    
    if args.not_testing:
        sys.exit(0)

    f.write("==> Testing Abhronil ANN-SNN Conversion:\n")
    # Instantiate spike network
    model_spike = model_resnet34_cifar100.ResNetSpike(dt=args.dt, t_end=args.t_end)
    model_spike = torch.nn.DataParallel(model_spike).cuda()
    f.write(str(model_spike)+'\n')
   
    # Run trained network through training dataset again to find maximum input to IFNeuron 
    weight_mapping = [('module.features.0.weight', 'module.features.1.weight'), ('module.features.3.weight', 'module.features.4.weight'), ('module.features.6.weight', 'module.features.7.weight'), ('module.features.10.delay_path.0.weight', 'module.features.12.weight'), ('module.features.10.delay_path.3.weight', 'module.features.15.weight'), ('module.features.11.delay_path.0.weight', 'module.features.21.weight'), ('module.features.11.delay_path.3.weight', 'module.features.24.weight'), ('module.features.12.delay_path.0.weight', 'module.features.30.weight'), ('module.features.12.delay_path.3.weight', 'module.features.33.weight'), ('module.features.13.delay_path.0.weight', 'module.features.39.weight'), ('module.features.13.delay_path.3.weight', 'module.features.42.weight'), ('module.features.14.delay_path.0.weight', 'module.features.48.weight'), ('module.features.14.delay_path.3.weight', 'module.features.51.weight'), ('module.features.15.delay_path.0.weight', 'module.features.57.weight'), ('module.features.15.delay_path.3.weight', 'module.features.60.weight'), ('module.features.16.delay_path.0.weight', 'module.features.66.weight'), ('module.features.16.delay_path.3.weight', 'module.features.69.weight'), ('module.features.17.delay_path.0.weight', 'module.features.75.weight'), ('module.features.17.delay_path.3.weight', 'module.features.78.weight'), ('module.features.18.delay_path.0.weight', 'module.features.84.weight'), ('module.features.18.delay_path.3.weight', 'module.features.87.weight'), ('module.features.19.delay_path.0.weight', 'module.features.93.weight'), ('module.features.19.delay_path.3.weight', 'module.features.96.weight'), ('module.features.20.delay_path.0.weight', 'module.features.102.weight'), ('module.features.20.delay_path.3.weight', 'module.features.105.weight'), ('module.features.21.delay_path.0.weight', 'module.features.111.weight'), ('module.features.21.delay_path.3.weight', 'module.features.114.weight'), ('module.features.22.delay_path.0.weight', 'module.features.120.weight'), ('module.features.22.delay_path.3.weight', 'module.features.123.weight'), ('module.features.23.delay_path.0.weight', 'module.features.129.weight'), ('module.features.23.delay_path.3.weight', 'module.features.132.weight'), ('module.features.24.delay_path.0.weight', 'module.features.138.weight'), ('module.features.24.delay_path.3.weight', 'module.features.141.weight'), ('module.features.25.delay_path.0.weight', 'module.features.147.weight'), ('module.features.25.delay_path.3.weight', 'module.features.150.weight'), ('module.classifier.0.weight', 'module.classifier.0.weight')]
    model_rate_dict = model_rate.state_dict() 
    model_spike_dict = model_spike.state_dict() 
    for source,target in weight_mapping:
        model_spike_dict[target].copy_(model_rate_dict[source])

    # Normalize threshold value
    start_time = time.time()
    model_spike.eval()
    with torch.no_grad():
        l2_max_inp_ = torch.zeros(1).cuda()
        l5_max_inp_ = torch.zeros(1).cuda()
        l8_max_inp_ = torch.zeros(1).cuda()
        for i, (inp, target) in enumerate(train_loader):
            if i == 4:  break
            outp,l2_max_inp,l5_max_inp,l8_max_inp = model_spike(inp)
            l2_max_inp_ = torch.max(l2_max_inp_,torch.max(l2_max_inp))
        model_spike.module.features[2].set_thres(float(l2_max_inp_))
        f.write('\tl2 threshold balancing {:.3f}\ttime {:.3f}\n'.format(float(torch.max(l2_max_inp)),time.time()-start_time)); start_time = time.time()
        for i, (inp, target) in enumerate(train_loader):
            if i == 4:  break
            outp,l2_max_inp,l5_max_inp,l8_max_inp = model_spike(inp)
            l5_max_inp_ = torch.max(l5_max_inp_,torch.max(l5_max_inp))
        model_spike.module.features[5].set_thres(float(l5_max_inp_))
        f.write('\tl5 threshold balancing {:.3f}\ttime {:.3f}\n'.format(float(torch.max(l5_max_inp)),time.time()-start_time)); start_time = time.time()
        for i, (inp, target) in enumerate(train_loader):
            if i == 4:  break
            outp,l2_max_inp,l5_max_inp,l8_max_inp = model_spike(inp)
            l8_max_inp_ = torch.max(l8_max_inp_,torch.max(l8_max_inp))
        model_spike.module.features[8].set_thres(float(l8_max_inp_))
        f.write('\tl8 threshold balancing {:.3f}\ttime {:.3f}\n'.format(float(torch.max(l8_max_inp)),time.time()-start_time)); start_time = time.time()

    # model_spike.module.features[2].set_thres(18.478)
    # model_spike.module.features[5].set_thres(4.801)
    # model_spike.module.features[8].set_thres(4.758)
    
    # Evaluate on validation set
    validate_spike(test_loader, model_spike, criterion, f)

    if not args.log is None:
        f.close()

def train_rate(train_loader, model, criterion, optimizer, epoch, f):
    """
        Run one train epoch
    """
    # switch to train mode
    model.train()

    start_time = time.time()
    acc_top1 = []
    acc_top5 = []
    acc_loss = []

    f.write('Epoch {:>3}\n'.format(epoch))
    for i, (inp, target) in enumerate(train_loader):
        target = target.cuda(non_blocking=True)

        # compute outp
        outp = model(inp)
        loss = criterion(outp, target)

        # measure accuracy and record loss
        prec1, prec5 = accuracy(outp, target, topk=(1, 5))
        acc_top1.append(float(prec1))
        acc_top5.append(float(prec5))
        acc_loss.append(float(loss))

        # compute gradient and do SGD step
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        
        if i%1000==0:
            f.write('\t({}/{})\tTime {:.3f}\tPrec@1 {:.3f}\tPrec@5 {:.3f}\tLoss {:.3f}\n'.format(i, len(train_loader), time.time()-start_time, np.mean(acc_top1), np.mean(acc_top5), np.mean(acc_loss)))
            start_time = time.time()

    f.write('\tSummary:\tPrec@1 {:.3f}\tPrec@5 {:.3f}\tLoss {:.3f}\t'.format(np.mean(acc_top1), np.mean(acc_top5), np.mean(acc_loss)))

def validate_spike(test_loader, model, criterion, f):
    """
    Run evaluation
    """
    # switch to evaluate mode
    model.eval()
    
    start_time = time.time()
    acc_top1 = []
    acc_top5 = []

    with torch.no_grad():
        for i, (inp, target) in enumerate(tqdm(test_loader)):
            target = target.cuda(non_blocking=True)
            outp,l2_max_inp,l5_max_inp,l8_max_inp = model(inp)
            loss = criterion(outp, target)

            # measure accuracy and record loss
            prec1, prec5 = accuracy(outp, target, topk=(1, 5))
            acc_top1.append(float(prec1))
            acc_top5.append(float(prec5))
            
            if (i!=0) and (i%2==0):         
                f.write('\tTest {:>5} :\tTime {:.3f}\tPrec@1 {:.3f}\tPrec@5 {:.3f}\n'.format(i, time.time()-start_time, np.mean(acc_top1), np.mean(acc_top5)))
        f.write('\tTest {:>5} :\tTime {:.3f}\tPrec@1 {:.3f}\tPrec@5 {:.3f}\n'.format(i, time.time()-start_time, np.mean(acc_top1), np.mean(acc_top5)))

    return np.mean(acc_top1)

def validate_rate(test_loader, model, criterion, f):
    """
    Run evaluation
    """
    # switch to evaluate mode
    model.eval()
    
    start_time = time.time()
    acc_top1 = []
    acc_top5 = []

    with torch.no_grad():
        for i, (inp, target) in enumerate(test_loader):
            target = target.cuda(non_blocking=True)

            # compute outp
            outp = model(inp)
            loss = criterion(outp, target)

            # measure accuracy and record loss
            prec1, prec5 = accuracy(outp, target, topk=(1, 5))
            acc_top1.append(float(prec1))
            acc_top5.append(float(prec5))

    f.write('/\tTest:\tTime {:.3f}\tPrec@1 {:.3f}\tPrec@5 {:.3f}\n'.format(time.time()-start_time, np.mean(acc_top1), np.mean(acc_top5)))

    return np.mean(acc_top1)

def save_checkpoint(state, is_best, filename='checkpoint.tar'):
    """
    Save the training model
    """
    torch.save(state, filename)

def adjust_learning_rate(optimizer, cur_epoch):
    # Reduce learning rate by 10 twice at epoch 81 and 122
    if cur_epoch == 100 or cur_epoch == 200 or cur_epoch == 300 or cur_epoch == 400:
        for param_group in optimizer.param_groups:
            param_group['lr'] /= 10


def accuracy(outp, target, topk=(1,)):
    """Computes the precision@k for the specified values of k"""
    with torch.no_grad():
        maxk = max(topk)
        batch_size = target.size(0)

        _, pred = outp.topk(maxk, 1, True, True)
        pred = pred.t()
        correct = pred.eq(target.view(1, -1).expand_as(pred))

        res = []
        for k in topk:
            correct_k = correct[:k].view(-1).float().sum(0, keepdim=True)
            res.append(correct_k.mul_(100.0 / batch_size))
        return res

if __name__ == '__main__':
    main()
