
import torch
import torch.nn as nn
import math

# Poisson spike generator
#   This module generates spike based on assumption that input is between 1 and -1
#   Positive spike is generated (i.e. 1 is return) if rand()<abs(input) and sign(input)=1
#   Negative spike is generated (i.e. -1 is return) if rand()<abs(input) and sign(input)=-1
#   This method is corresponding to Method 1 on Page 5 of lecture note http://www.cns.nyu.edu/~david/handouts/poisson.pdf
class PoissonGen(nn.Module):
    def __init__(self):
        super(PoissonGen, self).__init__()
    def forward(self, inp):
        return torch.mul(torch.le(torch.rand_like(inp), torch.abs(inp)).float(), torch.sign(inp))

# Integrate-and-fire neuron (IFNeuron)
#   This module is slightly from IFNeuron module in the script that I have sent to Gopal and Priya earlier.
#   This module models simple IFNeuron without any refractory period
#   This modeule does not have state information, thus allowing it to be parallelized across GPUs when torch.nn.DataParallel is wrapped around
#   As a result, this module takes two arguments: input and previous IFNeuron membrane potential
#   Spike is generated if IFNeuron membrane potential reachs defined threshold
#   Spike output is return with new IFNeuron membrane potential
class IFNeuron(nn.Module):
    # Argument inplace does not have any use. You can ignore it. 
    def __init__(self, inplace=True, thres=1.0):
        super(IFNeuron, self).__init__()
        self.thres = thres
    def forward(self, inp, mem_potential):
        mem_potential += inp
        outp = torch.ge(mem_potential, self.thres)
        mem_potential[outp] = 0.0
        return outp.float(), mem_potential 
    def set_thres(self, thres):
        self.thres = thres
    def get_thres(self):
        return self.thres
    def extra_repr(self):
        return 'thres={}'.format(self.thres)

# Identity module
#   This module returns whatever it recieves
class Identity(nn.Module):
    def __init__(self):
        super(Identity, self).__init__()
    def forward(self, inp):
        return inp

# Following are dummy modules
#   Those modules do not have any function
class DelayMark(nn.Module):
    def __init__(self):
        super(DelayMark, self).__init__()
class ResidueMark(nn.Module):
    def __init__(self):
        super(ResidueMark, self).__init__()
class MergeMark0(nn.Module):
    def __init__(self):
        super(MergeMark0, self).__init__()
class MergeMark1(nn.Module):
    def __init__(self):
        super(MergeMark1, self).__init__()

# Basic block in ResNet-20
class BasicBlock1(nn.Module):
    def __init__(self, in_channels, out_channels, stride, dropout_prob):
        super(BasicBlock1, self).__init__()
        # Construct delay path
        self.delay_path = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=(3,3), stride=(stride,stride), padding=(1,1), bias=False),
            nn.ReLU(),
            nn.Dropout(p=dropout_prob),
            nn.Conv2d(out_channels, out_channels, kernel_size=(3,3), stride=(1,1), padding=(1,1), bias=False)
        )
        # Construt residue path
        self.residual_path = Identity()
        self.relu = nn.ReLU(inplace=True)
    def forward(self, inp):
        # Output of basic block is sum of value from residue path and delay path
        outp = self.delay_path(inp)
        outp += self.residual_path(inp)
        outp = self.relu(outp)
        return outp

class BasicBlock0(nn.Module):
    def __init__(self, in_channels, out_channels, stride, dropout_prob):
        super(BasicBlock0, self).__init__()
        # Construct delay path
        self.delay_path = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=(3,3), stride=(stride,stride), padding=(1,1), bias=False),
            nn.ReLU(),
            nn.Dropout(p=dropout_prob),
            nn.Conv2d(out_channels, out_channels, kernel_size=(3,3), stride=(1,1), padding=(1,1), bias=False)
        )
        # Construt residue path
        self.residual_path = nn.AvgPool2d(kernel_size=(1,1), stride=(stride,stride), padding=(0,0))
        self.relu = nn.ReLU(inplace=True)
        self.pad_channels = out_channels - in_channels
    def forward(self, inp):
        # Output of basic block is sum of value from residue path and delay path
        outp = self.delay_path(inp)
        outp_res = self.delay_path(inp)
        outp += torch.cat((self.residual_path(inp),torch.zeros(inp.size(0), self.pad_channels, outp.size(2), outp.size(3)).cuda()), 1)
        outp = self.relu(outp)
        return outp

# Make basic block in specially for spiking ResNet
#   forward path of ResNet will be automatically generated with script in __main__ 
def make_basic_block(is_spike, in_channels, out_channels, stride, dropout_prob):
    if is_spike:
        delay_path = [nn.Conv2d(in_channels, out_channels, kernel_size=(3,3), stride=(stride,stride), padding=(1,1), bias=False),
                IFNeuron(inplace=True),
                nn.Dropout(p=dropout_prob),
                nn.Conv2d(out_channels, out_channels, kernel_size=(3,3), stride=(1,1), padding=(1,1), bias=False)]
        if in_channels == out_channels:
            residual_path = [Identity()]
            return [ResidueMark()] + delay_path + [DelayMark()] + residual_path + [MergeMark1()] + [IFNeuron(inplace=True)]
        else:
            residual_path = [nn.AvgPool2d(kernel_size=(1,1), stride=(stride,stride), padding=(0,0))]
            return [ResidueMark()] + delay_path + [DelayMark()] + residual_path + [MergeMark0()] + [IFNeuron(inplace=True)]
    else:
        if in_channels == out_channels:
            return [BasicBlock1(in_channels, out_channels, stride, dropout_prob)]
        else:
            return [BasicBlock0(in_channels, out_channels, stride, dropout_prob)]

# Function to create convolutional layer
#   When is_spike=False, this function creates convolutional layer for rate-based ResNet
#   When is_spike=True, this function creates convolutional layer for spiking ResNet
def make_features(is_spike, dropout_prob_list):
    list_m = []
    in_channels = 3
    if is_spike:
        list_m.append(PoissonGen())
        act_func = IFNeuron
    else:
        act_func = nn.ReLU
    list_m += [nn.Conv2d(in_channels, 64, kernel_size=(3,3), stride=(2,2), padding=(1,1), bias=False)]
    list_m += [act_func(inplace=True)]
    list_m += [nn.Dropout(p=dropout_prob_list[0])]
    list_m += [nn.Conv2d(64, 64, kernel_size=(3,3), stride=(1,1), padding=(1,1), bias=False)]
    list_m += [act_func(inplace=True)]
    list_m += [nn.Dropout(p=dropout_prob_list[1])]
    list_m += [nn.Conv2d(64, 64, kernel_size=(3,3), stride=(1,1), padding=(1,1), bias=False)]
    list_m += [act_func(inplace=True)]
    list_m += [nn.Dropout(p=dropout_prob_list[2])]
    list_m += [nn.AvgPool2d(kernel_size=(3,3), stride=(2,2), padding=(1,1))]
    in_channels = 64

    for out_channels,strides,nblock in zip([64, 128, 256, 512],[1, 2, 2, 2], [3, 4, 6, 3]):
        strides = [strides] + [1]*(nblock-1)
        for j,stride in zip(range(nblock),strides):
            list_m.extend(make_basic_block(is_spike, in_channels, out_channels, stride, dropout_prob_list[3]))
            in_channels = out_channels
    # list_m += [nn.AvgPool2d(kernel_size=(1,1), stride=(1,1))]
    return make_hierarchy(list_m,is_spike)

# Make fully connected layer 
#   When is_spike=False, this function creates fully-connected layer for rate-based ResNet network
#   When is_spike=True, this function creates fully-connected layer for spiking ResNet network 
def make_classifier(is_spike):
    list_m = []
    list_m += [nn.Linear(512, 100, bias=False)]
    return make_hierarchy(list_m,is_spike)

# Convert list of modules into torch.nn.ModuleList or torch.nn.Sequentual
#   For spiking simulation, we prefer modules to be stacked in torch.nn.ModuleList because output of modules are accessed at multiple points
#   During threshold balancing, we, for example, need to get maximum input to a particular IFNeuron. Having module in torch.nn.Sequential does allow us to access intermediate values easily 
def make_hierarchy(list_m,is_spike):
    if is_spike:
        return nn.ModuleList(list_m)
    else:
        return nn.Sequential(*list_m)

# Spiking version of simple network
class ResNetSpike(nn.Module):
    def __init__(self, dt=0.001, t_end=2.000, dropout_prob_list=[0.1,0.1,0.1,0.1]):
        super(ResNetSpike, self).__init__()
        # Save network parameters
        self.dt = dt
        self.t_end = t_end
        # Instantiate layers
        self.features = make_features(is_spike=True, dropout_prob_list=dropout_prob_list)
        self.classifier = make_classifier(is_spike=True)
    def forward(self, inp):
        # Code in this forward function is automatically generated by running this script
        #   $ python model_resnet34_imagenet.py
        # XX_mem_potential stores membrane potential of IFNeuron at layer XX
        # XX_max_inp stores maximum input to IFNeuon at layer XX
        outp_sum = torch.zeros(inp.size(0),100).cuda()
        l2_mem_potential = torch.zeros(inp.size(0),64,32,32).cuda()
        l2_max_inp = torch.zeros(inp.size(0),1).cuda()
        l5_mem_potential = torch.zeros(inp.size(0),64,32,32).cuda()
        l5_max_inp = torch.zeros(inp.size(0),1).cuda()
        l8_mem_potential = torch.zeros(inp.size(0),64,32,32).cuda()
        l8_max_inp = torch.zeros(inp.size(0),1).cuda()
        l13_mem_potential = torch.zeros(inp.size(0),64,16,16).cuda()
        l19_mem_potential = torch.zeros(inp.size(0),64,16,16).cuda()
        l22_mem_potential = torch.zeros(inp.size(0),64,16,16).cuda()
        l28_mem_potential = torch.zeros(inp.size(0),64,16,16).cuda()
        l31_mem_potential = torch.zeros(inp.size(0),64,16,16).cuda()
        l37_mem_potential = torch.zeros(inp.size(0),64,16,16).cuda()
        l40_mem_potential = torch.zeros(inp.size(0),128,8,8).cuda()
        l46_mem_potential = torch.zeros(inp.size(0),128,8,8).cuda()
        l49_mem_potential = torch.zeros(inp.size(0),128,8,8).cuda()
        l55_mem_potential = torch.zeros(inp.size(0),128,8,8).cuda()
        l58_mem_potential = torch.zeros(inp.size(0),128,8,8).cuda()
        l64_mem_potential = torch.zeros(inp.size(0),128,8,8).cuda()
        l67_mem_potential = torch.zeros(inp.size(0),128,8,8).cuda()
        l73_mem_potential = torch.zeros(inp.size(0),128,8,8).cuda()
        l76_mem_potential = torch.zeros(inp.size(0),256,4,4).cuda()
        l82_mem_potential = torch.zeros(inp.size(0),256,4,4).cuda()
        l85_mem_potential = torch.zeros(inp.size(0),256,4,4).cuda()
        l91_mem_potential = torch.zeros(inp.size(0),256,4,4).cuda()
        l94_mem_potential = torch.zeros(inp.size(0),256,4,4).cuda()
        l100_mem_potential = torch.zeros(inp.size(0),256,2,2).cuda()
        l103_mem_potential = torch.zeros(inp.size(0),256,2,2).cuda()
        l109_mem_potential = torch.zeros(inp.size(0),256,2,2).cuda()
        l112_mem_potential = torch.zeros(inp.size(0),256,2,2).cuda()
        l118_mem_potential = torch.zeros(inp.size(0),256,2,2).cuda()
        l121_mem_potential = torch.zeros(inp.size(0),256,2,2).cuda()
        l127_mem_potential = torch.zeros(inp.size(0),256,2,2).cuda()
        l130_mem_potential = torch.zeros(inp.size(0),512,1,1).cuda()
        l136_mem_potential = torch.zeros(inp.size(0),512,1,1).cuda()
        l139_mem_potential = torch.zeros(inp.size(0),512,1,1).cuda()
        l145_mem_potential = torch.zeros(inp.size(0),512,1,1).cuda()
        l148_mem_potential = torch.zeros(inp.size(0),512,1,1).cuda()
        l154_mem_potential = torch.zeros(inp.size(0),512,1,1).cuda()
        for j in range(int(self.t_end/self.dt)):
            outp = self.features[1](self.features[0](inp))
            l2_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l2_max_inp)
            outp,l2_mem_potential = self.features[2](outp,l2_mem_potential)
            outp = self.features[4](self.features[3](outp))
            l5_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l5_max_inp)
            outp,l5_mem_potential = self.features[5](outp,l5_mem_potential)
            outp = self.features[7](self.features[6](outp))
            l8_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l8_max_inp)
            outp,l8_mem_potential = self.features[8](outp,l8_mem_potential)
            outp = self.features[10](self.features[9](outp))
            outp_r = self.features[12](outp)
            outp_r,l13_mem_potential = self.features[13](outp_r,l13_mem_potential)
            outp_r = self.features[15](self.features[14](outp_r))
            outp_d = self.features[17](outp)
            outp = torch.add(outp_d, outp_r)
            outp,l19_mem_potential = self.features[19](outp,l19_mem_potential)
            outp_r = self.features[21](outp)
            outp_r,l22_mem_potential = self.features[22](outp_r,l22_mem_potential)
            outp_r = self.features[24](self.features[23](outp_r))
            outp_d = self.features[26](outp)
            outp = torch.add(outp_d, outp_r)
            outp,l28_mem_potential = self.features[28](outp,l28_mem_potential)
            outp_r = self.features[30](outp)
            outp_r,l31_mem_potential = self.features[31](outp_r,l31_mem_potential)
            outp_r = self.features[33](self.features[32](outp_r))
            outp_d = self.features[35](outp)
            outp = torch.add(outp_d, outp_r)
            outp,l37_mem_potential = self.features[37](outp,l37_mem_potential)
            outp_r = self.features[39](outp)
            outp_r,l40_mem_potential = self.features[40](outp_r,l40_mem_potential)
            outp_r = self.features[42](self.features[41](outp_r))
            outp_d = torch.cat((self.features[44](outp),torch.zeros(outp_r.size(0),64,outp_r.size(2),outp_r.size(3)).cuda()),1)
            outp = torch.add(outp_d, outp_r)
            outp,l46_mem_potential = self.features[46](outp,l46_mem_potential)
            outp_r = self.features[48](outp)
            outp_r,l49_mem_potential = self.features[49](outp_r,l49_mem_potential)
            outp_r = self.features[51](self.features[50](outp_r))
            outp_d = self.features[53](outp)
            outp = torch.add(outp_d, outp_r)
            outp,l55_mem_potential = self.features[55](outp,l55_mem_potential)
            outp_r = self.features[57](outp)
            outp_r,l58_mem_potential = self.features[58](outp_r,l58_mem_potential)
            outp_r = self.features[60](self.features[59](outp_r))
            outp_d = self.features[62](outp)
            outp = torch.add(outp_d, outp_r)
            outp,l64_mem_potential = self.features[64](outp,l64_mem_potential)
            outp_r = self.features[66](outp)
            outp_r,l67_mem_potential = self.features[67](outp_r,l67_mem_potential)
            outp_r = self.features[69](self.features[68](outp_r))
            outp_d = self.features[71](outp)
            outp = torch.add(outp_d, outp_r)
            outp,l73_mem_potential = self.features[73](outp,l73_mem_potential)
            outp_r = self.features[75](outp)
            outp_r,l76_mem_potential = self.features[76](outp_r,l76_mem_potential)
            outp_r = self.features[78](self.features[77](outp_r))
            outp_d = torch.cat((self.features[80](outp),torch.zeros(outp_r.size(0),128,outp_r.size(2),outp_r.size(3)).cuda()),1)
            outp = torch.add(outp_d, outp_r)
            outp,l82_mem_potential = self.features[82](outp,l82_mem_potential)
            outp_r = self.features[84](outp)
            outp_r,l85_mem_potential = self.features[85](outp_r,l85_mem_potential)
            outp_r = self.features[87](self.features[86](outp_r))
            outp_d = self.features[89](outp)
            outp = torch.add(outp_d, outp_r)
            outp,l91_mem_potential = self.features[91](outp,l91_mem_potential)
            outp_r = self.features[93](outp)
            outp_r,l94_mem_potential = self.features[94](outp_r,l94_mem_potential)
            outp_r = self.features[96](self.features[95](outp_r))
            outp_d = self.features[98](outp)
            outp = torch.add(outp_d, outp_r)
            outp,l100_mem_potential = self.features[100](outp,l100_mem_potential)
            outp_r = self.features[102](outp)
            outp_r,l103_mem_potential = self.features[103](outp_r,l103_mem_potential)
            outp_r = self.features[105](self.features[104](outp_r))
            outp_d = self.features[107](outp)
            outp = torch.add(outp_d, outp_r)
            outp,l109_mem_potential = self.features[109](outp,l109_mem_potential)
            outp_r = self.features[111](outp)
            outp_r,l112_mem_potential = self.features[112](outp_r,l112_mem_potential)
            outp_r = self.features[114](self.features[113](outp_r))
            outp_d = self.features[116](outp)
            outp = torch.add(outp_d, outp_r)
            outp,l118_mem_potential = self.features[118](outp,l118_mem_potential)
            outp_r = self.features[120](outp)
            outp_r,l121_mem_potential = self.features[121](outp_r,l121_mem_potential)
            outp_r = self.features[123](self.features[122](outp_r))
            outp_d = self.features[125](outp)
            outp = torch.add(outp_d, outp_r)
            outp,l127_mem_potential = self.features[127](outp,l127_mem_potential)
            outp_r = self.features[129](outp)
            outp_r,l130_mem_potential = self.features[130](outp_r,l130_mem_potential)
            outp_r = self.features[132](self.features[131](outp_r))
            outp_d = torch.cat((self.features[134](outp),torch.zeros(outp_r.size(0),256,outp_r.size(2),outp_r.size(3)).cuda()),1)
            outp = torch.add(outp_d, outp_r)
            outp,l136_mem_potential = self.features[136](outp,l136_mem_potential)
            outp_r = self.features[138](outp)
            outp_r,l139_mem_potential = self.features[139](outp_r,l139_mem_potential)
            outp_r = self.features[141](self.features[140](outp_r))
            outp_d = self.features[143](outp)
            outp = torch.add(outp_d, outp_r)
            outp,l145_mem_potential = self.features[145](outp,l145_mem_potential)
            outp_r = self.features[147](outp)
            outp_r,l148_mem_potential = self.features[148](outp_r,l148_mem_potential)
            outp_r = self.features[150](self.features[149](outp_r))
            outp_d = self.features[152](outp)
            outp = torch.add(outp_d, outp_r)
            outp,l154_mem_potential = self.features[154](outp,l154_mem_potential)
            outp = self.features[155](outp)
            outp = outp.view(outp.size(0), -1)
            outp = self.classifier[0](outp)
            outp_sum += outp
        return outp_sum,l2_max_inp,l5_max_inp,l8_max_inp

# Rate version of simple network
class ResNetRate(nn.Module):
    def __init__(self, dropout_prob_list=[0.1,0.1,0.1,0.1]):
        super(ResNetRate, self).__init__()
        # Instantiate layers
        self.features = make_features(is_spike=False, dropout_prob_list=dropout_prob_list)
        self.classifier = make_classifier(is_spike=False)
        print('Dropout Probability: {}'.format(dropout_prob_list))
        # Initialize weights in the MSR style (http://arxiv.org/pdf/1502.01852v1.pdf) which is more suitable for deep network than Xavier initialization (default initialization of convolutional layer in PyTorch)
        self.initialize_weights()
    def forward(self, inp):
        outp = self.features(inp)
        outp = outp.view(outp.size(0), -1)
        outp = self.classifier(outp)
        return outp
    def initialize_weights(self):
        # Initialize all convolutional layers
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                m.weight.data.normal_(0, math.sqrt(2./n))
                if m.bias is not None:
                    m.bias.data.zero_()
        # Reinitialize convolutional residual layer 
        for m in self.modules():
            if isinstance(m, BasicBlock0) or isinstance(m, BasicBlock1):
                for sm in m.modules():
                    if isinstance(sm, nn.Conv2d):
                        n = sm.kernel_size[0] * sm.kernel_size[1] * sm.out_channels
                        sm.weight.data.normal_(0, math.sqrt(2.)/float(n))
                        if sm.bias is not None:
                            sm.bias.data.zero_()

if __name__ == '__main__':

    # Test rate model with random input (batchsize of 4)
    inp = torch.rand(4,3,32,32) 
    print('-'*40)
    # Instantiate rate-baed ResNet model and parallelize model across GPUs, but only for convolutional layers (check this out https://arxiv.org/pdf/1404.5997.pdf)
    model_rate = ResNetRate()
    model_rate = torch.nn.DataParallel(model_rate).cuda()
    # Print model
    print(model_rate)
    # Compute output
    outp = model_rate(inp)
    print('Test successful!')
    
    # Test spiking model with random input (batchsize of 4)
    print('-'*40)
    # Instantiate spiking ResNet model and parallel model across multiple GPUs
    model_spike = ResNetSpike()
    model_spike = torch.nn.DataParallel(model_spike).cuda()
    # Print model
    print(model_spike)
    # Compute output
    model_spike.eval()
    with torch.no_grad():
        outp = model_spike(inp)
    print('Test successful!')

    # Automatically generate weight mapping list and forward statement
    print('-'*40)
    # After training rate-based model, weight of convolutional layers in the rate-based model is copied to that in the spiking model
    print(len(list(model_rate.state_dict().keys())))
    print(len(list(model_spike.state_dict().keys())))
    print(list(zip(list(model_rate.state_dict().keys()),list(model_spike.state_dict().keys()))))
    # Forward statement for spiking model
    print()
    print('    for j in range(int(self.t_end/self.dt)):')
    inp_dim = 3
    inp_size = 32
    pad_dim = None
    outstr = 'inp'
    initstr = '    outp_sum = torch.zeros(inp.size(0),10).cuda()\n'
    returnstr = '    return outp_sum'
    set1str = '    outp'
    set2str = []
    conv_count = 0
    delay_path = False
    residue_path = False
    # Forward statement for convolutional layers
    for i,m in enumerate(model_spike.module.features):
        if isinstance(m,PoissonGen):
            outstr = 'self.features[{}]({})'.format(i,outstr)
        elif isinstance(m,ResidueMark):
            if outstr != 'outp':
                print('        outp = {}'.format(outstr))
                outstr = 'outp'
            residue_path = True
            rpathstr = 'outp'
        elif isinstance(m,DelayMark):
            residue_path = False
            delay_path = True
            dpathstr = 'outp'
        elif isinstance(m,MergeMark1):
            delay_path = False
            print('        outp_r = {}'.format(rpathstr))
            print('        outp_d = {}'.format(dpathstr))
            print('        outp = torch.add(outp_d, outp_r)')
        elif isinstance(m,MergeMark0):
            delay_path = False
            print('        outp_r = {}'.format(rpathstr))
            print('        outp_d = torch.cat(({},torch.zeros(outp_r.size(0),{},outp_r.size(2),outp_r.size(3)).cuda()),1)'.format(dpathstr,pad_dim))
            print('        outp = torch.add(outp_d, outp_r)')
        elif isinstance(m,nn.Conv2d):
            if residue_path:
                if int(m.in_channels) != int(m.out_channels):
                    pad_dim = int(m.out_channels) - int(m.in_channels)
                inp_dim = int(m.out_channels)
                inp_size = math.floor((inp_size-m.kernel_size[0]+2*m.padding[0])/m.stride[0])+1
                rpathstr = 'self.features[{}]({})'.format(i,rpathstr)
            else:
                inp_dim = int(m.out_channels)
                inp_size = math.floor((inp_size-m.kernel_size[0]+2*m.padding[0])/m.stride[0])+1
                outstr = 'self.features[{}]({})'.format(i,outstr)
        elif isinstance(m,Identity):
            dpathstr = 'self.features[{}]({})'.format(i,dpathstr)
        elif isinstance(m,nn.Dropout):
            if residue_path: 
                rpathstr = 'self.features[{}]({})'.format(i,rpathstr)
            else: 
                outstr = 'self.features[{}]({})'.format(i,outstr)
        elif isinstance(m,nn.AvgPool2d):
            if delay_path: 
                dpathstr = 'self.features[{}]({})'.format(i,dpathstr)
            else:
                outstr = 'self.features[{}]({})'.format(i,outstr)
                inp_size = int((inp_size-m.kernel_size[0])/m.stride[0]+1)
        elif isinstance(m,IFNeuron):
            if residue_path: 
                # rpathstr = 'self.features[{}]({})'.format(i,rpathstr)
                print('        outp_r = {}'.format(rpathstr))
                rpathstr = 'outp_r'
                print('        outp_r,l{}_mem_potential = self.features[{}](outp_r,l{}_mem_potential)'.format(i,i,i))
                initstr += '    l{}_mem_potential = torch.zeros(inp.size(0),{},{},{}).cuda()\n'.format(i,inp_dim,inp_size,inp_size)
            else:
                if outstr != 'outp':
                    print('        outp = {}'.format(outstr))
                    outstr = 'outp'
                if conv_count < 3:
                    print('        l{}_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l{}_max_inp)'.format(i,i))
                    print('        outp,l{}_mem_potential = self.features[{}](outp,l{}_mem_potential)'.format(i,i,i))
                    initstr += '    l{}_mem_potential = torch.zeros(inp.size(0),{},{},{}).cuda()\n'.format(i,inp_dim,inp_size,inp_size)
                    initstr += '    l{}_max_inp = torch.zeros(inp.size(0),1).cuda()\n'.format(i)
                    returnstr += ',l{}_max_inp'.format(i) 
                    set1str += ',l{}_max_inp'.format(i) 
                    set2str.append('model_spike.module.features[{}].set_thres(float(torch.max(l{}_max_inp)))\n'.format(i,i))
                    conv_count += 1
                else:
                    print('        outp,l{}_mem_potential = self.features[{}](outp,l{}_mem_potential)'.format(i,i,i))
                    initstr += '    l{}_mem_potential = torch.zeros(inp.size(0),{},{},{}).cuda()\n'.format(i,inp_dim,inp_size,inp_size)

        else: 
            assert False, 'Unrecognized module {}'.format(m)
    print('        outp = {}'.format(outstr))
    # Forward statement for reshaping
    outstr = 'outp'
    print('        outp = outp.view(outp.size(0), -1)')
    inp_dim = (inp_dim * inp_size * inp_size)
    # Forward statement for fully connected-layer
    for i,m in enumerate(model_spike.module.classifier):
        if isinstance(m,nn.Linear):
            outstr = 'self.classifier[{}]({})'.format(i,outstr)
        else: 
            assert False, 'Unrecognized module {}'.format(m)
    print('        outp = {}'.format(outstr))
    print('        outp_sum += outp')
    print()
    print(returnstr)
    # Print initialization statement
    print(initstr)
    print()
    set1str += ' = model_spike(inp)'
    for each in set2str:
        print(set1str)
        print(each)
