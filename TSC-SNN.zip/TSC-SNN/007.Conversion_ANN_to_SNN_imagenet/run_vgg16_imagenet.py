import argparse
import os
import time
import sys

import numpy as np

import torch
import torch.nn as nn
import torch.nn.parallel
import torch.backends.cudnn as cudnn
import torch.optim
from torchvision import datasets, transforms
from tqdm import tqdm

parser = argparse.ArgumentParser(description='PyTorch Implementation of Abhronil ANN-SNN Conversion Technique - VGG16 with ImageNet', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
parser.add_argument('-d', '--dataset', default='/local/scratch/a/imagenet/imagenet2012', type=str)
# parser.add_argument('-d', '--dataset', default='/local/scratch/a/sarwar/imagenet2012', type=str)
# parser.add_argument('-d', '--dataset', default='/media/bing/Research/001.Simulation_Frameworks/dataset/imagenet2012', type=str)
# parser.add_argument('-d', '--dataset', default='/home/bing/Documents/001.Simulation_Frameworks/Project_7_Temporal_SNNs_Conversion/004.Training_BP_DeepConvNet/data/imagenet2012', type=str)
parser.add_argument('--start_epoch', default=1, type=int, help='starting epoch number (this value is set automatically if resume)')
parser.add_argument('--max_epoch', default=200, type=int, help='number of total epochs to run')
parser.add_argument('--batch_size', default=200, type=int, help='batch size')
parser.add_argument('--learning_rate', default=0.05, type=float, help='initial learning rate')
parser.add_argument('--momentum', default=0.9, type=float, help='momentum')
parser.add_argument('--num_workers', default=40, type=int, help='number of workers')
parser.add_argument('--weight_decay', default=1e-4, type=float, help='weight decay')
parser.add_argument('--resume', default='', type=str, help='path to latest checkpoint')
parser.add_argument('--evaluate', dest='evaluate', action='store_true', help='evaluate model on validation set')
parser.add_argument('--seed', default=0, type=int, help='random seed')
parser.add_argument('--log', default=None, help='log file location')
parser.add_argument('--save_dir', default=None, help='saved directory location')
parser.add_argument('--dt', default=0.001, type=float, help='simulation timestep')
parser.add_argument('--t_end', default=2.500, type=float, help='single example simulation time')

parser.add_argument('--gpu_id', default='0,1,2,3', type=str, help='id(s) for CUDA_VISIBLE_DEVICES')
parser.add_argument('--vth_vb', default=0.73, type=float, help='Spiking Neurons Threshold Value')
parser.add_argument('--vth_vu', default=0.0, type=float, help='Spiking Neurons Threshold Value')
parser.add_argument('--snn_fpi', default=64, type=int, help='Number of frames per input image')
parser.add_argument('--snn_TTS', default=128, type=int, help='Simulation timesteps per example')
parser.add_argument('--snn_mode', default='full', type=str, help='full or acc')
parser.add_argument('--if_mode', default='if', type=str, help='if or residual')
parser.add_argument('--in_coding', default='rate', type=str, help='Input encoding scheme for SNN')

def main():
    start_time = time.time()

    # Parse argument
    global args
    args = parser.parse_args()
   
    os.environ['CUDA_VISIBLE_DEVICES'] = args.gpu_id
    use_cuda = torch.cuda.is_available()

    if args.log is None:
        f = sys.stdout
    else:
        f = open(args.log, 'w', buffering=1)

    # Initialize seed and best accuracy
    torch.manual_seed(args.seed)
    torch.cuda.manual_seed_all(args.seed)
    best_prec1 = 0

    # Check the save_dir exists or not
    if (not args.save_dir is None) and (not os.path.exists(args.save_dir)):
        os.makedirs(args.save_dir)

    # Load model and parallelize on GPU
    import model_vgg16_imagenet
    model_rate = model_vgg16_imagenet.VGGRate()
    model_rate.features = torch.nn.DataParallel(model_rate.features)
    model_rate.cuda()
    f.write(str(model_rate)+'\n')

    # Define loss function (criterion) and optimizer
    criterion = nn.CrossEntropyLoss().cuda()
    optimizer = torch.optim.SGD(model_rate.parameters(), lr=args.learning_rate,
                                momentum=args.momentum,
                                weight_decay=args.weight_decay)

    # Optionally resume from checkpoint
    if args.resume:
        if os.path.isfile(args.resume):
            checkpoint = torch.load(args.resume)
            args.start_epoch = checkpoint['epoch']
            # best_prec1 = checkpoint['best_prec1']
            model_rate.load_state_dict(checkpoint['state_dict'])
            optimizer.load_state_dict(checkpoint['optimizer'])
            f.write("=> Load checkpoint from {} (start_epoch={})\n".format(args.resume, checkpoint['epoch']))
        else:
            f.write("=> No checkpoint found at {}\n".format(args.resume))
            sys.exit(0)

    # Set CUDNN to look for optimal running alogrithm 
    cudnn.benchmark = True

    # Normalization function
    class normalize(object):
        def __init__(self, mean, absmax):
            self.mean = mean
            self.absmax = absmax
        def __call__(self, tensor):
            # Args: tensor (Tensor): Tensor image of size (C, H, W) to be normalized.
            # Returns: Tensor: Normalized image.
            for t, m, am in zip(tensor, self.mean, self.absmax):
                t.sub_(m).div_(am)
            return tensor

    # Mean and SD are calculuated by get_dataset_stat.py
    train_transform = transforms.Compose([
        transforms.RandomResizedCrop(224),
        transforms.RandomHorizontalFlip(p=0.5),
        transforms.ToTensor(),
        normalize(mean=[0.4827, 0.4522, 0.4008],absmax=[0.5173, 0.5478, 0.5992])
        ])
    train_dir = os.path.join(args.dataset, 'train')
    train_set = datasets.ImageFolder(train_dir, transform=train_transform)
    train_loader = torch.utils.data.DataLoader(train_set, batch_size=args.batch_size, shuffle=True, num_workers=args.num_workers, pin_memory=True)
    test_transform = transforms.Compose([
        transforms.Resize(256),
        transforms.CenterCrop(224),
        transforms.ToTensor(),
        normalize(mean=[0.4827, 0.4522, 0.4008],absmax=[0.5173, 0.5478, 0.5992])
        ])
    test_dir = os.path.join(args.dataset, 'val')
    test_set = datasets.ImageFolder(test_dir, transform=test_transform)
    test_loader = torch.utils.data.DataLoader(test_set, batch_size=args.batch_size, shuffle=False, num_workers=args.num_workers, pin_memory=True) 

    if args.evaluate:
        best_prec1 = 0
        prec1 = validate_rate(test_loader, model_rate, criterion, f)
        is_best = prec1 > best_prec1
        best_prec1 = max(prec1, best_prec1)
    else:
        for epoch in range(args.start_epoch, args.max_epoch+1):
            adjust_learning_rate(optimizer, epoch)

            # Train for one epoch
            train_rate(train_loader, model_rate, criterion, optimizer, epoch, f)
            
            # Evaluate on validation set
            prec1 = validate_rate(test_loader, model_rate, criterion, f)

            # Save checkpoint
            is_best = prec1 > best_prec1
            best_prec1 = max(prec1, best_prec1)
            if (epoch % 20 == 0) and (not args.save_dir is None):
                save_checkpoint({
                    'epoch': epoch + 1,
                    'state_dict': model_rate.state_dict(),
                    'best_prec1': best_prec1,
                    'optimizer' : optimizer.state_dict(),            
                }, is_best, filename=os.path.join(args.save_dir, 'checkpoint_{}.tar'.format(epoch)))

        best_prec1 = 0
        prec1 = validate_rate(test_loader, model_rate, criterion, f)
        is_best = prec1 > best_prec1
        best_prec1 = max(prec1, best_prec1)

    f.write('Summary\t/\tTotal time {:.3f}\t/\tBest prec@1 {:.3f}\n'.format(time.time()-start_time, best_prec1))
    
    f.write("==> Testing Bing's ANN-SNN Conversion:\n")
   
    # Run trained network through training dataset again to find maximum input to IFNeuron 
    weight_mapping = [('features.module.0.weight', 'module.features.1.weight'), 
                      ('features.module.2.weight', 'module.features.3.weight'),
                      ('features.module.5.weight', 'module.features.6.weight'), 
                      ('features.module.7.weight', 'module.features.8.weight'),
                      ('features.module.10.weight', 'module.features.11.weight'), 
                      ('features.module.12.weight', 'module.features.13.weight'),
                      ('features.module.14.weight', 'module.features.15.weight'), 
                      ('features.module.17.weight', 'module.features.18.weight'),
                      ('features.module.19.weight', 'module.features.20.weight'), 
                      ('features.module.21.weight', 'module.features.22.weight'),
                      ('features.module.24.weight', 'module.features.25.weight'), 
                      ('features.module.26.weight', 'module.features.27.weight'),
                      ('features.module.28.weight', 'module.features.29.weight'), 
                      ('classifier.0.weight', 'module.classifier.0.weight'),
                      ('classifier.3.weight', 'module.classifier.3.weight'),
                      ('classifier.6.weight', 'module.classifier.6.weight')]

    # Normalize threshold value
    # Following lines are generated automatically from model_vgg16_cifar10.py

    V_b = args.vth_vb
    V_u = args.vth_vu
    
    """ 
    # Instantiate spike_probe network for normalizing threshold values
    model_spike_probe = model_vgg16_imagenet.VGGSpike(dt=args.dt, t_end=args.t_end, in_coding='rate', snn_mode='full', if_mode='if', TTS=args.snn_TTS, fpi=args.snn_TTS)
    model_spike_probe = torch.nn.DataParallel(model_spike_probe).cuda()
    f.write(str(model_spike_probe)+'\n')

    model_rate_dict = model_rate.state_dict() 
    model_spike_probe_dict = model_spike_probe.state_dict() 
    for source,target in weight_mapping:
        model_spike_probe_dict[target].copy_(model_rate_dict[source])

    # Normalize threshold value
    # Following lines are generated automatically from model_vgg16_cifar10.py
    start_time = time.time()
    model_spike_probe.eval()
    with torch.no_grad():
        l2_max_inp_ = torch.zeros(1).cuda()
        l4_max_inp_ = torch.zeros(1).cuda()
        l7_max_inp_ = torch.zeros(1).cuda()
        l9_max_inp_ = torch.zeros(1).cuda()
        l12_max_inp_ = torch.zeros(1).cuda()
        l14_max_inp_ = torch.zeros(1).cuda()
        l16_max_inp_ = torch.zeros(1).cuda()
        l19_max_inp_ = torch.zeros(1).cuda()
        l21_max_inp_ = torch.zeros(1).cuda()
        l23_max_inp_ = torch.zeros(1).cuda()
        l26_max_inp_ = torch.zeros(1).cuda()
        l28_max_inp_ = torch.zeros(1).cuda()
        l30_max_inp_ = torch.zeros(1).cuda()
        fc1_max_inp_ = torch.zeros(1).cuda()
        fc4_max_inp_ = torch.zeros(1).cuda()
        
        for i, (inp, target) in enumerate(train_loader):
            if i == 4:  break
            outp,l2_max_inp,l4_max_inp,l7_max_inp,l9_max_inp,l12_max_inp,l14_max_inp,l16_max_inp,l19_max_inp,l21_max_inp,l23_max_inp,l26_max_inp,l28_max_inp,l30_max_inp,fc1_max_inp,fc4_max_inp,spike_count = model_spike_probe(inp)
            l2_max_inp_ = torch.max(l2_max_inp_,torch.max(l2_max_inp))
        model_spike_probe.module.features[2].set_thres(float(l2_max_inp_))
        f.write('\tl2 threshold balancing {:.3f}\ttime {:.3f}\n'.format(float(torch.max(l2_max_inp_)),time.time()-start_time)); start_time = time.time()
        
        for i, (inp, target) in enumerate(train_loader):
            if i == 4:  break
            outp,l2_max_inp,l4_max_inp,l7_max_inp,l9_max_inp,l12_max_inp,l14_max_inp,l16_max_inp,l19_max_inp,l21_max_inp,l23_max_inp,l26_max_inp,l28_max_inp,l30_max_inp,fc1_max_inp,fc4_max_inp,spike_count = model_spike_probe(inp)
            l4_max_inp_ = torch.max(l4_max_inp_,torch.max(l4_max_inp))
        model_spike_probe.module.features[4].set_thres(float(l4_max_inp_))
        f.write('\tl4 threshold balancing {:.3f}\ttime {:.3f}\n'.format(float(torch.max(l4_max_inp_)),time.time()-start_time)); start_time = time.time()
        
        for i, (inp, target) in enumerate(train_loader):
            if i == 4:  break
            outp,l2_max_inp,l4_max_inp,l7_max_inp,l9_max_inp,l12_max_inp,l14_max_inp,l16_max_inp,l19_max_inp,l21_max_inp,l23_max_inp,l26_max_inp,l28_max_inp,l30_max_inp,fc1_max_inp,fc4_max_inp,spike_count = model_spike_probe(inp)
            l7_max_inp_ = torch.max(l7_max_inp_,torch.max(l7_max_inp))
        model_spike_probe.module.features[7].set_thres(float(l7_max_inp_))
        f.write('\tl7 threshold balancing {:.3f}\ttime {:.3f}\n'.format(float(torch.max(l7_max_inp_)),time.time()-start_time)); start_time = time.time()
        
        for i, (inp, target) in enumerate(train_loader):
            if i == 4:  break
            outp,l2_max_inp,l4_max_inp,l7_max_inp,l9_max_inp,l12_max_inp,l14_max_inp,l16_max_inp,l19_max_inp,l21_max_inp,l23_max_inp,l26_max_inp,l28_max_inp,l30_max_inp,fc1_max_inp,fc4_max_inp,spike_count = model_spike_probe(inp)
            l9_max_inp_ = torch.max(l9_max_inp_,torch.max(l9_max_inp))
        model_spike_probe.module.features[9].set_thres(float(l9_max_inp_))
        f.write('\tl9 threshold balancing {:.3f}\ttime {:.3f}\n'.format(float(torch.max(l9_max_inp_)),time.time()-start_time)); start_time = time.time()
        
        for i, (inp, target) in enumerate(train_loader):
            if i == 4:  break
            outp,l2_max_inp,l4_max_inp,l7_max_inp,l9_max_inp,l12_max_inp,l14_max_inp,l16_max_inp,l19_max_inp,l21_max_inp,l23_max_inp,l26_max_inp,l28_max_inp,l30_max_inp,fc1_max_inp,fc4_max_inp,spike_count = model_spike_probe(inp)
            l12_max_inp_ = torch.max(l12_max_inp_,torch.max(l12_max_inp))
        model_spike_probe.module.features[12].set_thres(float(l12_max_inp_))
        f.write('\tl12 threshold balancing {:.3f}\ttime {:.3f}\n'.format(float(torch.max(l12_max_inp_)),time.time()-start_time)); start_time = time.time()
        
        for i, (inp, target) in enumerate(train_loader):
            if i == 4:  break
            outp,l2_max_inp,l4_max_inp,l7_max_inp,l9_max_inp,l12_max_inp,l14_max_inp,l16_max_inp,l19_max_inp,l21_max_inp,l23_max_inp,l26_max_inp,l28_max_inp,l30_max_inp,fc1_max_inp,fc4_max_inp,spike_count = model_spike_probe(inp)
            l14_max_inp_ = torch.max(l14_max_inp_,torch.max(l14_max_inp))
        model_spike_probe.module.features[14].set_thres(float(l14_max_inp_))
        f.write('\tl14 threshold balancing {:.3f}\ttime {:.3f}\n'.format(float(torch.max(l14_max_inp_)),time.time()-start_time)); start_time = time.time()
        
        for i, (inp, target) in enumerate(train_loader):
            if i == 4:  break
            outp,l2_max_inp,l4_max_inp,l7_max_inp,l9_max_inp,l12_max_inp,l14_max_inp,l16_max_inp,l19_max_inp,l21_max_inp,l23_max_inp,l26_max_inp,l28_max_inp,l30_max_inp,fc1_max_inp,fc4_max_inp,spike_count = model_spike_probe(inp)
            l16_max_inp_ = torch.max(l16_max_inp_,torch.max(l16_max_inp))
        model_spike_probe.module.features[16].set_thres(float(l16_max_inp_))
        f.write('\tl16 threshold balancing {:.3f}\ttime {:.3f}\n'.format(float(torch.max(l16_max_inp_)),time.time()-start_time)); start_time = time.time()
        
        for i, (inp, target) in enumerate(train_loader):
            if i == 4:  break
            outp,l2_max_inp,l4_max_inp,l7_max_inp,l9_max_inp,l12_max_inp,l14_max_inp,l16_max_inp,l19_max_inp,l21_max_inp,l23_max_inp,l26_max_inp,l28_max_inp,l30_max_inp,fc1_max_inp,fc4_max_inp,spike_count = model_spike_probe(inp)
            l19_max_inp_ = torch.max(l19_max_inp_,torch.max(l19_max_inp))
        model_spike_probe.module.features[19].set_thres(float(l19_max_inp_))
        f.write('\tl19 threshold balancing {:.3f}\ttime {:.3f}\n'.format(float(torch.max(l19_max_inp_)),time.time()-start_time)); start_time = time.time()
        
        for i, (inp, target) in enumerate(train_loader):
            if i == 4:  break
            outp,l2_max_inp,l4_max_inp,l7_max_inp,l9_max_inp,l12_max_inp,l14_max_inp,l16_max_inp,l19_max_inp,l21_max_inp,l23_max_inp,l26_max_inp,l28_max_inp,l30_max_inp,fc1_max_inp,fc4_max_inp,spike_count = model_spike_probe(inp)
            l21_max_inp_ = torch.max(l21_max_inp_,torch.max(l21_max_inp))
        model_spike_probe.module.features[21].set_thres(float(l21_max_inp_))
        f.write('\tl21 threshold balancing {:.3f}\ttime {:.3f}\n'.format(float(torch.max(l21_max_inp_)),time.time()-start_time)); start_time = time.time()
        
        for i, (inp, target) in enumerate(train_loader):
            if i == 4:  break
            outp,l2_max_inp,l4_max_inp,l7_max_inp,l9_max_inp,l12_max_inp,l14_max_inp,l16_max_inp,l19_max_inp,l21_max_inp,l23_max_inp,l26_max_inp,l28_max_inp,l30_max_inp,fc1_max_inp,fc4_max_inp,spike_count = model_spike_probe(inp)
            l23_max_inp_ = torch.max(l23_max_inp_,torch.max(l23_max_inp))
        model_spike_probe.module.features[23].set_thres(float(l23_max_inp_))
        f.write('\tl23 threshold balancing {:.3f}\ttime {:.3f}\n'.format(float(torch.max(l23_max_inp_)),time.time()-start_time)); start_time = time.time()
        
        for i, (inp, target) in enumerate(train_loader):
            if i == 4:  break
            outp,l2_max_inp,l4_max_inp,l7_max_inp,l9_max_inp,l12_max_inp,l14_max_inp,l16_max_inp,l19_max_inp,l21_max_inp,l23_max_inp,l26_max_inp,l28_max_inp,l30_max_inp,fc1_max_inp,fc4_max_inp,spike_count = model_spike_probe(inp)
            l26_max_inp_ = torch.max(l26_max_inp_,torch.max(l26_max_inp))
        model_spike_probe.module.features[26].set_thres(float(l26_max_inp_))
        f.write('\tl26 threshold balancing {:.3f}\ttime {:.3f}\n'.format(float(torch.max(l26_max_inp_)),time.time()-start_time)); start_time = time.time()
        
        for i, (inp, target) in enumerate(train_loader):
            if i == 4:  break
            outp,l2_max_inp,l4_max_inp,l7_max_inp,l9_max_inp,l12_max_inp,l14_max_inp,l16_max_inp,l19_max_inp,l21_max_inp,l23_max_inp,l26_max_inp,l28_max_inp,l30_max_inp,fc1_max_inp,fc4_max_inp,spike_count = model_spike_probe(inp)
            l28_max_inp_ = torch.max(l28_max_inp_,torch.max(l28_max_inp))
        model_spike_probe.module.features[28].set_thres(float(l28_max_inp_))
        f.write('\tl28 threshold balancing {:.3f}\ttime {:.3f}\n'.format(float(torch.max(l28_max_inp_)),time.time()-start_time)); start_time = time.time()
        
        for i, (inp, target) in enumerate(train_loader):
            if i == 4:  break
            outp,l2_max_inp,l4_max_inp,l7_max_inp,l9_max_inp,l12_max_inp,l14_max_inp,l16_max_inp,l19_max_inp,l21_max_inp,l23_max_inp,l26_max_inp,l28_max_inp,l30_max_inp,fc1_max_inp,fc4_max_inp,spike_count = model_spike_probe(inp)
            l30_max_inp_ = torch.max(l30_max_inp_,torch.max(l30_max_inp))
        model_spike_probe.module.features[30].set_thres(float(l30_max_inp_))
        f.write('\tl30 threshold balancing {:.3f}\ttime {:.3f}\n'.format(float(torch.max(l30_max_inp_)),time.time()-start_time)); start_time = time.time()
               
        for i, (inp, target) in enumerate(train_loader):
            if i == 4:  break
            outp,l2_max_inp,l4_max_inp,l7_max_inp,l9_max_inp,l12_max_inp,l14_max_inp,l16_max_inp,l19_max_inp,l21_max_inp,l23_max_inp,l26_max_inp,l28_max_inp,l30_max_inp,fc1_max_inp,fc4_max_inp,spike_count = model_spike_probe(inp)
            fc1_max_inp_ = torch.max(fc1_max_inp_,torch.max(fc1_max_inp))
        model_spike_probe.module.classifier[1].set_thres(float(fc1_max_inp_))
        f.write('\tfc1 threshold balancing {:.3f}\ttime {:.3f}\n'.format(float(torch.max(fc1_max_inp_)),time.time()-start_time)); start_time = time.time()
       
        for i, (inp, target) in enumerate(train_loader):
            if i == 4:  break
            outp,l2_max_inp,l4_max_inp,l7_max_inp,l9_max_inp,l12_max_inp,l14_max_inp,l16_max_inp,l19_max_inp,l21_max_inp,l23_max_inp,l26_max_inp,l28_max_inp,l30_max_inp,fc1_max_inp,fc4_max_inp,spike_count = model_spike_probe(inp)
            fc4_max_inp_ = torch.max(fc4_max_inp_,torch.max(fc4_max_inp))
        model_spike_probe.module.classifier[4].set_thres(float(fc4_max_inp_))
        f.write('\tfc4 threshold balancing {:.3f}\ttime {:.3f}\n'.format(float(torch.max(fc4_max_inp_)),time.time()-start_time)); start_time = time.time()
    """

    
    print('Use pre-computed thresholds for SNN')
    if args.snn_TTS <= 256:
        l2_max_inp_ = 13.495
        l4_max_inp_ = 10.127
        l7_max_inp_ = 2.676
        l9_max_inp_ = 3.669
        l12_max_inp_ = 1.053
        l14_max_inp_ = 1.879
        l16_max_inp_ = 2.36
        l19_max_inp_ = 0.779
        l21_max_inp_ = 1.213
        l23_max_inp_ = 1.002
        l26_max_inp_ = 0.339
        l28_max_inp_ = 0.792
        l30_max_inp_ = 0.351
        fc1_max_inp_ = 0.071
        fc4_max_inp_ = 0.285 

    elif args.snn_TTS == 512:
        l2_max_inp_ = 13.178 
        l4_max_inp_ = 10.383
        l7_max_inp_ = 2.539
        l9_max_inp_ = 3.957
        l12_max_inp_ = 1.274
        l14_max_inp_ = 2.051
        l16_max_inp_ = 2.505
        l19_max_inp_ = 0.826
        l21_max_inp_ = 1.408
        l23_max_inp_ = 1.151
        l26_max_inp_ = 0.395
        l28_max_inp_ = 0.94
        l30_max_inp_ = 0.772
        fc1_max_inp_ = 0.041
        fc4_max_inp_ = 0.335

    elif args.snn_TTS == 768:
        l2_max_inp_ = 13.196
        l4_max_inp_ = 10.3
        l7_max_inp_ = 2.532
        l9_max_inp_ = 3.876
        l12_max_inp_ = 1.443
        l14_max_inp_ = 1.869
        l16_max_inp_ = 2.348
        l19_max_inp_ = 0.773
        l21_max_inp_ = 1.254
        l23_max_inp_ = 1.304
        l26_max_inp_ = 0.482
        l28_max_inp_ = 0.826
        l30_max_inp_ = 0.85
        fc1_max_inp_ = 0.044
        fc4_max_inp_ = 1.143

    elif args.snn_TTS == 1024:
        l2_max_inp_ = 13.332
        l4_max_inp_ = 10.502
        l7_max_inp_ = 2.394
        l9_max_inp_ = 3.929
        l12_max_inp_ = 1.293
        l14_max_inp_ = 2.236
        l16_max_inp_ = 2.622
        l19_max_inp_ = 0.726
        l21_max_inp_ = 1.4
        l23_max_inp_ = 1.129
        l26_max_inp_ = 0.566
        l28_max_inp_ = 0.95
        l30_max_inp_ = 0.846 
        fc1_max_inp_ = 0.042
        fc4_max_inp_ = 0.79

    elif args.snn_TTS == 1536:
        l2_max_inp_ = 13.332
        l4_max_inp_ = 10.413
        l7_max_inp_ = 3.017
        l9_max_inp_ = 3.539
        l12_max_inp_ = 1.448
        l14_max_inp_ = 2.162
        l16_max_inp_ = 2.32
        l19_max_inp_ = 0.796
        l21_max_inp_ = 1.302
        l23_max_inp_ = 1.22
        l26_max_inp_ = 0.468
        l28_max_inp_ = 1.011
        l30_max_inp_ = 0.901
        fc1_max_inp_ = 0.046
        fc4_max_inp_ = 0.771

    elif args.snn_TTS == 2048:
        l2_max_inp_ = 13.298
        l4_max_inp_ = 10.529
        l7_max_inp_ = 2.49
        l9_max_inp_ = 3.744
        l12_max_inp_ = 1.508
        l14_max_inp_ = 2.236
        l16_max_inp_ = 2.312 
        l19_max_inp_ = 0.766
        l21_max_inp_ = 1.377
        l23_max_inp_ = 1.211
        l26_max_inp_ = 0.506
        l28_max_inp_ = 1.054
        l30_max_inp_ = 0.897
        fc1_max_inp_ = 0.051
        fc4_max_inp_ = 0.783

    elif args.snn_TTS == 2560:
        l2_max_inp_ = 13.287
        l4_max_inp_ = 10.538
        l7_max_inp_ = 2.372
        l9_max_inp_ = 4.39
        l12_max_inp_ = 1.458
        l14_max_inp_ = 2.109
        l16_max_inp_ = 2.409
        l19_max_inp_ = 0.766
        l21_max_inp_ = 1.334
        l23_max_inp_ = 1.298
        l26_max_inp_ = 0.521
        l28_max_inp_ = 0.977
        l30_max_inp_ = 0.882
        fc1_max_inp_ = 0.043
        fc4_max_inp_ = 0.445

    elif args.snn_TTS == 3072:
        l2_max_inp_ = 13.303
        l4_max_inp_ = 10.522
        l7_max_inp_ = 2.643
        l9_max_inp_ = 3.953
        l12_max_inp_ = 1.427
        l14_max_inp_ = 2.248
        l16_max_inp_ = 2.544
        l19_max_inp_ = 0.983
        l21_max_inp_ = 1.259
        l23_max_inp_ = 1.454
        l26_max_inp_ = 0.5
        l28_max_inp_ = 0.927
        l30_max_inp_ = 0.907
        fc1_max_inp_ = 0.045
        fc4_max_inp_ = 1.017

    elif args.snn_TTS == 4096:
        l2_max_inp_ = 13.522
        l4_max_inp_ = 10.151
        l7_max_inp_ = 2.54
        l9_max_inp_ = 4.717
        l12_max_inp_ = 1.49
        l14_max_inp_ = 2.476
        l16_max_inp_ = 2.394
        l19_max_inp_ = 0.787
        l21_max_inp_ = 1.409
        l23_max_inp_ = 1.238
        l26_max_inp_ = 0.516
        l28_max_inp_ = 1.021
        l30_max_inp_ = 0.907
        fc1_max_inp_ = 0.046
        fc4_max_inp_ = 0.942

    f.write('\tl2 threshold balancing {:.3f} \n '.format(float(l2_max_inp_)))
    f.write('\tl4 threshold balancing {:.3f} \n '.format(float(l4_max_inp_)))
    f.write('\tl7 threshold balancing {:.3f} \n '.format(float(l7_max_inp_)))
    f.write('\tl9 threshold balancing {:.3f} \n '.format(float(l9_max_inp_)))
    f.write('\tl12 threshold balancing {:.3f} \n'.format(float(l12_max_inp_)))
    f.write('\tl14 threshold balancing {:.3f} \n '.format(float(l14_max_inp_)))
    f.write('\tl16 threshold balancing {:.3f} \n '.format(float(l16_max_inp_)))
    f.write('\tl19 threshold balancing {:.3f} \n '.format(float(l19_max_inp_)))
    f.write('\tl21 threshold balancing {:.3f} \n '.format(float(l21_max_inp_)))
    f.write('\tl23 threshold balancing {:.3f} \n '.format(float(l23_max_inp_)))
    f.write('\tl26 threshold balancing {:.3f} \n '.format(float(l26_max_inp_)))
    f.write('\tl28 threshold balancing {:.3f} \n '.format(float(l28_max_inp_)))
    f.write('\tl30 threshold balancing {:.3f} \n '.format(float(l30_max_inp_)))
    f.write('\tfc1 threshold balancing {:.3f} \n '.format(float(fc1_max_inp_)))
    f.write('\tfc4 threshold balancing {:.3f} \n '.format(float(fc4_max_inp_)))
    

    model_spike = model_vgg16_imagenet.VGGSpike(dt=args.dt, t_end=args.t_end, in_coding=args.in_coding, snn_mode=args.snn_mode, if_mode=args.if_mode, TTS=args.snn_TTS, fpi=args.snn_fpi)
    model_spike = torch.nn.DataParallel(model_spike).cuda()
    model_rate_dict = model_rate.state_dict()
    model_spike_dict = model_spike.state_dict()
    for source,target in weight_mapping:
        model_spike_dict[target].copy_(model_rate_dict[source])

    # Set threshold value manually
    model_spike.module.features[2].set_thres(l2_max_inp_*V_b+V_u)
    model_spike.module.features[4].set_thres(l4_max_inp_*V_b+V_u)
    model_spike.module.features[7].set_thres(l7_max_inp_*V_b+V_u)
    model_spike.module.features[9].set_thres(l9_max_inp_*V_b+V_u)
    model_spike.module.features[12].set_thres(l12_max_inp_*V_b+V_u)
    model_spike.module.features[14].set_thres(l14_max_inp_*V_b+V_u)
    model_spike.module.features[16].set_thres(l16_max_inp_*V_b+V_u)
    model_spike.module.features[19].set_thres(l19_max_inp_*V_b+V_u)
    model_spike.module.features[21].set_thres(l21_max_inp_*V_b+V_u)
    model_spike.module.features[23].set_thres(l23_max_inp_*V_b+V_u)
    model_spike.module.features[26].set_thres(l26_max_inp_*V_b+V_u)
    model_spike.module.features[28].set_thres(l28_max_inp_*V_b+V_u)
    model_spike.module.features[30].set_thres(l30_max_inp_*V_b+V_u)
    model_spike.module.classifier[1].set_thres(fc1_max_inp_*V_b+V_u)
    model_spike.module.classifier[4].set_thres(fc4_max_inp_*V_b+V_u)

    f.write(str(model_spike)+'\n')

    # Evaluate on validation set
    validate_spike(test_loader, model_spike, criterion, f)

    if not args.log is None:
        f.close()

def train_rate(train_loader, model, criterion, optimizer, epoch, f):
    """
        Run one train epoch
    """
    # switch to train mode
    model.train()

    start_time = time.time()
    acc_top1 = []
    acc_top5 = []
    acc_loss = []

    for i, (inp, target) in enumerate(train_loader):
        inp = inp.cuda(non_blocking=True)
        target = target.cuda(non_blocking=True)

        # compute outp
        outp = model(inp)
        loss = criterion(outp, target)

        # measure accuracy and record loss
        prec1, prec5 = accuracy(outp, target, topk=(1, 5))
        acc_top1.append(float(prec1))
        acc_top5.append(float(prec5))
        acc_loss.append(float(loss))

        # compute gradient and do SGD step
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

    f.write('Epoch {:>3}\t/\tTrain:\tTime {:.3f}\tPrec@1 {:.3f}\tPrec@5 {:.3f}\tLoss {:.3f}\t'.format(epoch,time.time()-start_time, np.mean(acc_top1), np.mean(acc_top5), np.mean(acc_loss)))

def validate_spike(test_loader, model, criterion, f):
    """
    Run evaluation
    """
    # switch to evaluate mode
    model.eval()
    
    start_time = time.time()
    acc_top1 = []
    acc_top5 = []
    spike_count = []

    inp_neuron_count = 224*224*3
    l2_neuron_count = 64*224*224
    l4_neuron_count = 64*224*224
    l7_neuron_count = 128*112*112
    l9_neuron_count = 128*112*112
    l12_neuron_count = 256*56*56
    l14_neuron_count = 256*56*56
    l16_neuron_count = 256*56*56
    l19_neuron_count = 512*28*28
    l21_neuron_count = 512*28*28
    l23_neuron_count = 512*28*28
    l26_neuron_count = 512*14*14
    l28_neuron_count = 512*14*14
    l30_neuron_count = 512*14*14
    fc1_neuron_count = 4096
    fc4_neuron_count = 4096
    spike_total = torch.zeros(1,200).cuda()

    with torch.no_grad():
        for i, (inp, target) in enumerate(tqdm(test_loader)):
            target = target.cuda(non_blocking=True)
            outp,l2_max_inp,l4_max_inp,l7_max_inp,l9_max_inp,l12_max_inp,l14_max_inp,l16_max_inp,l19_max_inp,l21_max_inp,l23_max_inp,l26_max_inp,l28_max_inp,l30_max_inp,fc1_max_inp,fc4_max_inp,spike_count = model(inp)
            loss = criterion(outp, target)
            # measure accuracy and record loss
            prec1, prec5 = accuracy(outp, target, topk=(1, 5))
            acc_top1.append(float(prec1))
            acc_top5.append(float(prec5))
            spike_total += torch.sum(spike_count, dim=0)
            
            if (i!=0) and (i%25==0):
                f.write('\tTest {:>5} :\tTime {:.3f}\tPrec@1 {:.3f}\tPrec@5 {:.3f}\n'.format(i, time.time()-start_time, np.mean(acc_top1), np.mean(acc_top5)))

        f.write('\t*****************************************************************************\n')
        f.write('\tSummary:\tTotal Time {:.3f}\tPrec@1 {:.3f}\tPrec@5 {:.3f}\n'.format(time.time()-start_time, np.mean(acc_top1), np.mean(acc_top5)))

        f.write('\t*****************************************************************************\n')
        f.write('\tFull-Frame Temporal RMP-SNN spike activities:\n')
        f.write('\tLayer IN   spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format( spike_total[0,1]/50000., inp_neuron_count))
        f.write('\tLayer  2   spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format( spike_total[0,2]/50000., l2_neuron_count))
        f.write('\tLayer  4   spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format( spike_total[0,4]/50000., l4_neuron_count))
        f.write('\tLayer  7   spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format( spike_total[0,7]/50000., l7_neuron_count))
        f.write('\tLayer  9   spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format( spike_total[0,9]/50000., l9_neuron_count))
        f.write('\tLayer 12   spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,12]/50000., l12_neuron_count))
        f.write('\tLayer 14   spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,14]/50000., l14_neuron_count))
        f.write('\tLayer 16   spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,16]/50000., l16_neuron_count))
        f.write('\tLayer 19   spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,19]/50000., l19_neuron_count))
        f.write('\tLayer 21   spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,21]/50000., l21_neuron_count))
        f.write('\tLayer 23   spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,23]/50000., l23_neuron_count))
        f.write('\tLayer 26   spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,26]/50000., l26_neuron_count))
        f.write('\tLayer 28   spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,28]/50000., l28_neuron_count))
        f.write('\tLayer 30   spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,30]/50000., l30_neuron_count))
        f.write('\tLayer fc1  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,41]/50000., fc1_neuron_count))
        f.write('\tLayer fc4  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,44]/50000., fc4_neuron_count))

        f.write('\t*****************************************************************************\n')
        f.write('\tDelta-Frame Temporal RMP-SNN spike activities:\n')
        f.write('\tLayer IN   spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,101]/50000., inp_neuron_count))
        f.write('\tLayer  2   spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,102]/50000., l2_neuron_count))
        f.write('\tLayer  4   spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,104]/50000., l4_neuron_count))
        f.write('\tLayer  7   spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,107]/50000., l7_neuron_count))
        f.write('\tLayer  9   spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,109]/50000., l9_neuron_count))
        f.write('\tLayer 12   spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,112]/50000., l12_neuron_count))
        f.write('\tLayer 14   spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,114]/50000., l14_neuron_count))
        f.write('\tLayer 16   spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,116]/50000., l16_neuron_count))
        f.write('\tLayer 19   spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,119]/50000., l19_neuron_count))
        f.write('\tLayer 21   spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,121]/50000., l21_neuron_count))
        f.write('\tLayer 23   spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,123]/50000., l23_neuron_count))
        f.write('\tLayer 26   spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,126]/50000., l26_neuron_count))
        f.write('\tLayer 28   spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,128]/50000., l28_neuron_count))
        f.write('\tLayer 30   spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,130]/50000., l30_neuron_count))
        f.write('\tLayer fc1  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,141]/50000., fc1_neuron_count))
        f.write('\tLayer fc4  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,144]/50000., fc4_neuron_count))

    return np.mean(acc_top1)

def validate_rate(test_loader, model, criterion, f):
    """
    Run evaluation
    """
    # switch to evaluate mode
    model.eval()
    
    start_time = time.time()
    acc_top1 = []
    acc_top5 = []

    with torch.no_grad():
        for i, (inp, target) in enumerate(test_loader):

            inp = inp.cuda(non_blocking=True)
            target = target.cuda(non_blocking=True)

            # compute outp
            # outp = model(inp)

            outp = model.features.module[0](inp)
            outp = model.features.module[1](outp)
            outp = model.features.module[2](outp)

            outp = model.features.module[3](outp)
            outp = model.features.module[4](outp)
            outp = model.features.module[5](outp)

            outp = model.features.module[6](outp)
            outp = model.features.module[7](outp)
            outp = model.features.module[8](outp)

            outp = model.features.module[9](outp)
            outp = model.features.module[10](outp)
            outp = model.features.module[11](outp)

            outp = model.features.module[12](outp)
            outp = model.features.module[13](outp)
            outp = model.features.module[14](outp)

            outp = model.features.module[15](outp)
            outp = model.features.module[16](outp)
            outp = model.features.module[17](outp)

            outp = model.features.module[18](outp)
            outp = model.features.module[19](outp)
            outp = model.features.module[20](outp)

            outp = model.features.module[21](outp)
            outp = model.features.module[22](outp)
            outp = model.features.module[23](outp)

            outp = model.features.module[24](outp)
            outp = model.features.module[25](outp)
            outp = model.features.module[26](outp)

            outp = model.features.module[27](outp)
            outp = model.features.module[28](outp)
            outp = model.features.module[29](outp)
            outp = model.features.module[30](outp)

            outp = outp.view(outp.size(0), -1)
            outp = model.classifier(outp)

            loss = criterion(outp, target)

            # measure accuracy and record loss
            prec1, prec5 = accuracy(outp, target, topk=(1, 5))
            acc_top1.append(float(prec1))
            acc_top5.append(float(prec5))

    f.write('/\tTest:\tTime {:.3f}\tPrec@1 {:.3f}\tPrec@5 {:.3f}\n'.format(time.time()-start_time, np.mean(acc_top1), np.mean(acc_top5)))

    return np.mean(acc_top1)

def save_checkpoint(state, is_best, filename='checkpoint.tar'):
    """
    Save the training model
    """
    torch.save(state, filename)

def adjust_learning_rate(optimizer, cur_epoch):
    # Reduce learning rate by 10 twice at epoch 81 and 122
    if cur_epoch == 81 or cur_epoch == 122:
        for param_group in optimizer.param_groups:
            param_group['lr'] /= 10


def accuracy(outp, target, topk=(1,)):
    """Computes the precision@k for the specified values of k"""
    with torch.no_grad():
        maxk = max(topk)
        batch_size = target.size(0)

        _, pred = outp.topk(maxk, 1, True, True)
        pred = pred.t()
        correct = pred.eq(target.view(1, -1).expand_as(pred))

        res = []
        for k in topk:
            correct_k = correct[:k].view(-1).float().sum(0, keepdim=True)
            res.append(correct_k.mul_(100.0 / batch_size))
        return res

if __name__ == '__main__':
    main()
