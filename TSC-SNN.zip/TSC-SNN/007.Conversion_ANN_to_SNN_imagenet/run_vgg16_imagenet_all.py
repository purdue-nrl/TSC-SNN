import argparse
import os
import time
import sys

import numpy as np

import torch
import torch.nn as nn
import torch.nn.parallel
import torch.backends.cudnn as cudnn
import torch.optim
from torchvision import datasets, transforms
from tqdm import tqdm

parser = argparse.ArgumentParser(description='Comparison of ANN-SNN Conversion Techniques - VGG16_bn with IMAGENET', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
parser.add_argument('-d', '--data', default='/local/scratch/a/imagenet/imagenet2012', type=str)
# parser.add_argument('-d', '--data', default='/local/scratch/a/sarwar/imagenet2012', type=str)
# parser.add_argument('-d', '--data', default='/media/bing/Research/001.Simulation_Frameworks/Project_7_Temporal_SNNs_Conversion/004.Training_BP_DeepConvNet/data/imagenet2012', type=str)
parser.add_argument('--start_epoch', default=1, type=int, help='starting epoch number (this value is set automatically if resume)')
parser.add_argument('--max_epoch', default=400, type=int, help='number of total epochs to run')
parser.add_argument('--train_batch', default=8, type=int, help='batch size')
parser.add_argument('--test_batch', default=8, type=int, help='batch size')
parser.add_argument('--batch_size', default=8, type=int, help='batch size')
parser.add_argument('--learning_rate', default=0.1, type=float, help='initial learning rate')
parser.add_argument('--momentum', default=0.9, type=float, help='momentum')
parser.add_argument('--num_workers', default=16, type=int, help='number of workers')
parser.add_argument('--weight_decay', default=1e-4, type=float, help='weight decay')
parser.add_argument('--resume', default='', type=str, help='path to latest checkpoint')
parser.add_argument('--evaluate', dest='evaluate', action='store_true', help='evaluate model on validation set')
parser.add_argument('--seed', default=0, type=int, help='random seed')
parser.add_argument('--log', default=None, help='log file location')
parser.add_argument('--save_dir', default=None, help='saved directory location')
parser.add_argument('--dt', default=0.001, type=float, help='simulation timestep')
parser.add_argument('--t_end', default=2.5, type=float, help='single example simulation time')
parser.add_argument('--workers', default=12, type=int, help='number of workers')

parser.add_argument('--gpu_id', default='0,1,2,3', type=str, help='id(s) for CUDA_VISIBLE_DEVICES')
parser.add_argument('--in_coding', default='temporal', type=str, help='Input encoding scheme for SNN')
parser.add_argument('--vth_vb', default=1.0, type=float, help='Spiking Neurons Threshold Value')
parser.add_argument('--vth_vu', default=0.0, type=float, help='Spiking Neurons Threshold Value')
parser.add_argument('--snn_TTS', default=128, type=int, help='Simulation timesteps per example')
parser.add_argument('--snn_fpi', default=64, type=int, help='Number of frames per input image')

def main():
    start_time = time.time()

    # Parse argument
    global args
    args = parser.parse_args()
  
    os.environ['CUDA_VISIBLE_DEVICES'] = args.gpu_id
    use_cuda = torch.cuda.is_available()

    if args.log is None:
        f = sys.stdout
    else:
        f = open(args.log, 'w', buffering=1)

    # Initialize seed and best accuracy
    torch.manual_seed(args.seed)
    torch.cuda.manual_seed_all(args.seed)
    best_prec1 = 0

    # Check the save_dir exists or not
    if (not args.save_dir is None) and (not os.path.exists(args.save_dir)):
        os.makedirs(args.save_dir)

    # Load model and parallelize on GPU
    import model_vgg16_imagenet
    model_rate = model_vgg16_imagenet.VGGRate()
    model_rate.features = torch.nn.DataParallel(model_rate.features)
    model_rate.cuda()
    f.write(str(model_rate)+'\n')

    # Define loss function (criterion) and optimizer
    criterion = nn.CrossEntropyLoss().cuda()
    optimizer = torch.optim.SGD(model_rate.parameters(), lr=args.learning_rate,
                                momentum=args.momentum,
                                weight_decay=args.weight_decay)

    # Optionally resume from checkpoint
    if args.resume:
        if os.path.isfile(args.resume):
            checkpoint = torch.load(args.resume)
            args.start_epoch = checkpoint['epoch']
            # best_prec1 = checkpoint['best_prec1']

            # print("model_rate's state_dict:")
            # for param_tensor in model_rate.state_dict():
            #     print(param_tensor, model_rate.state_dict()[param_tensor].size())
            model_rate.load_state_dict(checkpoint['state_dict'])

            # print("Optimizer's state_dict:")
            # for var_name in optimizer.state_dict():
            #     print(var_name, optimizer.state_dict()[var_name])
            optimizer.load_state_dict(checkpoint['optimizer'])

            f.write("=> Load checkpoint from {} (start_epoch={})\n".format(args.resume, checkpoint['epoch']))
        else:
            f.write("=> No checkpoint found at {}\n".format(args.resume))
            sys.exit(0)

    # Set CUDNN to look for optimal running alogrithm 
    cudnn.benchmark = True

    # Normalization function
    class normalize(object):
        def __init__(self, mean, absmax):
            self.mean = mean
            self.absmax = absmax
        def __call__(self, tensor):
            # Args: tensor (Tensor): Tensor image of size (C, H, W) to be normalized.
            # Returns: Tensor: Normalized image.
            for t, m, am in zip(tensor, self.mean, self.absmax):
                t.sub_(m).div_(am)
            return tensor


     # Data loading code
    traindir = os.path.join(args.data, 'train')
    valdir = os.path.join(args.data, 'val')
    normalize = transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                     std=[0.5173, 0.5478, 0.5992])

    train_loader = torch.utils.data.DataLoader(
        datasets.ImageFolder(traindir, transforms.Compose([
            transforms.RandomSizedCrop(224),
            transforms.RandomHorizontalFlip(),
            transforms.ToTensor(),
            normalize,
        ])),
        batch_size=args.train_batch, shuffle=True,
        num_workers=args.workers, pin_memory=True)

    test_loader = torch.utils.data.DataLoader(
        datasets.ImageFolder(valdir, transforms.Compose([
            transforms.Scale(256),
            transforms.CenterCrop(224),
            transforms.ToTensor(),
            normalize,
        ])),
        batch_size=args.test_batch, shuffle=False,
        num_workers=args.workers, pin_memory=True)


    if args.evaluate:
        best_prec1 = 0
        prec1 = validate_rate(test_loader, model_rate, criterion, f)
        is_best = prec1 > best_prec1
        best_prec1 = max(prec1, best_prec1)
    else:
        for epoch in range(args.start_epoch, args.max_epoch+1):
            adjust_learning_rate(optimizer, epoch)

            # Train for one epoch
            train_rate(train_loader, model_rate, criterion, optimizer, epoch, f)
            
            # Evaluate on validation set
            prec1 = validate_rate(test_loader, model_rate, criterion, f)

            # Save checkpoint
            is_best = prec1 > best_prec1
            best_prec1 = max(prec1, best_prec1)
            if (epoch % 20 == 0) and (not args.save_dir is None):
                save_checkpoint({
                    'epoch': epoch + 1,
                    'state_dict': model_rate.state_dict(),
                    'best_prec1': best_prec1,
                    'optimizer' : optimizer.state_dict(),            
                }, is_best, filename=os.path.join(args.save_dir, 'checkpoint_{}.tar'.format(epoch)))

        # Re-evaluate again for 10 times
        best_prec1 = 0
        prec1 = validate_rate(val_loader, model_rate, criterion, f)
        is_best = prec1 > best_prec1
        best_prec1 = max(prec1, best_prec1)

    f.write('Summary\t/\tTotal time {:.3f}\t/\tBest prec@1 {:.3f}\n'.format(time.time()-start_time, best_prec1))
    ##############################################################################################################

    f.write("==> Testing Bing's ANN-SNN Conversion:\n")
    # Instantiate rate-based sequential model
    import model_vgg16_imagenet_baseline
    model_rate_wprobe = model_vgg16_imagenet_baseline.VGGRate()
    model_rate_wprobe.features = torch.nn.DataParallel(model_rate_wprobe.features)
    model_rate_wprobe.cuda()
    f.write(str(model_rate_wprobe)+'\n')

    # print("model_rate's state_dict:")
    # for param_tensor in model_rate.state_dict():
    #     print(param_tensor, model_rate.state_dict()[param_tensor].size())

    # print("model_rate_probe's state_dict:")
    # for param_tensor in model_rate_wprobe.state_dict():
    #     print(param_tensor, model_rate_wprobe.state_dict()[param_tensor].size())

    # Run trained network through training dataset again to find maximum input to IFNeuron 
    weight_mapping = [('features.module.0.weight', 'features.module.0.weight'), 
                      ('features.module.2.weight', 'features.module.2.weight'),
                      ('features.module.5.weight', 'features.module.5.weight'), 
                      ('features.module.7.weight', 'features.module.7.weight'),
                      ('features.module.10.weight', 'features.module.10.weight'), 
                      ('features.module.12.weight', 'features.module.12.weight'),
                      ('features.module.14.weight', 'features.module.14.weight'), 
                      ('features.module.17.weight', 'features.module.17.weight'),
                      ('features.module.19.weight', 'features.module.19.weight'), 
                      ('features.module.21.weight', 'features.module.21.weight'),
                      ('features.module.24.weight', 'features.module.24.weight'), 
                      ('features.module.26.weight', 'features.module.26.weight'),
                      ('features.module.28.weight', 'features.module.28.weight'), 
                      ('classifier.0.weight', 'classifier.0.weight'),
                      ('classifier.3.weight', 'classifier.3.weight'),
                      ('classifier.6.weight', 'classifier.6.weight')]
    model_rate_dict = model_rate.state_dict() 
    model_rate_wprobe_dict = model_rate_wprobe.state_dict() 
    for source,target in weight_mapping:
        model_rate_wprobe_dict[target].copy_(model_rate_dict[source]) 

    l1_hmax_outp =  torch.zeros(args.batch_size,1).cuda()
    l3_hmax_outp =  torch.zeros(args.batch_size,1).cuda()
    l6_hmax_outp =  torch.zeros(args.batch_size,1).cuda()
    l8_hmax_outp = torch.zeros(args.batch_size,1).cuda()
    l11_hmax_outp = torch.zeros(args.batch_size,1).cuda()
    l13_hmax_outp = torch.zeros(args.batch_size,1).cuda()
    l15_hmax_outp = torch.zeros(args.batch_size,1).cuda()
    l18_hmax_outp = torch.zeros(args.batch_size,1).cuda()
    l20_hmax_outp = torch.zeros(args.batch_size,1).cuda()
    l22_hmax_outp = torch.zeros(args.batch_size,1).cuda()
    l25_hmax_outp = torch.zeros(args.batch_size,1).cuda()
    l27_hmax_outp = torch.zeros(args.batch_size,1).cuda()
    l29_hmax_outp = torch.zeros(args.batch_size,1).cuda()
    fc0_hmax_outp = torch.zeros(args.batch_size,1).cuda()
    fc3_hmax_outp = torch.zeros(args.batch_size,1).cuda()


    with torch.no_grad():
        for i, (inp, target) in enumerate(train_loader):
            if i == 6250:  break

            inp = inp.cuda(non_blocking=True)
            target = target.cuda(non_blocking=True)
            outp,l1_max_outp,l3_max_outp,l6_max_outp,l8_max_outp,l11_max_outp,l13_max_outp,l15_max_outp,l18_max_outp,l20_max_outp,l22_max_outp,l25_max_outp,l27_max_outp,l29_max_outp,fc0_max_outp,fc3_max_outp = model_rate_wprobe(inp)
            # print(i, l1_hmax_outp.shape, l1_max_outp.shape)
            l1_hmax_outp = torch.max(l1_hmax_outp,l1_max_outp)
            l3_hmax_outp = torch.max(l3_hmax_outp,l3_max_outp)
            l6_hmax_outp = torch.max(l6_hmax_outp,l6_max_outp)
            l8_hmax_outp = torch.max(l8_hmax_outp,l8_max_outp)
            l11_hmax_outp = torch.max(l11_hmax_outp,l11_max_outp)
            l13_hmax_outp = torch.max(l13_hmax_outp,l13_max_outp)
            l15_hmax_outp = torch.max(l15_hmax_outp,l15_max_outp)
            l18_hmax_outp = torch.max(l18_hmax_outp,l18_max_outp)
            l20_hmax_outp = torch.max(l20_hmax_outp,l20_max_outp)
            l22_hmax_outp = torch.max(l22_hmax_outp,l22_max_outp)
            l25_hmax_outp = torch.max(l25_hmax_outp,l25_max_outp)
            l27_hmax_outp = torch.max(l27_hmax_outp,l27_max_outp)
            l29_hmax_outp = torch.max(l29_hmax_outp,l29_max_outp)
            fc0_hmax_outp = torch.max(fc0_hmax_outp,fc0_max_outp)
            fc3_hmax_outp = torch.max(fc3_hmax_outp,fc3_max_outp)

    l1_hmax_outp = torch.max(l1_hmax_outp)
    l3_hmax_outp = torch.max(l3_hmax_outp)
    l6_hmax_outp = torch.max(l6_hmax_outp)
    l8_hmax_outp = torch.max(l8_hmax_outp)
    l11_hmax_outp = torch.max(l11_hmax_outp)
    l13_hmax_outp = torch.max(l13_hmax_outp)
    l15_hmax_outp = torch.max(l15_hmax_outp)
    l18_hmax_outp = torch.max(l18_hmax_outp)
    l20_hmax_outp = torch.max(l20_hmax_outp)
    l22_hmax_outp = torch.max(l22_hmax_outp)
    l25_hmax_outp = torch.max(l25_hmax_outp)
    l27_hmax_outp = torch.max(l27_hmax_outp)
    l29_hmax_outp = torch.max(l29_hmax_outp)
    fc0_hmax_outp = torch.max(fc0_hmax_outp)
    fc3_hmax_outp = torch.max(fc3_hmax_outp)

    ##############################################################################
    # Instantiate spiking module
    model_spike = model_vgg16_imagenet.VGGSpike(dt=args.dt, t_end=args.t_end, in_coding=args.in_coding)
    model_spike = torch.nn.DataParallel(model_spike).cuda()
    f.write(str(model_spike)+'\n')
    
    # Copy weight from sequential model
    weight_mapping = [('features.module.0.weight', 'module.features.1.weight'), 
                      ('features.module.2.weight', 'module.features.3.weight'),
                      ('features.module.5.weight', 'module.features.6.weight'), 
                      ('features.module.7.weight', 'module.features.8.weight'),
                      ('features.module.10.weight', 'module.features.11.weight'), 
                      ('features.module.12.weight', 'module.features.13.weight'),
                      ('features.module.14.weight', 'module.features.15.weight'), 
                      ('features.module.17.weight', 'module.features.18.weight'),
                      ('features.module.19.weight', 'module.features.20.weight'), 
                      ('features.module.21.weight', 'module.features.22.weight'),
                      ('features.module.24.weight', 'module.features.25.weight'), 
                      ('features.module.26.weight', 'module.features.27.weight'),
                      ('features.module.28.weight', 'module.features.29.weight'), 
                      ('classifier.0.weight', 'module.classifier.0.weight'),
                      ('classifier.3.weight', 'module.classifier.3.weight'),
                      ('classifier.6.weight', 'module.classifier.6.weight')]
    model_rate_wprobe_dict = model_rate_wprobe.state_dict() 
    model_spike_dict = model_spike.state_dict() 
    for source,target in weight_mapping:
        model_spike_dict[target].copy_(model_rate_wprobe_dict[source])

    V_b = args.vth_vb
    V_u = args.vth_vu

    prev_factor = 1.0
    l1_maxw = torch.max(model_rate_wprobe.features.module[0].weight)
    scale_factor = torch.max(l1_hmax_outp, l1_maxw)
    vth_l2 = torch.div(scale_factor, prev_factor)
    apply_factor = vth_l2*V_b + V_u
    f.write('\tl2 threshold balancing {:.3f}\n'.format(apply_factor))
    model_spike.module.features[2].set_thres(float(apply_factor))
    prev_factor = scale_factor

    l3_maxw = torch.max(model_rate_wprobe.features.module[2].weight)
    scale_factor = torch.max(l3_hmax_outp, l3_maxw)
    vth_l4 = torch.div(scale_factor, prev_factor)
    apply_factor = vth_l4*V_b + V_u
    f.write('\tl4 threshold balancing {:.3f}\n'.format(apply_factor))
    model_spike.module.features[4].set_thres(float(apply_factor))
    prev_factor = scale_factor

    l6_maxw = torch.max(model_rate_wprobe.features.module[5].weight)
    scale_factor = torch.max(l6_hmax_outp, l6_maxw)
    vth_l7 = torch.div(scale_factor, prev_factor)
    apply_factor = vth_l7*V_b + V_u
    f.write('\tl7 threshold balancing {:.3f}\n'.format(apply_factor))
    model_spike.module.features[7].set_thres(float(apply_factor))
    prev_factor = scale_factor

    l8_maxw = torch.max(model_rate_wprobe.features.module[7].weight)
    scale_factor = torch.max(l8_hmax_outp, l8_maxw)
    vth_l9 = torch.div(scale_factor, prev_factor)
    apply_factor = vth_l9*V_b + V_u
    f.write('\tl9 threshold balancing {:.3f}\n'.format(apply_factor))
    model_spike.module.features[9].set_thres(float(apply_factor))
    prev_factor = scale_factor

    l11_maxw = torch.max(model_rate_wprobe.features.module[10].weight)
    scale_factor = torch.max(l11_hmax_outp, l11_maxw)
    vth_l12 = torch.div(scale_factor, prev_factor)
    apply_factor = vth_l12*V_b + V_u
    f.write('\tl12 threshold balancing {:.3f}\n'.format(apply_factor))
    model_spike.module.features[12].set_thres(float(apply_factor))
    prev_factor = scale_factor

    l13_maxw = torch.max(model_rate_wprobe.features.module[12].weight)
    scale_factor = torch.max(l13_hmax_outp, l13_maxw)
    vth_l14 = torch.div(scale_factor, prev_factor)
    apply_factor = vth_l14*V_b + V_u
    f.write('\tl14 threshold balancing {:.3f}\n'.format(apply_factor))
    model_spike.module.features[14].set_thres(float(apply_factor))
    prev_factor = scale_factor

    l15_maxw = torch.max(model_rate_wprobe.features.module[14].weight)
    scale_factor = torch.max(l15_hmax_outp, l15_maxw)
    vth_l16 = torch.div(scale_factor, prev_factor)
    apply_factor = vth_l16*V_b + V_u
    f.write('\tl16 threshold balancing {:.3f}\n'.format(apply_factor))
    model_spike.module.features[16].set_thres(float(apply_factor))
    prev_factor = scale_factor

    l18_maxw = torch.max(model_rate_wprobe.features.module[17].weight)
    scale_factor = torch.max(l18_hmax_outp, l18_maxw)
    vth_l19 = torch.div(scale_factor, prev_factor)
    apply_factor = vth_l19*V_b + V_u
    f.write('\tl19 threshold balancing {:.3f}\n'.format(apply_factor))
    model_spike.module.features[19].set_thres(float(apply_factor))
    prev_factor = scale_factor

    l20_maxw = torch.max(model_rate_wprobe.features.module[19].weight)
    scale_factor = torch.max(l20_hmax_outp, l20_maxw)
    vth_l21 = torch.div(scale_factor, prev_factor)
    apply_factor = vth_l21*V_b + V_u
    f.write('\tl21 threshold balancing {:.3f}\n'.format(apply_factor))
    model_spike.module.features[21].set_thres(float(apply_factor))
    prev_factor = scale_factor

    l22_maxw = torch.max(model_rate_wprobe.features.module[21].weight)
    scale_factor = torch.max(l22_hmax_outp, l22_maxw)
    vth_l23 = torch.div(scale_factor, prev_factor)
    apply_factor = vth_l23*V_b + V_u
    f.write('\tl23 threshold balancing {:.3f}\n'.format(apply_factor))
    model_spike.module.features[23].set_thres(float(apply_factor))
    prev_factor = scale_factor

    l25_maxw = torch.max(model_rate_wprobe.features.module[24].weight)
    scale_factor = torch.max(l25_hmax_outp, l25_maxw)
    vth_l26 = torch.div(scale_factor, prev_factor)
    apply_factor = vth_l26*V_b + V_u
    f.write('\tl26 threshold balancing {:.3f}\n'.format(apply_factor))
    model_spike.module.features[26].set_thres(float(apply_factor))
    prev_factor = scale_factor

    l27_maxw = torch.max(model_rate_wprobe.features.module[26].weight)
    scale_factor = torch.max(l27_hmax_outp, l27_maxw)
    vth_l28 = torch.div(scale_factor, prev_factor)
    apply_factor = vth_l28*V_b + V_u
    f.write('\tl28 threshold balancing {:.3f}\n'.format(apply_factor))
    model_spike.module.features[28].set_thres(float(apply_factor))
    prev_factor = scale_factor

    l29_maxw = torch.max(model_rate_wprobe.features.module[28].weight)
    scale_factor = torch.max(l29_hmax_outp, l29_maxw)
    vth_l30 = torch.div(scale_factor, prev_factor)
    apply_factor = vth_l30*V_b + V_u
    f.write('\tl30 threshold balancing {:.3f}\n'.format(apply_factor))
    model_spike.module.features[30].set_thres(float(apply_factor))
    prev_factor = scale_factor

    fc0_maxw = torch.max(model_rate_wprobe.classifier[0].weight)
    scale_factor = torch.max(fc0_hmax_outp, fc0_maxw)
    vth_fc1 = torch.div(scale_factor, prev_factor)
    apply_factor = vth_fc1*V_b + V_u
    f.write('\tfc1 threshold balancing {:.3f}\n'.format(apply_factor))
    model_spike.module.classifier[1].set_thres(float(apply_factor))
    prev_factor = scale_factor

    fc3_maxw = torch.max(model_rate_wprobe.classifier[3].weight)
    scale_factor = torch.max(fc3_hmax_outp, fc3_maxw)
    vth_fc4 = torch.div(scale_factor, prev_factor)
    apply_factor = vth_fc4*V_b + V_u
    f.write('\tfc4 threshold balancing {:.3f}\n'.format(apply_factor))
    model_spike.module.classifier[4].set_thres(float(apply_factor))
    prev_factor = scale_factor

    # Evaluate on validation set
    validate_spike(test_loader, model_spike, criterion, f)
#####################################################################################################################################

def train_rate(train_loader, model, criterion, optimizer, epoch, f):
    """
        Run one train epoch
    """
    # switch to train mode
    model.train()

    start_time = time.time()
    acc_top1 = []
    acc_top5 = []
    acc_loss = []

    for i, (inp, target) in enumerate(train_loader):
        
        inp = inp.cuda(non_blocking=True)
        target = target.cuda(non_blocking=True)

        # compute outp
        # outp = model(inp)

        outp = model.features.module[0](inp)
        # print('l1_max_outp_pre', torch.max(outp), torch.min(outp))
        outp = model.features.module[1](outp)  # batch norm layer
        # print('l1_max_outp_post', torch.max(outp), torch.min(outp))

        outp = model.features.module[3](model.features.module[2](outp))
        # print('l4_max_outp_pre', torch.max(outp), torch.min(outp))
        outp = model.features.module[4](outp)  # batch norm layer
        # print('l4_max_outp_post', torch.max(outp), torch.min(outp))

        outp = model.features.module[7](model.features.module[6](model.features.module[5](outp)))
        # print('l8_max_outp', torch.max(outp), torch.min(outp))
        outp = model.features.module[8](outp)  # batch norm layer
        # print('l8_max_outp', torch.max(outp), torch.min(outp))

        outp = model.features.module[10](model.features.module[9](outp))
        # print('l11_max_outp', torch.max(outp), torch.min(outp))
        outp = model.features.module[11](outp)  # batch norm layer
        # print('l11_max_outp', torch.max(outp), torch.min(outp))

        outp = model.features.module[14](model.features.module[13](model.features.module[12](outp)))
        # print('l15_max_outp', torch.max(outp), torch.min(outp))
        outp = model.features.module[15](outp)
        # print('l15_max_outp', torch.max(outp), torch.min(outp))

        outp = model.features.module[17](model.features.module[16](outp))
        # print('l18_max_outp', torch.max(outp), torch.min(outp))
        outp = model.features.module[18](outp)
        # print('l18_max_outp', torch.max(outp), torch.min(outp))

        outp = model.features.module[20](model.features.module[19](outp))
        # print('l21_max_outp', torch.max(outp), torch.min(outp))
        outp = model.features.module[21](outp)
        # print('l21_max_outp', torch.max(outp), torch.min(outp))

        outp = model.features.module[24](model.features.module[23](model.features.module[22](outp)))
        # print('l25_max_outp', torch.max(outp), torch.min(outp))
        outp = model.features.module[25](outp)
        # print('l25_max_outp', torch.max(outp), torch.min(outp))

        outp = model.features.module[27](model.features.module[26](outp))
        # print('l28_max_outp', torch.max(outp), torch.min(outp))
        outp = model.features.module[28](outp)
        # print('l28_max_outp', torch.max(outp), torch.min(outp))

        outp = model.features.module[30](model.features.module[29](outp))
        # print('l31_max_outp', torch.max(outp), torch.min(outp))
        outp = model.features.module[31](outp)
        # print('l31_max_outp', torch.max(outp), torch.min(outp))

        outp = model.features.module[34](model.features.module[33](model.features.module[32](outp)))
        # print('l35_max_outp', torch.max(outp), torch.min(outp))
        outp = model.features.module[35](outp)
        # print('l35_max_outp', torch.max(outp), torch.min(outp))

        outp = model.features.module[37](model.features.module[36](outp))
        # print('l38_max_outp', torch.max(outp), torch.min(outp))
        outp = model.features.module[38](outp)
        # print('l38_max_outp', torch.max(outp), torch.min(outp))

        outp = model.features.module[40](model.features.module[39](outp))
        # print('l41_max_outp', torch.max(outp), torch.min(outp))
        outp = model.features.module[41](outp)
        # print('l41_max_outp', torch.max(outp), torch.min(outp))

        outp = model.features.module[43](model.features.module[42](outp))
        outp = outp.view(outp.size(0), -1)
        outp = model.classifier[0](outp)

        loss = criterion(outp, target)

        # measure accuracy and record loss
        prec1, prec5 = accuracy(outp, target, topk=(1, 5))
        acc_top1.append(float(prec1))
        acc_top5.append(float(prec5))
        acc_loss.append(float(loss))

        # compute gradient and do SGD step
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

    f.write('Epoch {:>3}\t/\tTrain:\tTime {:.3f}\tPrec@1 {:.3f}\tPrec@5 {:.3f}\tLoss {:.3f}\t'.format(epoch,time.time()-start_time, np.mean(acc_top1), np.mean(acc_top5), np.mean(acc_loss)))

def validate_spike(val_loader, model, criterion, f):
    """
    Run evaluation
    """
    # switch to evaluate mode
    model.eval()
    
    start_time = time.time()
    acc_top1 = []
    acc_top5 = []

    with torch.no_grad():
        for i, (inp, target) in enumerate(tqdm(val_loader)):
            
            inp = inp.cuda(non_blocking=True)
            target = target.cuda(non_blocking=True)

            # compute outp
            # outp = model_rate(inp)
            outp_sum = torch.zeros(inp.size(0),1000).cuda()
            l2_mem_potential = torch.zeros(inp.size(0),64,224,224).cuda()
            l2_max_inp = torch.zeros(inp.size(0),1).cuda()
            l2_spike_count = torch.zeros(1).cuda()
            l2_neuron_count = 64*224*224

            l4_mem_potential = torch.zeros(inp.size(0),64,224,224).cuda()
            l4_max_inp = torch.zeros(inp.size(0),1).cuda()
            l4_spike_count = torch.zeros(1).cuda()
            l4_neuron_count = 64*224*224

            l7_mem_potential = torch.zeros(inp.size(0),128,112,112).cuda()
            l7_max_inp = torch.zeros(inp.size(0),1).cuda()
            l7_spike_count = torch.zeros(1).cuda()
            l7_neuron_count = 128*112*112

            l9_mem_potential = torch.zeros(inp.size(0),128,112,112).cuda()
            l9_max_inp = torch.zeros(inp.size(0),1).cuda()
            l9_spike_count = torch.zeros(1).cuda()
            l9_neuron_count = 128*112*112

            l12_mem_potential = torch.zeros(inp.size(0),256,56,56).cuda()
            l12_max_inp = torch.zeros(inp.size(0),1).cuda()
            l12_spike_count = torch.zeros(1).cuda()
            l12_neuron_count = 256*56*56

            l14_mem_potential = torch.zeros(inp.size(0),256,56,56).cuda()
            l14_max_inp = torch.zeros(inp.size(0),1).cuda()
            l14_spike_count = torch.zeros(1).cuda()
            l14_neuron_count = 256*56*56

            l16_mem_potential = torch.zeros(inp.size(0),256,56,56).cuda()
            l16_max_inp = torch.zeros(inp.size(0),1).cuda()
            l16_spike_count = torch.zeros(1).cuda()
            l16_neuron_count = 256*56*56

            l19_mem_potential = torch.zeros(inp.size(0),512,28,28).cuda()
            l19_max_inp = torch.zeros(inp.size(0),1).cuda()
            l19_spike_count = torch.zeros(1).cuda()
            l19_neuron_count = 512*28*28

            l21_mem_potential = torch.zeros(inp.size(0),512,28,28).cuda()
            l21_max_inp = torch.zeros(inp.size(0),1).cuda()
            l21_spike_count = torch.zeros(1).cuda()
            l21_neuron_count = 512*28*28

            l23_mem_potential = torch.zeros(inp.size(0),512,28,28).cuda()
            l23_max_inp = torch.zeros(inp.size(0),1).cuda()
            l23_spike_count = torch.zeros(1).cuda()
            l23_neuron_count = 512*28*28

            l26_mem_potential = torch.zeros(inp.size(0),512,14,14).cuda()
            l26_max_inp = torch.zeros(inp.size(0),1).cuda()
            l26_spike_count = torch.zeros(1).cuda()
            l26_neuron_count = 512*14*14

            l28_mem_potential = torch.zeros(inp.size(0),512,14,14).cuda()
            l28_max_inp = torch.zeros(inp.size(0),1).cuda()
            l28_spike_count = torch.zeros(1).cuda()
            l28_neuron_count = 512*14*14

            l30_mem_potential = torch.zeros(inp.size(0),512,14,14).cuda()
            l30_max_inp = torch.zeros(inp.size(0),1).cuda()
            l30_spike_count = torch.zeros(1).cuda()
            l30_neuron_count = 512*14*14

            fc1_mem_potential = torch.zeros(inp.size(0),4096).cuda()
            fc1_max_inp = torch.zeros(inp.size(0),1).cuda()
            fc1_spike_count = torch.zeros(1).cuda()
            fc1_neuron_count = 4096

            fc4_mem_potential = torch.zeros(inp.size(0),4096).cuda()
            fc4_max_inp = torch.zeros(inp.size(0),1).cuda()
            fc4_spike_count = torch.zeros(1).cuda()
            fc4_neuron_count = 4096
        
            TTS = args.snn_TTS
            fpi = args.snn_fpi
            count = 0
            en_IN = True
            en_IF = False

            for ts in range(TTS+1):

                if count == fpi+1:
                    count = 0
                
                    if en_IN == True:
                        en_IN = False
                    elif en_IN == False:
                        en_IN = True

                    if en_IF == True:
                        en_IF = False
                    elif en_IF == False:
                        en_IF = True
                
                count = count + 1
                
                outp = model.module.features[0](inp, count, fpi, en_IN)
                outp = model.module.features[1](outp)
                l2_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l2_max_inp)
                outp,l2_mem_potential = model.module.features[2](outp,l2_mem_potential, en_IF)
                # print('timestep', ts, 'l2_mem_potential', l2_mem_potential.shape, torch.max(l2_mem_potential), torch.min(l2_mem_potential))
                l2_spike_count += torch.sum(outp)

                outp = model.module.features[3](outp)
                l4_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l4_max_inp)
                outp,l4_mem_potential = model.module.features[4](outp,l4_mem_potential, en_IF)
                # print('timestep', ts, 'l4_mem_potential', l4_mem_potential.shape, torch.max(l4_mem_potential), torch.min(l4_mem_potential))
                l4_spike_count += torch.sum(outp)
                outp = model.module.features[5](outp)

                outp = model.module.features[6](outp)
                l7_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l7_max_inp)
                outp,l7_mem_potential = model.module.features[7](outp,l7_mem_potential, en_IF)
                # print('timestep', ts, 'l7_mem_potential', l7_mem_potential.shape, torch.max(l7_mem_potential), torch.min(l7_mem_potential))
                l7_spike_count += torch.sum(outp)

                outp = model.module.features[8](outp)
                l9_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l9_max_inp)
                outp,l9_mem_potential = model.module.features[9](outp,l9_mem_potential, en_IF)
                # print('timestep', ts, 'l9_mem_potential', l9_mem_potential.shape, torch.max(l9_mem_potential), torch.min(l9_mem_potential))
                l9_spike_count += torch.sum(outp)
                outp = model.module.features[10](outp)

                outp = model.module.features[11](outp)
                l12_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l12_max_inp)
                outp,l12_mem_potential = model.module.features[12](outp,l12_mem_potential, en_IF)
                # print('timestep', ts, 'l12_mem_potential', l12_mem_potential.shape, torch.max(l12_mem_potential), torch.min(l12_mem_potential))
                l12_spike_count += torch.sum(outp)

                outp = model.module.features[13](outp)
                l14_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l14_max_inp)
                outp,l14_mem_potential = model.module.features[14](outp,l14_mem_potential, en_IF)
                # print('timestep', ts, 'l14_mem_potential', l14_mem_potential.shape, torch.max(l14_mem_potential), torch.min(l14_mem_potential))
                l14_spike_count += torch.sum(outp)

                outp = model.module.features[15](outp)
                l16_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l16_max_inp)
                outp,l16_mem_potential = model.module.features[16](outp,l16_mem_potential, en_IF)
                # print('timestep', ts, 'l16_mem_potential', l16_mem_potential.shape, torch.max(l16_mem_potential), torch.min(l16_mem_potential))
                l16_spike_count += torch.sum(outp)
                outp = model.module.features[17](outp)

                outp = model.module.features[18](outp)
                l19_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l19_max_inp)
                outp,l19_mem_potential = model.module.features[19](outp,l19_mem_potential, en_IF)
                # print('timestep', ts, 'l19_mem_potential', l19_mem_potential.shape, torch.max(l19_mem_potential), torch.min(l19_mem_potential))
                l19_spike_count += torch.sum(outp)

                outp = model.module.features[20](outp)
                l21_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l21_max_inp)
                outp,l21_mem_potential = model.module.features[21](outp,l21_mem_potential, en_IF)
                # print('timestep', ts, 'l21_mem_potential', l21_mem_potential.shape, torch.max(l21_mem_potential), torch.min(l21_mem_potential))
                l21_spike_count += torch.sum(outp)

                outp = model.module.features[22](outp)
                l23_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l23_max_inp)
                outp,l23_mem_potential = model.module.features[23](outp,l23_mem_potential, en_IF)
                # print('timestep', ts, 'l23_mem_potential', l23_mem_potential.shape, torch.max(l23_mem_potential), torch.min(l23_mem_potential))
                l23_spike_count += torch.sum(outp)
                outp = model.module.features[24](outp)

                outp = model.module.features[25](outp)
                l26_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l26_max_inp)
                outp,l26_mem_potential = model.module.features[26](outp,l26_mem_potential, en_IF)
                # print('timestep', ts, 'l26_mem_potential', l26_mem_potential.shape, torch.max(l26_mem_potential), torch.min(l26_mem_potential))
                l26_spike_count += torch.sum(outp)

                outp = model.module.features[27](outp)
                l28_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l28_max_inp)
                outp,l28_mem_potential = model.module.features[28](outp,l28_mem_potential, en_IF)
                # print('timestep', ts, 'l28_mem_potential', l28_mem_potential.shape, torch.max(l28_mem_potential), torch.min(l28_mem_potential))
                l28_spike_count += torch.sum(outp)

                outp = model.module.features[29](outp)
                l30_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l30_max_inp)
                outp,l30_mem_potential = model.module.features[30](outp,l30_mem_potential, en_IF)
                # print('timestep', ts, 'l30_mem_potential', l30_mem_potential.shape, torch.max(l30_mem_potential), torch.min(l30_mem_potential))
                l30_spike_count += torch.sum(outp)
                outp = model.module.features[31](outp)

                outp = outp.view(outp.size(0), -1)

                outp = model.module.classifier[0](outp)
                fc1_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],fc1_max_inp)
                outp, fc1_mem_potential = model.module.classifier[1](outp,fc1_mem_potential, en_IF)
                # print('timestep', ts, 'fc1_mem_potential', fc1_mem_potential.shape, torch.max(fc1_mem_potential), torch.min(fc1_mem_potential))
                fc1_spike_count += torch.sum(outp)

                outp = model.module.classifier[2](outp)
                outp = model.module.classifier[3](outp)

                fc4_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],fc4_max_inp)
                outp, fc4_mem_potential = model.module.classifier[4](outp,fc4_mem_potential, en_IF)
                # print('timestep', ts, 'fc4_mem_potential', fc4_mem_potential.shape, torch.max(fc4_mem_potential), torch.min(fc4_mem_potential))
                fc4_spike_count += torch.sum(outp)

                outp = model.module.classifier[5](outp)
                outp = model.module.classifier[6](outp)

                outp_sum += outp

            loss = criterion(outp_sum, target)
            # measure accuracy and record loss
            prec1, prec5 = accuracy(outp_sum, target, topk=(1, 5))
            acc_top1.append(float(prec1))
            acc_top5.append(float(prec5))
            
            if (i!=0) and (i%10==0):  
                f.write('\tTest {:>5} :\tTime {:.3f}\tPrec@1 {:.3f}\tPrec@5 {:.3f}\n'.format(i, time.time()-start_time, np.mean(acc_top1), np.mean(acc_top5)))

        print('Layer  l2  Total spikes/image: ',  l2_spike_count/50000, 'Total neurons: ',  l2_neuron_count)
        print('Layer  l4  Total spikes/image: ',  l4_spike_count/50000, 'Total Neurons: ',  l4_neuron_count)
        print('Layer  l7  Total spikes/image: ',  l7_spike_count/50000, 'Total Neurons: ',  l7_neuron_count)
        print('Layer  l9  Total spikes/image: ',  l9_spike_count/50000, 'Total Neurons: ',  l9_neuron_count)
        print('Layer l12  Total spikes/image: ', l12_spike_count/50000, 'Total Neurons: ', l12_neuron_count)
        print('Layer l14  Total spikes/image: ', l14_spike_count/50000, 'Total Neurons: ', l14_neuron_count)
        print('Layer l16  Total spikes/image: ', l16_spike_count/50000, 'Total Neurons: ', l16_neuron_count)
        print('Layer l19  Total spikes/image: ', l19_spike_count/50000, 'Total Neurons: ', l19_neuron_count)
        print('Layer l21  Total spikes/image: ', l21_spike_count/50000, 'Total Neurons: ', l21_neuron_count)
        print('Layer l23  Total spikes/image: ', l23_spike_count/50000, 'Total Neurons: ', l23_neuron_count)
        print('Layer l26  Total spikes/image: ', l26_spike_count/50000, 'Total Neurons: ', l26_neuron_count)
        print('Layer l28  Total spikes/image: ', l28_spike_count/50000, 'Total Neurons: ', l28_neuron_count)
        print('Layer l30  Total spikes/image: ', l30_spike_count/50000, 'Total Neurons: ', l30_neuron_count)
        print('Layer fc1  Total spikes/image: ', fc1_spike_count/50000, 'Total Neurons: ', fc1_neuron_count)
        print('Layer fc4  Total spikes/image: ', fc4_spike_count/50000, 'Total Neurons: ', fc4_neuron_count)

        f.write('\tSummary:\tTotal Time {:.3f}\tPrec@1 {:.3f}\tPrec@5 {:.3f}\n'.format(time.time()-start_time, np.mean(acc_top1), np.mean(acc_top5)))

    return np.mean(acc_top1)

def validate_seq(val_loader, model, criterion, f):
    """
    Run evaluation
    """
    # switch to evaluate mode
    model.eval()
    
    start_time = time.time()
    acc_top1 = []
    acc_top5 = []

    with torch.no_grad():
        for i, (inp, target) in enumerate(val_loader):
            inp = inp.cuda(non_blocking=True)
            target = target.cuda(non_blocking=True)

            # compute outp
            outp = model(inp)
            loss = criterion(outp, target)

            # measure accuracy and record loss
            prec1, prec5 = accuracy(outp, target, topk=(1, 5))
            acc_top1.append(float(prec1))
            acc_top5.append(float(prec5))

    f.write('/\tTest:\tTime {:.3f}\tPrec@1 {:.3f}\tPrec@5 {:.3f}\n'.format(time.time()-start_time, np.mean(acc_top1), np.mean(acc_top5)))

    return np.mean(acc_top1)

def validate_rate(val_loader, model, criterion, f):
    """
    Run evaluation
    """
    # switch to evaluate mode
    model.eval()
    
    start_time = time.time()
    acc_top1 = []
    acc_top5 = []

    with torch.no_grad():
        for i, (inp, target) in enumerate(val_loader):

            inp = inp.cuda(non_blocking=True)
            target = target.cuda(non_blocking=True)

            # compute outp
            # outp = model(inp)

            outp = model.features.module[0](inp)
            # print('l0_max_outp_pre', torch.max(outp), torch.min(outp))
            outp = model.features.module[1](outp)

            outp = model.features.module[2](outp)
            outp = model.features.module[3](outp)
            # print('l3_max_outp_pre', torch.max(outp), torch.min(outp))
            outp = model.features.module[4](outp)

            outp = model.features.module[5](outp)            
            outp = model.features.module[6](outp)
            # print('l6_max_outp', torch.max(outp), torch.min(outp))

            outp = model.features.module[7](outp)  
            outp = model.features.module[8](outp)  
            outp = model.features.module[9](outp)
            # print('l9_max_outp', torch.max(outp), torch.min(outp))

            outp = model.features.module[10](outp)
            outp = model.features.module[11](outp)  

            outp = model.features.module[12](outp)
            # print('l12_max_outp', torch.max(outp), torch.min(outp))
            outp = model.features.module[13](outp)
         
            outp = model.features.module[14](outp)
            outp = model.features.module[15](outp)
            # print('l15_max_outp', torch.max(outp), torch.min(outp))
            outp = model.features.module[16](outp)
            
            outp = model.features.module[17](outp)
            outp = model.features.module[18](outp)
            # print('l18_max_outp', torch.max(outp), torch.min(outp))

            outp = model.features.module[19](outp)
            outp = model.features.module[20](outp)

            outp = model.features.module[21](outp)
            # print('l21_max_outp', torch.max(outp), torch.min(outp))
            outp = model.features.module[22](outp)
            outp = model.features.module[23](outp)

            outp = model.features.module[24](outp)
            # print('l24_max_outp', torch.max(outp), torch.min(outp))
            outp = model.features.module[25](outp)
            
            outp = model.features.module[26](outp)
            outp = model.features.module[27](outp)
            # print('l27_max_outp', torch.max(outp), torch.min(outp))

            outp = model.features.module[28](outp)
            outp = model.features.module[29](outp)
            outp = model.features.module[30](outp)
            
            outp = outp.view(outp.size(0), -1)
            outp = model.classifier[0](outp)
            outp = model.classifier[1](outp)
            outp = model.classifier[2](outp)
            outp = model.classifier[3](outp)
            outp = model.classifier[4](outp)
            outp = model.classifier[5](outp)
            outp = model.classifier[6](outp)
            
            loss = criterion(outp, target)

            # measure accuracy and record loss
            prec1, prec5 = accuracy(outp, target, topk=(1, 5))
            acc_top1.append(float(prec1))
            acc_top5.append(float(prec5))

    f.write('/\tTest:\tTime {:.3f}\tPrec@1 {:.3f}\tPrec@5 {:.3f}\n'.format(time.time()-start_time, np.mean(acc_top1), np.mean(acc_top5)))

    return np.mean(acc_top1)

def save_checkpoint(state, is_best, filename='checkpoint.tar'):
    """
    Save the training model
    """
    torch.save(state, filename)

def adjust_learning_rate(optimizer, cur_epoch):
    # Reduce learning rate by 10 twice at epoch 81 and 122
    if cur_epoch == 81 or cur_epoch == 122:
        for param_group in optimizer.param_groups:
            param_group['lr'] /= 10


def accuracy(outp, target, topk=(1,)):
    """Computes the precision@k for the specified values of k"""
    with torch.no_grad():
        maxk = max(topk)
        batch_size = target.size(0)

        _, pred = outp.topk(maxk, 1, True, True)
        pred = pred.t()
        correct = pred.eq(target.view(1, -1).expand_as(pred))

        res = []
        for k in topk:
            correct_k = correct[:k].view(-1).float().sum(0, keepdim=True)
            res.append(correct_k.mul_(100.0 / batch_size))
        return res

if __name__ == '__main__':
    main()
