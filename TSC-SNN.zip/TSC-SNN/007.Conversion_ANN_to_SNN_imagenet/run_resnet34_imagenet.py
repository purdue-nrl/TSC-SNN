import argparse
import os
import time
import sys

import numpy as np

import torch
import torch.nn as nn
import torch.nn.parallel
import torch.backends.cudnn as cudnn
import torch.optim
from torchvision import datasets, transforms
from tqdm import tqdm

parser = argparse.ArgumentParser(description='PyTorch Implementation of Abhronil ANN-SNN Conversion Technique - ResNet34 with ImageNet', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
parser.add_argument('-d', '--dataset', default='/local/scratch/a/imagenet/imagenet2012', type=str)
# parser.add_argument('-d', '--dataset', default='/local/scratch/a/sarwar/imagenet2012', type=str)
# parser.add_argument('-d', '--dataset', default='/media/bing/Research/001.Simulation_Frameworks/dataset/imagenet2012', type=str)
# parser.add_argument('-d', '--dataset', default='/home/bing/Documents/001.Simulation_Frameworks/Project_7_Temporal_SNNs_Conversion/004.Training_BP_DeepConvNet/data/imagenet2012', type=str)
parser.add_argument('--start_epoch', default=1, type=int, help='starting epoch number (this value is set automatically if resume)')
parser.add_argument('--max_epoch', default=100, type=int, help='number of total epochs to run')
parser.add_argument('--batch_size', default=500, type=int, help='batch size')
parser.add_argument('--learning_rate', default=0.05, type=float, help='initial learning rate')
parser.add_argument('--momentum', default=0.9, type=float, help='momentum')
parser.add_argument('--num_workers', default=40, type=int, help='number of workers')
parser.add_argument('--weight_decay', default=1e-4, type=float, help='weight decay')
parser.add_argument('--resume', default='', type=str, help='path to latest checkpoint')
parser.add_argument('--evaluate', dest='evaluate', action='store_true', help='evaluate model on validation set')
parser.add_argument('--seed', default=10, type=int, help='random seed')
parser.add_argument('--log', default=None, help='log file location')
parser.add_argument('--save_dir', default=None, help='saved directory location')
parser.add_argument('--dt', default=0.001, type=float, help='simulation timestep')
parser.add_argument('--t_end', default=2.500, type=float, help='single example simulation time')
parser.add_argument('--dropout_prob_0', default=0.0, type=float, help='dropout probability of 1st feature')
parser.add_argument('--dropout_prob_1', default=0.0, type=float, help='dropout probability of 2nd feature')
parser.add_argument('--dropout_prob_2', default=0.0, type=float, help='dropout probability of 3rd feature')
parser.add_argument('--dropout_prob_3', default=0.0, type=float, help='dropout probability of other features')
parser.add_argument('--testing', dest='not_testing', action='store_false', help='performa ANN-SNN conversion and spiking simulation if specified')

parser.add_argument('--gpu_id', default='0,1,2,3', type=str, help='id(s) for CUDA_VISIBLE_DEVICES')
parser.add_argument('--vth_vb', default=0.73, type=float, help='Spiking Neurons Threshold Value')
parser.add_argument('--vth_vu', default=0.0, type=float, help='Spiking Neurons Threshold Value')
parser.add_argument('--snn_fpi', default=64, type=int, help='Number of frames per input image')
parser.add_argument('--snn_TTS', default=128, type=int, help='Simulation timesteps per example')
parser.add_argument('--snn_mode', default='full', type=str, help='full or acc')
parser.add_argument('--if_mode', default='if', type=str, help='if or residual')
parser.add_argument('--in_coding', default='rate', type=str, help='Input encoding scheme for SNN')

def main():
    start_time = time.time()

    # Parse argument
    global args
    args = parser.parse_args()

    os.environ['CUDA_VISIBLE_DEVICES'] = args.gpu_id
    use_cuda = torch.cuda.is_available()
   
    if args.log is None:
        f = sys.stdout
    else:
        f = open(args.log, 'w', buffering=1)

    # Initialize seed and best accuracy
    torch.manual_seed(args.seed)
    torch.cuda.manual_seed_all(args.seed)
    best_prec1 = 0

    # Check the save_dir exists or not
    if (not args.save_dir is None) and (not os.path.exists(args.save_dir)):
        os.makedirs(args.save_dir)

    # Load model and parallelize on GPU
    import model_resnet34_imagenet
    model_rate = model_resnet34_imagenet.ResNetRate([args.dropout_prob_0,args.dropout_prob_1,args.dropout_prob_2,args.dropout_prob_3])
    model_rate = torch.nn.DataParallel(model_rate).cuda()
    f.write(str(model_rate)+'\n')

    # Define loss function (criterion) and optimizer
    criterion = nn.CrossEntropyLoss().cuda()
    optimizer = torch.optim.SGD(model_rate.parameters(), lr=args.learning_rate,
                                momentum=args.momentum,
                                weight_decay=args.weight_decay)

    # Optionally resume from checkpoint
    if args.resume:
        if os.path.isfile(args.resume):
            checkpoint = torch.load(args.resume)
            args.start_epoch = checkpoint['epoch']
            # best_prec1 = checkpoint['best_prec1']
            model_rate.load_state_dict(checkpoint['state_dict'])
            optimizer.load_state_dict(checkpoint['optimizer'])
            f.write("=> Load checkpoint from {} (start_epoch={})\n".format(args.resume, checkpoint['epoch']))
        else:
            f.write("=> No checkpoint found at {}\n".format(args.resume))
            sys.exit(0)

    # Set CUDNN to look for optimal running alogrithm 
    cudnn.benchmark = True

    # Normalization function
    class normalize(object):
        def __init__(self, mean, absmax):
            self.mean = mean
            self.absmax = absmax
        def __call__(self, tensor):
            # Args: tensor (Tensor): Tensor image of size (C, H, W) to be normalized.
            # Returns: Tensor: Normalized image.
            for t, m, am in zip(tensor, self.mean, self.absmax):
                t.sub_(m).div_(am)
            return tensor

    # Mean and SD are calculuated by get_dataset_stat.py
    train_transform = transforms.Compose([
        transforms.RandomResizedCrop(224),
        transforms.RandomHorizontalFlip(p=0.5),
        transforms.ToTensor(),
        normalize(mean=[0.4827, 0.4522, 0.4008],absmax=[0.5173, 0.5478, 0.5992])
        ])
    train_dir = os.path.join(args.dataset, 'train')
    train_set = datasets.ImageFolder(train_dir, transform=train_transform)
    train_loader = torch.utils.data.DataLoader(train_set, batch_size=args.batch_size, shuffle=True, num_workers=args.num_workers, pin_memory=True)
    test_transform = transforms.Compose([
        transforms.Resize(256),
        transforms.CenterCrop(224),
        transforms.ToTensor(),
        normalize(mean=[0.4827, 0.4522, 0.4008],absmax=[0.5173, 0.5478, 0.5992])
        ])
    test_dir = os.path.join(args.dataset, 'val')
    test_set = datasets.ImageFolder(test_dir, transform=test_transform)
    test_loader = torch.utils.data.DataLoader(test_set, batch_size=args.batch_size, shuffle=False, num_workers=args.num_workers, pin_memory=True)
    
    if args.evaluate:
        best_prec1 = 0
        prec1 = validate_rate(test_loader, model_rate, criterion, f)
        is_best = prec1 > best_prec1
        best_prec1 = max(prec1, best_prec1)
    else:
        for epoch in range(args.start_epoch, args.max_epoch+1):
            adjust_learning_rate(optimizer, epoch)

            # Train for one epoch
            train_rate(train_loader, model_rate, criterion, optimizer, epoch, f)
            
            # Evaluate on validation set
            prec1 = validate_rate(test_loader, model_rate, criterion, f)

            # Save checkpoint
            is_best = prec1 > best_prec1
            best_prec1 = max(prec1, best_prec1)
            if (epoch % 20 == 0) and (not args.save_dir is None):
                save_checkpoint({
                    'epoch': epoch + 1,
                    'state_dict': model_rate.state_dict(),
                    'best_prec1': best_prec1,
                    'optimizer' : optimizer.state_dict(),            
                }, is_best, filename=os.path.join(args.save_dir, 'checkpoint_{}.tar'.format(epoch)))

        best_prec1 = 0
        prec1 = validate_rate(test_loader, model_rate, criterion, f)
        is_best = prec1 > best_prec1
        best_prec1 = max(prec1, best_prec1)

    f.write('Summary\t/\tTotal time {:.3f}\t/\tBest prec@1 {:.3f}\n'.format(time.time()-start_time, best_prec1))
    
    args.not_testing = False 
    if args.not_testing:
        sys.exit(0)

    f.write("==> Testing Bing's ANN-SNN Conversion:\n")
    # Instantiate spike network
    model_spike_probe = model_resnet34_imagenet.ResNetSpike(dt=args.dt, t_end=args.t_end, in_coding='rate', snn_mode='full', if_mode='if', TTS=args.snn_TTS, fpi=args.snn_TTS)
    model_spike_probe = torch.nn.DataParallel(model_spike_probe).cuda()
    f.write(str(model_spike_probe)+'\n')
   
    # Run trained network through training dataset again to find maximum input to IFNeuron 
    weight_mapping = [('module.features.0.weight', 'module.features.1.weight'), 
		      ('module.features.3.weight', 'module.features.4.weight'), 
		      ('module.features.6.weight', 'module.features.7.weight'), 
		      ('module.features.10.delay_path.0.weight', 'module.features.12.weight'), 
		      ('module.features.10.delay_path.3.weight', 'module.features.15.weight'), 
		      ('module.features.11.delay_path.0.weight', 'module.features.21.weight'), 
		      ('module.features.11.delay_path.3.weight', 'module.features.24.weight'), 
		      ('module.features.12.delay_path.0.weight', 'module.features.30.weight'), 
		      ('module.features.12.delay_path.3.weight', 'module.features.33.weight'), 
		      ('module.features.13.delay_path.0.weight', 'module.features.39.weight'), 
		      ('module.features.13.delay_path.3.weight', 'module.features.42.weight'), 
		      ('module.features.14.delay_path.0.weight', 'module.features.48.weight'), 
		      ('module.features.14.delay_path.3.weight', 'module.features.51.weight'), 
		      ('module.features.15.delay_path.0.weight', 'module.features.57.weight'), 
		      ('module.features.15.delay_path.3.weight', 'module.features.60.weight'), 
		      ('module.features.16.delay_path.0.weight', 'module.features.66.weight'), 
		      ('module.features.16.delay_path.3.weight', 'module.features.69.weight'), 
		      ('module.features.17.delay_path.0.weight', 'module.features.75.weight'), 
		      ('module.features.17.delay_path.3.weight', 'module.features.78.weight'), 
		      ('module.features.18.delay_path.0.weight', 'module.features.84.weight'), 
		      ('module.features.18.delay_path.3.weight', 'module.features.87.weight'), 
		      ('module.features.19.delay_path.0.weight', 'module.features.93.weight'), 
		      ('module.features.19.delay_path.3.weight', 'module.features.96.weight'), 
		      ('module.features.20.delay_path.0.weight', 'module.features.102.weight'), 
		      ('module.features.20.delay_path.3.weight', 'module.features.105.weight'), 
		      ('module.features.21.delay_path.0.weight', 'module.features.111.weight'), 
		      ('module.features.21.delay_path.3.weight', 'module.features.114.weight'), 
		      ('module.features.22.delay_path.0.weight', 'module.features.120.weight'), 
		      ('module.features.22.delay_path.3.weight', 'module.features.123.weight'), 
		      ('module.features.23.delay_path.0.weight', 'module.features.129.weight'), 
		      ('module.features.23.delay_path.3.weight', 'module.features.132.weight'), 
		      ('module.features.24.delay_path.0.weight', 'module.features.138.weight'), 
		      ('module.features.24.delay_path.3.weight', 'module.features.141.weight'), 
		      ('module.features.25.delay_path.0.weight', 'module.features.147.weight'), 
		      ('module.features.25.delay_path.3.weight', 'module.features.150.weight'), 
		      ('module.classifier.0.weight', 'module.classifier.0.weight')]
    model_rate_dict = model_rate.state_dict() 
    model_spike_probe_dict = model_spike_probe.state_dict() 
    for source,target in weight_mapping:
        model_spike_probe_dict[target].copy_(model_rate_dict[source])

    # Normalize threshold value

    V_b = args.vth_vb
    V_u = args.vth_vu

    """
    start_time = time.time()
    model_spike_probe.eval()
    with torch.no_grad():
        l2_max_inp_ = torch.zeros(1).cuda()
        l5_max_inp_ = torch.zeros(1).cuda()
        l8_max_inp_ = torch.zeros(1).cuda()
        for i, (inp, target) in enumerate(train_loader):
            if i == 4:  break
            outp,l2_max_inp,l5_max_inp,l8_max_inp,spike_count = model_spike_probe(inp)
            l2_max_inp_ = torch.max(l2_max_inp_,torch.max(l2_max_inp))
        model_spike_probe.module.features[2].set_thres(float(l2_max_inp_))
        f.write('\tl2 threshold balancing {:.3f}\ttime {:.3f}\n'.format(float(torch.max(l2_max_inp_)),time.time()-start_time)); start_time = time.time()
        for i, (inp, target) in enumerate(train_loader):
            if i == 4:  break
            outp,l2_max_inp,l5_max_inp,l8_max_inp,spike_count = model_spike_probe(inp)
            l5_max_inp_ = torch.max(l5_max_inp_,torch.max(l5_max_inp))
        model_spike_probe.module.features[5].set_thres(float(l5_max_inp_))
        f.write('\tl5 threshold balancing {:.3f}\ttime {:.3f}\n'.format(float(torch.max(l5_max_inp_)),time.time()-start_time)); start_time = time.time()
        for i, (inp, target) in enumerate(train_loader):
            if i == 4:  break
            outp,l2_max_inp,l5_max_inp,l8_max_inp,spike_count = model_spike_probe(inp)
            l8_max_inp_ = torch.max(l8_max_inp_,torch.max(l8_max_inp))
        model_spike_probe.module.features[8].set_thres(float(l8_max_inp_))
        f.write('\tl8 threshold balancing {:.3f}\ttime {:.3f}\n'.format(float(torch.max(l8_max_inp_)),time.time()-start_time)); start_time = time.time()
    """

    model_spike = model_resnet34_imagenet.ResNetSpike(dt=args.dt, t_end=args.t_end, in_coding=args.in_coding, snn_mode=args.snn_mode, if_mode=args.if_mode, TTS=args.snn_TTS, fpi=args.snn_fpi)
    model_spike = torch.nn.DataParallel(model_spike).cuda()
    model_rate_dict = model_rate.state_dict()
    model_spike_dict = model_spike.state_dict()
    for source,target in weight_mapping:
        model_spike_dict[target].copy_(model_rate_dict[source])

    
    print('Use pre-computed thresholds for SNN')
    if args.snn_TTS <= 256:
        l2_max_inp_ = 19.184
        l5_max_inp_ = 5.988
        l8_max_inp_ = 4.199
    elif args.snn_TTS == 512:
        l2_max_inp_ = 19.365
        l5_max_inp_ = 5.853
        l8_max_inp_ = 5.184
    elif args.snn_TTS == 768:
        l2_max_inp_ = 19.365
        l5_max_inp_ = 5.492
        l8_max_inp_ = 5.184
    elif args.snn_TTS == 1024:
        l2_max_inp_ = 19.089
        l5_max_inp_ = 6.299
        l8_max_inp_ = 4.695
    elif args.snn_TTS == 1536:
        l2_max_inp_ = 18.98
        l5_max_inp_ = 5.979
        l8_max_inp_ = 4.508
    elif args.snn_TTS == 2048:
        l2_max_inp_ = 19.314
        l5_max_inp_ = 6.143
        l8_max_inp_ = 5.22
    elif args.snn_TTS == 3072:
        l2_max_inp_ = 19.314
        l5_max_inp_ = 6.034
        l8_max_inp_ = 4.786
    elif args.snn_TTS >= 4096:
        l2_max_inp_ = 19.591
        l5_max_inp_ = 6.033
        l8_max_inp_ = 5.027

    f.write('\tl2 threshold balancing {:.3f} \n '.format(float(l2_max_inp_)))
    f.write('\tl5 threshold balancing {:.3f} \n '.format(float(l5_max_inp_)))
    f.write('\tl8 threshold balancing {:.3f} \n '.format(float(l8_max_inp_)))


    model_spike.module.features[2].set_thres(float(l2_max_inp_*V_b+V_u))
    model_spike.module.features[5].set_thres(float(l5_max_inp_*V_b+V_u))
    model_spike.module.features[8].set_thres(float(l8_max_inp_*V_b+V_u))

   # Setting thresholds according to Abhronil's conversion 2500 Timesteps simulation
    model_spike.module.features[13].set_thres(1.0)
    model_spike.module.features[19].set_thres(1.0)
    model_spike.module.features[22].set_thres(1.0)
    model_spike.module.features[28].set_thres(1.0)
    model_spike.module.features[31].set_thres(1.0)
    model_spike.module.features[37].set_thres(1.0)

    model_spike.module.features[40].set_thres(1.0)
    model_spike.module.features[46].set_thres(1.0)
    model_spike.module.features[49].set_thres(1.0)
    model_spike.module.features[55].set_thres(1.0)
    model_spike.module.features[58].set_thres(1.0)
    model_spike.module.features[64].set_thres(1.0)
    model_spike.module.features[67].set_thres(1.0)
    model_spike.module.features[73].set_thres(1.0)

    model_spike.module.features[76].set_thres(1.0)
    model_spike.module.features[82].set_thres(1.0)
    model_spike.module.features[85].set_thres(1.0)
    model_spike.module.features[91].set_thres(1.0) 
    model_spike.module.features[94].set_thres(1.0)
    model_spike.module.features[100].set_thres(1.0)    
    model_spike.module.features[103].set_thres(1.0)
    model_spike.module.features[109].set_thres(1.0)
    model_spike.module.features[112].set_thres(1.0)
    model_spike.module.features[118].set_thres(1.0)
    model_spike.module.features[121].set_thres(1.0)
    model_spike.module.features[127].set_thres(1.0)    
    
    model_spike.module.features[130].set_thres(1.0)
    model_spike.module.features[136].set_thres(1.0)
    model_spike.module.features[139].set_thres(1.0)
    model_spike.module.features[145].set_thres(1.0)
    model_spike.module.features[148].set_thres(1.0)
    model_spike.module.features[154].set_thres(1.0)


    # Evaluate on validation set
    validate_spike(test_loader, model_spike, criterion, f)

    if not args.log is None:
        f.close()

def train_rate(train_loader, model, criterion, optimizer, epoch, f):
    """
        Run one train epoch
    """
    # switch to train mode
    model.train()

    start_time = time.time()
    acc_top1 = []
    acc_top5 = []
    acc_loss = []

    f.write('Epoch {:>3}\n'.format(epoch))
    for i, (inp, target) in enumerate(train_loader):
        target = target.cuda(non_blocking=True)

        # compute outp
        outp = model(inp)
        loss = criterion(outp, target)

        # measure accuracy and record loss
        prec1, prec5 = accuracy(outp, target, topk=(1, 5))
        acc_top1.append(float(prec1))
        acc_top5.append(float(prec5))
        acc_loss.append(float(loss))

        # compute gradient and do SGD step
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        
        if i%1000==0:
            f.write('\t({}/{})\tTime {:.3f}\tPrec@1 {:.3f}\tPrec@5 {:.3f}\tLoss {:.3f}\n'.format(i, len(train_loader), time.time()-start_time, np.mean(acc_top1), np.mean(acc_top5), np.mean(acc_loss)))
            start_time = time.time()

    f.write('\tSummary:\tPrec@1 {:.3f}\tPrec@5 {:.3f}\tLoss {:.3f}\t'.format(np.mean(acc_top1), np.mean(acc_top5), np.mean(acc_loss)))

def validate_spike(test_loader, model, criterion, f):
    """
    Run evaluation
    """
    # switch to evaluate mode
    model.eval()
    
    start_time = time.time()
    acc_top1 = []
    acc_top5 = []
    spike_count = []

    inp_neuron_count = 112*112*3   
 
    l2_neuron_count = 64*112*112
    l5_neuron_count = 64*112*112
    l8_neuron_count = 64*112*112

    l13_neuron_count = 64*56*56
    l19_neuron_count = 64*56*56
    l22_neuron_count = 64*56*56
    l28_neuron_count = 64*56*56
    l31_neuron_count = 64*56*56
    l37_neuron_count = 64*56*56

    l40_neuron_count = 128*28*28
    l46_neuron_count = 128*28*28
    l49_neuron_count = 128*28*28
    l55_neuron_count = 128*28*28
    l58_neuron_count = 128*28*28
    l64_neuron_count = 128*28*28
    l67_neuron_count = 128*28*28
    l73_neuron_count = 128*28*28

    l76_neuron_count = 256*14*14
    l82_neuron_count = 256*14*14
    l85_neuron_count = 256*14*14
    l91_neuron_count = 256*14*14
    l94_neuron_count = 256*14*14
    l100_neuron_count = 256*14*14
    l103_neuron_count = 256*14*14
    l109_neuron_count = 256*14*14
    l112_neuron_count = 256*14*14
    l118_neuron_count = 256*14*14
    l121_neuron_count = 256*14*14
    l127_neuron_count = 256*14*14

    l130_neuron_count = 512*7*7
    l136_neuron_count = 512*7*7
    l139_neuron_count = 512*7*7
    l145_neuron_count = 512*7*7
    l148_neuron_count = 512*7*7
    l154_neuron_count = 512*7*7
    spike_total = torch.zeros(2,160).cuda()

    with torch.no_grad():
        for i, (inp, target) in enumerate(tqdm(test_loader)):
            target = target.cuda(non_blocking=True)
            outp,l2_max_inp,l5_max_inp,l8_max_inp,spike_count = model(inp)
            loss = criterion(outp, target)
            # measure accuracy and record loss
            prec1, prec5 = accuracy(outp, target, topk=(1, 5))
            acc_top1.append(float(prec1))
            acc_top5.append(float(prec5))
            spike_total += torch.sum(spike_count, dim=0)
            
            if (i!=0) and (i%5==0):         
                f.write('\tTest {:>5} :\tTime {:.3f}\tPrec@1 {:.3f}\tPrec@5 {:.3f}\n'.format(i, time.time()-start_time, np.mean(acc_top1), np.mean(acc_top5)))

        f.write('\t*****************************************************************************\n')
        f.write('\tTest {:>5} :\tTime {:.3f}\tPrec@1 {:.3f}\tPrec@5 {:.3f}\n'.format(i, time.time()-start_time, np.mean(acc_top1), np.mean(acc_top5)))

        f.write('\t*****************************************************************************\n')
        f.write('\tFull-Frame Temporal RMP-SNN spike activities:\n')
        f.write('\tLayer  IN  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format( spike_total[0,1]/50000., inp_neuron_count))
        f.write('\tLayer   2  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format( spike_total[0,2]/50000., l2_neuron_count))
        f.write('\tLayer   5  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format( spike_total[0,5]/50000., l5_neuron_count))
        f.write('\tLayer   8  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format( spike_total[0,8]/50000., l8_neuron_count))
        f.write('\tLayer  13  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,13]/50000., l13_neuron_count))
        f.write('\tLayer  19  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,19]/50000., l19_neuron_count))
        f.write('\tLayer  22  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,22]/50000., l22_neuron_count))
        f.write('\tLayer  28  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,28]/50000., l28_neuron_count))
        f.write('\tLayer  31  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,31]/50000., l31_neuron_count))
        f.write('\tLayer  37  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,37]/50000., l37_neuron_count))
        f.write('\tLayer  40  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,40]/50000., l40_neuron_count))
        f.write('\tLayer  46  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,46]/50000., l46_neuron_count))
        f.write('\tLayer  49  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,49]/50000., l49_neuron_count))
        f.write('\tLayer  55  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,55]/50000., l55_neuron_count))
        f.write('\tLayer  58  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,58]/50000., l58_neuron_count))
        f.write('\tLayer  64  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,64]/50000., l64_neuron_count))
        f.write('\tLayer  67  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,67]/50000., l67_neuron_count))
        f.write('\tLayer  73  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,73]/50000., l73_neuron_count))
        f.write('\tLayer  76  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,76]/50000., l76_neuron_count))
        f.write('\tLayer  82  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,82]/50000., l82_neuron_count))
        f.write('\tLayer  85  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,85]/50000., l85_neuron_count))
        f.write('\tLayer  91  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,91]/50000., l91_neuron_count))
        f.write('\tLayer  94  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,94]/50000., l94_neuron_count))
        f.write('\tLayer 100  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,100]/50000., l100_neuron_count))
        f.write('\tLayer 103  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,103]/50000., l103_neuron_count))
        f.write('\tLayer 109  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,109]/50000., l109_neuron_count))
        f.write('\tLayer 112  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,112]/50000., l112_neuron_count))
        f.write('\tLayer 118  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,118]/50000., l118_neuron_count))
        f.write('\tLayer 121  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,121]/50000., l121_neuron_count))
        f.write('\tLayer 127  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,127]/50000., l127_neuron_count))
        f.write('\tLayer 130  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,130]/50000., l130_neuron_count))
        f.write('\tLayer 136  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,136]/50000., l136_neuron_count))
        f.write('\tLayer 139  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,139]/50000., l139_neuron_count))
        f.write('\tLayer 145  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,145]/50000., l145_neuron_count))
        f.write('\tLayer 148  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,148]/50000., l148_neuron_count))
        f.write('\tLayer 154  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,154]/50000., l154_neuron_count))

        f.write('\t*****************************************************************************\n')
        f.write('\tDelta-Frame Temporal TSC-SNN spike activities:\n')
        f.write('\tLayer  IN  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format( spike_total[1,1]/50000., inp_neuron_count))
        f.write('\tLayer   2  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format( spike_total[1,2]/50000., l2_neuron_count))
        f.write('\tLayer   5  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format( spike_total[1,5]/50000., l5_neuron_count))
        f.write('\tLayer   8  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format( spike_total[1,8]/50000., l8_neuron_count))
        f.write('\tLayer  13  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[1,13]/50000., l13_neuron_count))
        f.write('\tLayer  19  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[1,19]/50000., l19_neuron_count))
        f.write('\tLayer  22  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[1,22]/50000., l22_neuron_count))
        f.write('\tLayer  28  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[1,28]/50000., l28_neuron_count))
        f.write('\tLayer  31  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[1,31]/50000., l31_neuron_count))
        f.write('\tLayer  37  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[1,37]/50000., l37_neuron_count))
        f.write('\tLayer  40  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[1,40]/50000., l40_neuron_count))
        f.write('\tLayer  46  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[1,46]/50000., l46_neuron_count))
        f.write('\tLayer  49  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[1,49]/50000., l49_neuron_count))
        f.write('\tLayer  55  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[1,55]/50000., l55_neuron_count))
        f.write('\tLayer  58  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[1,58]/50000., l58_neuron_count))
        f.write('\tLayer  64  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[1,64]/50000., l64_neuron_count))
        f.write('\tLayer  67  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[1,67]/50000., l67_neuron_count))
        f.write('\tLayer  73  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[1,73]/50000., l73_neuron_count))
        f.write('\tLayer  76  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[1,76]/50000., l76_neuron_count))
        f.write('\tLayer  82  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[1,82]/50000., l82_neuron_count))
        f.write('\tLayer  85  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[1,85]/50000., l85_neuron_count))
        f.write('\tLayer  91  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[1,91]/50000., l91_neuron_count))
        f.write('\tLayer  94  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[1,94]/50000., l94_neuron_count))
        f.write('\tLayer 100  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[1,100]/50000., l100_neuron_count))
        f.write('\tLayer 103  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[1,103]/50000., l103_neuron_count))
        f.write('\tLayer 109  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[1,109]/50000., l109_neuron_count))
        f.write('\tLayer 112  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[1,112]/50000., l112_neuron_count))
        f.write('\tLayer 118  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[1,118]/50000., l118_neuron_count))
        f.write('\tLayer 121  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[1,121]/50000., l121_neuron_count))
        f.write('\tLayer 127  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[1,127]/50000., l127_neuron_count))
        f.write('\tLayer 130  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[1,130]/50000., l130_neuron_count))
        f.write('\tLayer 136  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[1,136]/50000., l136_neuron_count))
        f.write('\tLayer 139  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[1,139]/50000., l139_neuron_count))
        f.write('\tLayer 145  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[1,145]/50000., l145_neuron_count))
        f.write('\tLayer 148  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[1,148]/50000., l148_neuron_count))
        f.write('\tLayer 154  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[1,154]/50000., l154_neuron_count))

    return np.mean(acc_top1)

def validate_rate(test_loader, model, criterion, f):
    """
    Run evaluation
    """
    # switch to evaluate mode
    model.eval()
    
    start_time = time.time()
    acc_top1 = []
    acc_top5 = []

    with torch.no_grad():
        for i, (inp, target) in enumerate(test_loader):
            target = target.cuda(non_blocking=True)

            # compute outp
            outp = model(inp)
            loss = criterion(outp, target)

            # measure accuracy and record loss
            prec1, prec5 = accuracy(outp, target, topk=(1, 5))
            acc_top1.append(float(prec1))
            acc_top5.append(float(prec5))

    f.write('/\tTest:\tTime {:.3f}\tPrec@1 {:.3f}\tPrec@5 {:.3f}\n'.format(time.time()-start_time, np.mean(acc_top1), np.mean(acc_top5)))

    return np.mean(acc_top1)

def save_checkpoint(state, is_best, filename='checkpoint.tar'):
    """
    Save the training model
    """
    torch.save(state, filename)

def adjust_learning_rate(optimizer, cur_epoch):
    # Reduce learning rate by 10 twice at epoch 81 and 122
    if cur_epoch == 30 or cur_epoch == 60:
        for param_group in optimizer.param_groups:
            param_group['lr'] /= 10


def accuracy(outp, target, topk=(1,)):
    """Computes the precision@k for the specified values of k"""
    with torch.no_grad():
        maxk = max(topk)
        batch_size = target.size(0)

        _, pred = outp.topk(maxk, 1, True, True)
        pred = pred.t()
        correct = pred.eq(target.view(1, -1).expand_as(pred))

        res = []
        for k in topk:
            correct_k = correct[:k].view(-1).float().sum(0, keepdim=True)
            res.append(correct_k.mul_(100.0 / batch_size))
        return res

if __name__ == '__main__':
    main()
