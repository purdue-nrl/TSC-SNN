
import torch
import torch.nn as nn
import math

# Poisson spike generator
#   This module generates spike based on assumption that input is between 1 and -1
#   Positive spike is generated (i.e. 1 is return) if rand()<abs(input) and sign(input)=1
#   Negative spike is generated (i.e. -1 is return) if rand()<abs(input) and sign(input)=-1
#   This method is corresponding to Method 1 on Page 5 of lecture note http://www.cns.nyu.edu/~david/handouts/poisson.pdf
class PoissonGen(nn.Module):
    def __init__(self):
        super(PoissonGen, self).__init__()
    def forward(self, inp, t, N, en_IN):
        # nbits = 32
        # inp_disc= torch.round(inp*(2^nbits-1))/(2^nbits-1)
        if en_IN:
            op=1.0
        else:
            op=0.0
        # return op*torch.mul(torch.le(torch.rand_like(inp), torch.abs(inp_disc)).float(), torch.sign(inp))
        return op*torch.mul(torch.le(torch.rand_like(inp), torch.abs(inp)).float(), torch.sign(inp))


# Temporal spikes generator
class TemporalGen(nn.Module):
    def __init__(self):
        super(TemporalGen, self).__init__()
    def forward(self, inp, t, N, en_IN):

        if en_IN:
            op=1.0
        else:
            op=0.0

        outp = op * torch.mul(torch.mul( torch.ge(inp*0+t, ((N+1)/2)*(1-torch.abs(inp))).float(),
                                         torch.le(inp*0+t, ((N+1)/2)*(1+torch.abs(inp))).float()), torch.sign(inp))
        return outp


# Integrate-and-fire neuron (IFNeuron)
#   This module is slightly from IFNeuron module in the script that I have sent to Gopal and Priya earlier.
#   This module models simple IFNeuron without any refractory period
#   This modeule does not have state information, thus allowing it to be parallelized across GPUs when torch.nn.DataParallel is wrapped around
#   As a result, this module takes two arguments: input and previous IFNeuron membrane potential
#   Spike is generated if IFNeuron membrane potential reachs defined threshold
#   Spike output is return with new IFNeuron membrane potential
class IFNeuron(nn.Module):
    # Argument inplace does not have any use. You can ignore it. 
    def __init__(self, inplace=True, thres=1.0):
        super(IFNeuron, self).__init__()
        self.thres = thres
    def forward(self, inp, mem_potential, IF_spiking, IF_residual):
        mem_potential += inp
        outp = mem_potential*0.0
        if IF_spiking:
            outp = torch.ge(mem_potential, self.thres)
            if IF_residual:
                mem_potential[outp] = (mem_potential[outp] - self.thres)*1.0  # Residual-IF neuron
            else:
                mem_potential[outp] = (mem_potential[outp] - self.thres)*0.0  # IF neuron
        return outp.float(), mem_potential
    def set_thres(self, thres):
        self.thres = thres
    def get_thres(self):
        return self.thres
    def extra_repr(self):
        return 'thres={}'.format(self.thres)

# Function to create convolutional layer
#   When is_spike=False, this function creates convolutional layer for rate-based VGG network
#   When is_spike=True, this function creates convolutional layer for spiking VGG network 
#   Convolutional layetures(is_spike, is_temp):
def make_features(is_spike, is_temp):
    batch_norm = False
    list_m = []
    in_channels = 3

    if is_spike:
        if is_temp:
            list_m.append(TemporalGen())
        else:
            list_m.append(PoissonGen())
        act_func = IFNeuron
    else:
        act_func = nn.ReLU

    for out_channels in [64, 64, 'A', 128, 128, 'A', 256, 256, 256, 'A', 512, 512, 512, 'A', 512, 512, 512, 'A']:
        if out_channels == 'A':
            list_m += [nn.AvgPool2d(kernel_size=(2,2), stride=(2,2))]
        elif out_channels == 'M':
            list_m += [nn.MaxPool2d(kernel_size=(2,2), stride=(2,2))]
        elif out_channels == 'D':
                list_m += [nn.Dropout(p=0.3)]
        else:
            list_m += [nn.Conv2d(in_channels, out_channels, kernel_size=(3,3), stride=(1,1), padding=(1,1), bias=False)]
            if batch_norm:
                list_m += [nn.BatchNorm2d(out_channels), act_func(inplace=True)]
            else:
                list_m += [act_func(inplace=True)]
            in_channels = out_channels
    return make_hierarchy(list_m,is_spike)


# Make fully connected layer 
#   When is_spike=False, this function creates fully-connected layer for rate-based VGG network
#   When is_spike=True, this function creates fully-connected layer for spiking VGG network 
#   Convolutional layer structure follows model from https://github.com/szagoruyko/cifar.torch/blob/master/models/vgg_bn_drop.lua w/o batch normalization and bias

def make_classifier(is_spike):
    if is_spike:
        act_func = IFNeuron
    else:
        act_func = nn.ReLU

    list_m = []
    list_m += [nn.Linear(25088, 4096, bias=False)]  
    list_m += [act_func(inplace=True)]
    list_m += [nn.Dropout(p=0.5)]
    list_m += [nn.Linear(4096, 4096, bias=False)]
    list_m += [act_func(inplace=True)]
    list_m += [nn.Dropout(p=0.5)]
    list_m += [nn.Linear(4096, 1000, bias=False)]
    return make_hierarchy(list_m,is_spike)


# Convert list of modules into torch.nn.ModuleList or torch.nn.Sequentual
#   For spiking simulation, we prefer modules to be stacked in torch.nn.ModuleList because output of modules are accessed at multiple points
#   During threshold balancing, we, for example, need to get maximum input to a particular IFNeuron. Having module in torch.nn.Sequential does allow us to access intermediate values easily 
def make_hierarchy(list_m,is_spike):
     if is_spike:
         return nn.ModuleList(list_m)
     else:
         return nn.Sequential(*list_m)

# Spiking version of simple network
class VGGSpike(nn.Module):
    def __init__(self, dt=0.001, t_end=0.128, in_coding='rate', snn_mode='full', if_mode='if', TTS=256, fpi=128):
        super(VGGSpike, self).__init__()
        # Save network parameters

        self.dt = dt
        self.t_end = t_end
        self.TTS = TTS
        self.fpi = fpi+1
        self.in_coding = in_coding
        self.snn_mode = snn_mode
        self.if_mode = if_mode

        if self.if_mode == 'residual':
            self.is_residual = True
        elif self.if_mode == 'if':
            self.is_residual = False

        if self.in_coding == 'temp':
            is_temp = True
        elif self.in_coding == 'rate':
            is_temp = False

        # Instantiate layers
        self.features = make_features(is_spike=True, is_temp=is_temp)
        self.classifier = make_classifier(is_spike=True)
        self.initialize_weights()
        self.initialize_thresholds()


    def initialize_thresholds(self):
        th = 1.0
        self.features[2].set_thres(th)
        self.features[4].set_thres(th)
        self.features[7].set_thres(th)
        self.features[9].set_thres(th)
        self.features[12].set_thres(th)
        self.features[14].set_thres(th)
        self.features[16].set_thres(th)
        self.features[19].set_thres(th)
        self.features[21].set_thres(th)
        self.features[23].set_thres(th)
        self.features[26].set_thres(th)
        self.features[28].set_thres(th)
        self.features[30].set_thres(th)
        self.classifier[1].set_thres(th)
        self.classifier[4].set_thres(th)
     

    def initialize_weights(self):
        for m in self.modules():
            # Only reinitialize for spatial convolutional layer
            if isinstance(m, nn.Conv2d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                m.weight.data.normal_(0, math.sqrt(2. / n))
                if m.bias is not None:
                    m.bias.data.zero_()
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                if m.bias is not None:
                    m.bias.data.zero_()
            elif isinstance(m, nn.Linear):
                n = m.weight.size(1)
                m.weight.data.normal_(0, 0.01)
                if m.bias is not None:
                    m.bias.data.zero_()

    def forward(self, inp):
        # Code in this forward function is automatically generated by running this script
        #   $ python model_vgg16_cifar10.py
        # XX_mem_potential stores membrane potential of IFNeuron at layer XX
        # XX_max_inp stores maximum input to IFNeuon at layer XX 

        outp_sum = torch.zeros(inp.size(0),1000).cuda()
        l2_mem_potential = torch.zeros(inp.size(0),64,224,224).cuda()
        l2_max_inp = torch.zeros(inp.size(0),1).cuda()
        l2_pre_inp = torch.zeros(inp.size(0),64,224,224).cuda()
        l3_pre_inp = torch.zeros(inp.size(0),64,224,224).cuda()

        l4_mem_potential = torch.zeros(inp.size(0),64,224,224).cuda()
        l4_max_inp = torch.zeros(inp.size(0),1).cuda()
        l4_pre_inp = torch.zeros(inp.size(0),64,224,224).cuda()
        l5_pre_inp = torch.zeros(inp.size(0),64,224,224).cuda()

        l7_mem_potential = torch.zeros(inp.size(0),128,112,112).cuda()
        l7_max_inp = torch.zeros(inp.size(0),1).cuda()
        l7_pre_inp = torch.zeros(inp.size(0),128,112,112).cuda()
        l8_pre_inp = torch.zeros(inp.size(0),128,112,112).cuda()

        l9_mem_potential = torch.zeros(inp.size(0),128,112,112).cuda()
        l9_max_inp = torch.zeros(inp.size(0),1).cuda()
        l9_pre_inp = torch.zeros(inp.size(0),128,112,112).cuda()
        l10_pre_inp = torch.zeros(inp.size(0),128,112,112).cuda()

        l12_mem_potential = torch.zeros(inp.size(0),256,56,56).cuda()
        l12_max_inp = torch.zeros(inp.size(0),1).cuda()
        l12_pre_inp = torch.zeros(inp.size(0),256,56,56).cuda()
        l13_pre_inp = torch.zeros(inp.size(0),256,56,56).cuda()

        l14_mem_potential = torch.zeros(inp.size(0),256,56,56).cuda()
        l14_max_inp = torch.zeros(inp.size(0),1).cuda()
        l14_pre_inp = torch.zeros(inp.size(0),256,56,56).cuda()
        l15_pre_inp = torch.zeros(inp.size(0),256,56,56).cuda()

        l16_mem_potential = torch.zeros(inp.size(0),256,56,56).cuda()
        l16_max_inp = torch.zeros(inp.size(0),1).cuda()
        l16_pre_inp = torch.zeros(inp.size(0),256,56,56).cuda()
        l17_pre_inp = torch.zeros(inp.size(0),256,56,56).cuda()

        l19_mem_potential = torch.zeros(inp.size(0),512,28,28).cuda()
        l19_max_inp = torch.zeros(inp.size(0),1).cuda()
        l19_pre_inp = torch.zeros(inp.size(0),512,28,28).cuda()
        l20_pre_inp = torch.zeros(inp.size(0),512,28,28).cuda()

        l21_mem_potential = torch.zeros(inp.size(0),512,28,28).cuda()
        l21_max_inp = torch.zeros(inp.size(0),1).cuda()
        l21_pre_inp = torch.zeros(inp.size(0),512,28,28).cuda()
        l22_pre_inp = torch.zeros(inp.size(0),512,28,28).cuda()
 
        l23_mem_potential = torch.zeros(inp.size(0),512,28,28).cuda()
        l23_max_inp = torch.zeros(inp.size(0),1).cuda()
        l23_pre_inp = torch.zeros(inp.size(0),512,28,28).cuda()
        l24_pre_inp = torch.zeros(inp.size(0),512,28,28).cuda()

        l26_mem_potential = torch.zeros(inp.size(0),512,14,14).cuda()
        l26_max_inp = torch.zeros(inp.size(0),1).cuda()
        l26_pre_inp = torch.zeros(inp.size(0),512,14,14).cuda()
        l27_pre_inp = torch.zeros(inp.size(0),512,14,14).cuda()

        l28_mem_potential = torch.zeros(inp.size(0),512,14,14).cuda()
        l28_max_inp = torch.zeros(inp.size(0),1).cuda()
        l28_pre_inp = torch.zeros(inp.size(0),512,14,14).cuda()
        l29_pre_inp = torch.zeros(inp.size(0),512,14,14).cuda()

        l30_mem_potential = torch.zeros(inp.size(0),512,14,14).cuda()
        l30_max_inp = torch.zeros(inp.size(0),1).cuda()
        l30_pre_inp = torch.zeros(inp.size(0),512,14,14).cuda()
        l31_pre_inp = torch.zeros(inp.size(0),512,14,14).cuda()

        fc1_mem_potential = torch.zeros(inp.size(0),4096).cuda()
        fc1_max_inp = torch.zeros(inp.size(0),1).cuda()
        fc1_pre_inp = torch.zeros(inp.size(0),4096).cuda()
        fc2_pre_inp = torch.zeros(inp.size(0),4096).cuda()

        fc4_mem_potential = torch.zeros(inp.size(0),4096).cuda()
        fc4_max_inp = torch.zeros(inp.size(0),1).cuda()
        fc4_pre_inp = torch.zeros(inp.size(0),4096).cuda()
        fc5_pre_inp = torch.zeros(inp.size(0),4096).cuda()

        spike_count = torch.zeros(1,200).cuda()
        # Simulating spiking network over time inside the module, thus allow simulation to be parallelized across GPUs when torch.nn.DataParallel is wrapped around

        count = torch.zeros(1).cuda()

        self.en_IN = True
        self.en_IF = True
        l2_on = True
        l4_on = True
        l7_on = True

        l9_on = True
        l12_on = True
        l14_on = True

        l16_on = True
        l19_on = True
        l21_on = True

        l23_on = True
        l26_on = True
        l28_on = True
        l30_on = True

        fc1_on = True
        fc4_on = True

        for ts in range(self.TTS):

            count = count + 1
            if count%self.fpi==0:
                count = 1
            # print('timestep {}, en_IN = {}, en_IF = {}, fpi = {}, TTS = {}'.format(ts, self.en_IN, self.en_IF, self.fpi, self.TTS))  
            # generate delta-frame inputs to synapse of layer 1
            if count == 1:
                outp = self.features[0](inp, count, self.fpi, self.en_IN) # spike-input
            else:
                outp = self.features[0](inp, count, self.fpi, self.en_IN) - self.features[0](inp, count-1, self.fpi, self.en_IN)
            spike_count[0,101] += torch.sum(torch.abs(outp))
            spike_count[0,1] += torch.sum(torch.abs(self.features[0](inp, count, self.fpi, self.en_IN)))
            # print('spike_count_full = {}, spike_count_delt = {}'.format(torch.sum(torch.abs(self.features[0](inp, count, self.fpi, self.en_IN))), torch.sum(torch.abs(outp))))  
            outp = self.features[1](outp) # synapse
            # reconstruct spiking neuron full-frame inputs to layer 2
            if count == 1:
                l2_pre_inp = outp
            else:
                outp += l2_pre_inp
                l2_pre_inp = outp
            l2_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l2_max_inp)
            outp,l2_mem_potential = self.features[2](outp,l2_mem_potential, False, self.is_residual)
            spike_count[0,2] += torch.sum(torch.abs(outp))


        count = 1
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp = 0*l2_mem_potential
            outp,l2_mem_potential = self.features[2](outp,l2_mem_potential, True, self.is_residual)
            spike_count[0,2] += torch.sum(torch.abs(outp))

            # generate delta-frame inputs to synapse of layer 3 
            if count == 1:
                l3_pre_inp = outp
            else:
                outp = outp - l3_pre_inp
                l3_pre_inp = l3_pre_inp + outp

            spike_count[0,102] += torch.sum(torch.abs(outp))
            outp = self.features[3](outp) # synapse
            # reconstruct spiking neuron full-frame inputs to layer 4
            if count == 1:
                l4_pre_inp = outp
            else:
                outp += l4_pre_inp
                l4_pre_inp = outp
            l4_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l4_max_inp)
            outp,l4_mem_potential = self.features[4](outp,l4_mem_potential, False, self.is_residual)
            # print('   layer 4, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l4_mem_potential), torch.min(l4_mem_potential), l4_mem_potential.shape))
            spike_count[0,4] += torch.sum(torch.abs(outp))


        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp = 0*l4_mem_potential
            outp,l4_mem_potential = self.features[4](outp,l4_mem_potential, True, self.is_residual)
            spike_count[0,4] += torch.sum(torch.abs(outp))

            # generate delta-frame inputs to synapse of layer 6
            if count == 1:
                l5_pre_inp = outp
            else:
                outp = outp - l5_pre_inp
                l5_pre_inp = l5_pre_inp + outp
            spike_count[0,104] += torch.sum(torch.abs(outp))
            outp = self.features[5](outp) # pooling
            outp = self.features[6](outp) # synapse
            # reconstruct spiking neuron full-frame inputs to layer 7
            if count == 1:
                l7_pre_inp = outp
            else:
                outp += l7_pre_inp
                l7_pre_inp = outp
            l7_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l7_max_inp)
            outp,l7_mem_potential = self.features[7](outp,l7_mem_potential, False, self.is_residual)
            # print('        layer 7, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l7_mem_potential), torch.min(l7_mem_potential), l7_mem_potential.shape))
            spike_count[0,7] += torch.sum(outp)


        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp = 0*l7_mem_potential
            outp,l7_mem_potential = self.features[7](outp,l7_mem_potential, True, self.is_residual)
            spike_count[0,7] += torch.sum(outp)

            # generate delta-frame inputs to synapse of layer 8
            if count == 1:
                l8_pre_inp = outp
            else:
                outp = outp - l8_pre_inp
                l8_pre_inp = l8_pre_inp + outp
            spike_count[0,107] += torch.sum(torch.abs(outp))
            outp = self.features[8](outp) # synapse
            # reconstruct spiking neuron full-frame inputs to layer 9
            if count == 1:
                l9_pre_inp = outp
            else:
                outp += l9_pre_inp
                l9_pre_inp = outp
            l9_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l9_max_inp)
            outp,l9_mem_potential = self.features[9](outp,l9_mem_potential, False, self.is_residual)
            # print('        layer 9, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l9_mem_potential), torch.min(l9_mem_potential), l9_mem_potential.shape))
            spike_count[0,9] += torch.sum(outp)


        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1 
            outp = 0*l9_mem_potential
            outp,l9_mem_potential = self.features[9](outp,l9_mem_potential, True, self.is_residual)
            spike_count[0,9] += torch.sum(outp)   

            # generate delta-frame inputs to synapse of layer 11
            if count == 1:
                l10_pre_inp = outp
            else:
                outp = outp - l10_pre_inp
                l10_pre_inp = l10_pre_inp + outp  
            spike_count[0,109] += torch.sum(torch.abs(outp))  
            outp = self.features[10](outp) # pooling
            outp = self.features[11](outp) # synapse
            # reconstruct spiking neuron full-frame inputs to layer 12
            if count == 1:
                l12_pre_inp = outp
            else:
                outp += l12_pre_inp
                l12_pre_inp = outp
            l12_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l12_max_inp)
            outp,l12_mem_potential = self.features[12](outp,l12_mem_potential, False, self.is_residual)
            # print('        layer 12, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l12_mem_potential), torch.min(l12_mem_potential), l12_mem_potential.shape))
            spike_count[0,12] += torch.sum(outp)


        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp = 0*l12_mem_potential
            outp,l12_mem_potential = self.features[12](outp,l12_mem_potential, True, self.is_residual)
            spike_count[0,12] += torch.sum(outp)

            # generate delta-frame inputs to synapse of layer 13
            if count == 1:
                l13_pre_inp = outp
            else:
                outp = outp - l13_pre_inp
                l13_pre_inp = l13_pre_inp + outp
            spike_count[0,112] += torch.sum(torch.abs(outp))
            outp = self.features[13](outp) # synapse
            # reconstruct spiking neuron full-frame inputs to layer 14
            if count == 1:
                l14_pre_inp = outp
            else:
                outp += l14_pre_inp
                l14_pre_inp = outp
            l14_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l14_max_inp)
            outp,l14_mem_potential = self.features[14](outp,l14_mem_potential, False, self.is_residual)
            # print('        layer 14, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l14_mem_potential), torch.min(l14_mem_potential), l14_mem_potential.shape))
            spike_count[0,14] += torch.sum(outp)


        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp = 0*l14_mem_potential
            outp,l14_mem_potential = self.features[14](outp,l14_mem_potential, True, self.is_residual)
            spike_count[0,14] += torch.sum(outp)

            # generate delta-frame inputs to synapse of layer 15
            if count == 1:
                l15_pre_inp = outp
            else:
                outp = outp - l15_pre_inp
                l15_pre_inp = l15_pre_inp + outp
            spike_count[0,114] += torch.sum(torch.abs(outp))
            outp = self.features[15](outp) # synapse
            # reconstruct spiking neuron full-frame inputs to layer 16
            if count == 1:
                l16_pre_inp = outp
            else:
                outp += l16_pre_inp
                l16_pre_inp = outp
            l16_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l16_max_inp)
            outp,l16_mem_potential = self.features[16](outp,l16_mem_potential, False, self.is_residual)
            # print('        layer 16, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l16_mem_potential), torch.min(l16_mem_potential), l16_mem_potential.shape))
            spike_count[0,16] += torch.sum(outp)


        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp = 0*l16_mem_potential
            outp,l16_mem_potential = self.features[16](outp,l16_mem_potential, True, self.is_residual)
            spike_count[0,16] += torch.sum(outp)

            # generate delta-frame inputs to synapse of layer 18
            if count == 1:
                l17_pre_inp = outp
            else:
                outp = outp - l17_pre_inp
                l17_pre_inp = l17_pre_inp + outp
            spike_count[0,116] += torch.sum(torch.abs(outp))
            outp = self.features[17](outp) # pooling
            outp = self.features[18](outp) # synapse
            # reconstruct spiking neuron full-frame inputs to layer 19
            if count == 1:
                l19_pre_inp = outp
            else:
                outp += l19_pre_inp
                l19_pre_inp = outp
            l19_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l19_max_inp)
            outp,l19_mem_potential = self.features[19](outp,l19_mem_potential, False, self.is_residual)
            # print('        layer 19, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l19_mem_potential), torch.min(l19_mem_potential), l19_mem_potential.shape))
            spike_count[0,19] += torch.sum(outp)


        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp = 0*l19_mem_potential
            outp,l19_mem_potential = self.features[19](outp,l19_mem_potential, True, self.is_residual)
            spike_count[0,19] += torch.sum(outp)

            # generate delta-frame inputs to synapse of layer 20
            if count == 1:
                l20_pre_inp = outp
            else:
                outp = outp - l20_pre_inp
                l20_pre_inp = l20_pre_inp + outp
            spike_count[0,119] += torch.sum(torch.abs(outp))
            outp = self.features[20](outp) # synapse
            # reconstruct spiking neuron full-frame inputs to layer 21
            if count == 1:
                l21_pre_inp = outp
            else:
                outp += l21_pre_inp
                l21_pre_inp = outp
            l21_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l21_max_inp)
            outp,l21_mem_potential = self.features[21](outp,l21_mem_potential, False, self.is_residual)
            # print('        layer 21, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l21_mem_potential), torch.min(l21_mem_potential), l21_mem_potential.shape))
            spike_count[0,21] += torch.sum(outp)


        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp = 0*l21_mem_potential
            outp,l21_mem_potential = self.features[21](outp,l21_mem_potential, True, self.is_residual)
            spike_count[0,21] += torch.sum(outp)

            # generate delta-frame inputs to synapse of layer 22
            if count == 1:
                l22_pre_inp = outp
            else:
                outp = outp - l22_pre_inp
                l22_pre_inp = l22_pre_inp + outp
            spike_count[0,121] += torch.sum(torch.abs(outp))
            outp = self.features[22](outp) # synapse
            # reconstruct spiking neuron full-frame inputs to layer 23
            if count == 1:
                l23_pre_inp = outp
            else:
                outp += l23_pre_inp
                l23_pre_inp = outp
            l23_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l23_max_inp)
            outp,l23_mem_potential = self.features[23](outp,l23_mem_potential, False, self.is_residual)
            # print('        layer 23, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l23_mem_potential), torch.min(l23_mem_potential), l23_mem_potential.shape))
            spike_count[0,23] += torch.sum(outp)


        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp = 0*l23_mem_potential
            outp,l23_mem_potential = self.features[23](outp,l23_mem_potential, True, self.is_residual)
            spike_count[0,23] += torch.sum(outp)

            # generate delta-frame inputs to synapse of layer 25
            if count == 1:
                l24_pre_inp = outp
            else:
                outp = outp - l24_pre_inp
                l24_pre_inp = l24_pre_inp + outp
            spike_count[0,123] += torch.sum(torch.abs(outp))
            outp = self.features[24](outp) # pooling
            outp = self.features[25](outp) # synapse
            # reconstruct spiking neuron full-frame inputs to layer 26
            if count == 1:
                l26_pre_inp = outp
            else:
                outp += l26_pre_inp
                l26_pre_inp = outp
            l26_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l26_max_inp)
            outp,l26_mem_potential = self.features[26](outp,l26_mem_potential, False, self.is_residual)
            # print('        layer 26, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l26_mem_potential), torch.min(l26_mem_potential), l26_mem_potential.shape))
            spike_count[0,26] += torch.sum(outp)


        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp = 0*l26_mem_potential
            outp,l26_mem_potential = self.features[26](outp,l26_mem_potential, True, self.is_residual)
            spike_count[0,26] += torch.sum(outp)

            # generate delta-frame inputs to synapse of layer 27
            if count == 1:
                l27_pre_inp = outp
            else:
                outp = outp - l27_pre_inp
                l27_pre_inp = l27_pre_inp + outp
            spike_count[0,126] += torch.sum(torch.abs(outp))
            outp = self.features[27](outp) # synapse      
            # reconstruct spiking neuron full-frame inputs to layer 28
            if count == 1:
                l28_pre_inp = outp
            else:
                outp += l28_pre_inp
                l28_pre_inp = outp
            l28_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l28_max_inp)
            outp,l28_mem_potential = self.features[28](outp,l28_mem_potential, False, self.is_residual)
            # print('        layer 28, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l28_mem_potential), torch.min(l28_mem_potential), l28_mem_potential.shape))
            spike_count[0,28] += torch.sum(outp)


        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp = 0*l28_mem_potential
            outp,l28_mem_potential = self.features[28](outp,l28_mem_potential, True, self.is_residual)
            spike_count[0,28] += torch.sum(outp)

            # generate delta-frame inputs to synapse of layer 29
            if count == 1:
                l29_pre_inp = outp
            else:
                outp = outp - l29_pre_inp
                l29_pre_inp = l29_pre_inp + outp
            spike_count[0,128] += torch.sum(torch.abs(outp))
            outp = self.features[29](outp) # synapse
            # reconstruct spiking neuron full-frame inputs to layer 30
            if count == 1:
                l30_pre_inp = outp
            else:
                outp += l30_pre_inp
                l30_pre_inp = outp
            l30_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l30_max_inp)
            outp,l30_mem_potential = self.features[30](outp,l30_mem_potential, False, self.is_residual)
            # print('        layer 30, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l30_mem_potential), torch.min(l30_mem_potential), l30_mem_potential.shape))
            spike_count[0,30] += torch.sum(outp)


        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp = 0*l30_mem_potential
            outp,l30_mem_potential = self.features[30](outp,l30_mem_potential, True, self.is_residual)
            spike_count[0,30] += torch.sum(outp)

            # generate delta-frame inputs to synapse of layer fc0
            if count == 1:
                l31_pre_inp = outp
            else:
                outp = outp - l31_pre_inp
                l31_pre_inp = l31_pre_inp + outp
            spike_count[0,130] += torch.sum(torch.abs(outp))
            outp = self.features[31](outp) # pooling
            outp = self.classifier[0](outp.view(outp.size(0), -1)) # fc0 synapse
            # reconstruct spiking neuron full-frame inputs to layer fc1
            if count == 1:
                fc1_pre_inp = outp
            else:
                outp += fc1_pre_inp
                fc1_pre_inp = outp        
            fc1_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],fc1_max_inp)
            outp,fc1_mem_potential = self.classifier[1](outp,fc1_mem_potential, False, self.is_residual)
            # print('        layer fc1, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(fc1_mem_potential), torch.min(fc1_mem_potential), fc1_mem_potential.shape))
            spike_count[0,41] += torch.sum(outp)


        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp = 0*fc1_mem_potential
            outp,fc1_mem_potential = self.classifier[1](outp,fc1_mem_potential, True, self.is_residual)
            spike_count[0,41] += torch.sum(outp)

            # generate delta-frame inputs to synapse of layer fc3
            if count == 1:
                fc2_pre_inp = outp
            else:
                outp = outp - fc2_pre_inp
                fc2_pre_inp = fc2_pre_inp + outp
            spike_count[0,141] += torch.sum(torch.abs(outp))
            outp = self.classifier[2](outp) # dropout
            outp = self.classifier[3](outp) # fc3 synapse
            # reconstruct spiking neuron full-frame inputs to layer fc4
            if count == 1:
                fc4_pre_inp = outp
            else:
                outp += fc4_pre_inp
                fc4_pre_inp = outp
            fc4_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],fc4_max_inp)
            outp,fc4_mem_potential = self.classifier[4](outp,fc4_mem_potential, False, self.is_residual)
            # print('        layer fc4, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(fc4_mem_potential), torch.min(fc4_mem_potential), fc4_mem_potential.shape))
            spike_count[0,44] += torch.sum(outp)


        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp = 0*fc4_mem_potential
            outp,fc4_mem_potential = self.classifier[4](outp,fc4_mem_potential, True, self.is_residual)
            spike_count[0,44] += torch.sum(outp)
            spike_count[0,144] += torch.sum(outp)

            outp = self.classifier[5](outp) # dropout
            outp = self.classifier[6](outp) # fc6 classifier
            outp_sum += outp

        return outp_sum,l2_max_inp,l4_max_inp,l7_max_inp,l9_max_inp,l12_max_inp,l14_max_inp,l16_max_inp,l19_max_inp,l21_max_inp,l23_max_inp,l26_max_inp,l28_max_inp,l30_max_inp,fc1_max_inp,fc4_max_inp,spike_count

# Rate version of simple network
class VGGRate(nn.Module):
    
    def __init__(self):
        super(VGGRate, self).__init__()
        # Instantiate layers
        self.features = make_features(is_spike=False, is_temp=False)
        # self.classifier = nn.Linear(25088, 1000, bias=False)
        self.classifier = make_classifier(is_spike=False)
        # Initialize weights in the MSR style (http://arxiv.org/pdf/1502.01852v1.pdf) which is more suitable for deep network than Xavier initialization (default initialization of convolutional layer in PyTorch)
        self.initialize_weights()

    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                m.weight.data.normal_(0, math.sqrt(2. / n))
                if m.bias is not None:
                    m.bias.data.zero_()
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                if m.bias is not None:
                    m.bias.data.zero_()
            elif isinstance(m, nn.Linear):
                n = m.weight.size(1)
                m.weight.data.normal_(0, 0.01)
                if m.bias is not None:
                    m.bias.data.zero_()

    def forward(self, inp):
        # outp = self.features(inp)
        # outp = outp.view(outp.size(0), -1)
        # outp = self.classifier(outp)

        # print('inp_batch_img', inp.shape, torch.max(inp), torch.min(inp))

        # compute outp
        # outp = model(inp)

        outp = self.features.module[0](inp)
        outp = self.features.module[1](outp)
        outp = self.features.module[2](outp)

        outp = self.features.module[3](outp)
        outp = self.features.module[4](outp)
        outp = self.features.module[5](outp)

        outp = self.features.module[6](outp)
        outp = self.features.module[7](outp)
        outp = self.features.module[8](outp)

        outp = self.features.module[9](outp)
        outp = self.features.module[10](outp)
        outp = self.features.module[11](outp)

        outp = self.features.module[12](outp)
        outp = self.features.module[13](outp)
        outp = self.features.module[14](outp)

        outp = self.features.module[15](outp)
        outp = self.features.module[16](outp)
        outp = self.features.module[17](outp)

        outp = self.features.module[18](outp)
        outp = self.features.module[19](outp)
        outp = self.features.module[20](outp)

        outp = self.features.module[21](outp)
        outp = self.features.module[22](outp)
        outp = self.features.module[23](outp)

        outp = self.features.module[24](outp)
        outp = self.features.module[25](outp)
        outp = self.features.module[26](outp) 

        outp = self.features.module[27](outp)
        outp = self.features.module[28](outp)
        outp = self.features.module[29](outp)

        outp = self.features.module[30](outp)
        outp = outp.view(outp.size(0), -1)
        outp = self.classifier(outp)
        
        return outp


    def initialize_weights(self):
        for m in self.modules():
            # Only reinitialize for spatial convolutional layer
            if isinstance(m, nn.Conv2d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                m.weight.data.normal_(0, math.sqrt(2. / n))
                if m.bias is not None:
                    m.bias.data.zero_()
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                if m.bias is not None:
                    m.bias.data.zero_()
            elif isinstance(m, nn.Linear):
                n = m.weight.size(1)
                m.weight.data.normal_(0, 0.01)
                if m.bias is not None:
                    m.bias.data.zero_() 


if __name__ == '__main__':

    # Test rate model with random input (batchsize of 4)
    inp = torch.rand(4,3,224,224) 
    print('-'*40)
    # Instantiate rate-baed VGG model and parallelize model across GPUs, but only for convolutional layers (check this out https://arxiv.org/pdf/1404.5997.pdf)
    model_rate = VGGRate()
    model_rate.features = torch.nn.DataParallel(model_rate.features)
    model_rate.cuda()
    # Print model
    print(model_rate)
    # Compute output
    # outp = model_rate(inp)
    # print('Test successful!')
    # input('...')
    sys.exit(0)
    
    # Test spiking model with random input (batchsize of 4)
    print('-'*40)
    # Instantiate spiking VGG model and parallel model across multiple GPUs
    model_spike = VGGSpike()
    model_spike = torch.nn.DataParallel(model_spike).cuda()
    # Print model
    print(model_spike)
    # Compute output
    model_spike.eval()
    # with torch.no_grad():
    #     outp = model_spike(inp)
    # print('Test successful!')

    # Automatically generate weight mapping list and forward statement
    print('-'*40)
    # After training rate-based model, weight of convolutional layers in the rate-based model is copied to that in the spiking model
    print(list(zip(list(model_rate.state_dict().keys()),list(model_spike.state_dict().keys()))))
    # Forward statement for spiking model
    print()
    print('    for j in range(int(self.t_end/self.dt)):')
    inp_dim = 3
    inp_size = 224
    outstr = 'inp'
    initstr1 = '    outp_sum = torch.zeros(inp.size(0),1000).cuda()\n'
    initstr2 = ''
    returnstr = '    return outp_sum'
    set1str = '    outp'
    set2str = []
    # Forward statement for convolutional layers
    for i,m in enumerate(model_spike.module.features):
        if isinstance(m,PoissonGen) or isinstance(m,nn.Dropout):
            outstr = 'self.features[{}]({})'.format(i,outstr)
        elif isinstance(m,nn.Conv2d):
            outstr = 'self.features[{}]({})'.format(i,outstr)
            inp_dim = int(m.out_channels)
            inp_size = int((inp_size-m.kernel_size[0]+2*m.padding[0])/m.stride[0]+1)
        elif isinstance(m,nn.AvgPool2d):
            outstr = 'self.features[{}]({})'.format(i,outstr)
            inp_size = int((inp_size-m.kernel_size[0])/m.stride[0]+1)
        elif isinstance(m,IFNeuron):
            print('        outp = {}'.format(outstr))
            outstr = 'outp'
            print('        l{}_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l{}_max_inp)'.format(i,i))
            print('        outp,l{}_mem_potential = self.features[{}](outp,l{}_mem_potential)'.format(i,i,i))
            initstr1 += '    l{}_mem_potential = torch.zeros(inp.size(0),{},{},{}).cuda()\n'.format(i,inp_dim,inp_size,inp_size)
            initstr1 += '    l{}_max_inp = torch.zeros(inp.size(0),1).cuda()\n'.format(i)
            initstr2 += '    l{}_max_inp_ = torch.zeros(1).cuda()\n'.format(i)
            returnstr += ',l{}_max_inp'.format(i) 
            set1str += ',l{}_max_inp'.format(i) 
            # set2str.append('model_spike.module.features[{}].set_thres(float(torch.max(l{}_max_inp)))\n'.format(i,i))
            set2str.append('    l{}_max_inp_ = torch.max(l{}_max_inp_,torch.max(l{}_max_inp))\nmodel_spike.module.features[{}].set_thres(float(l{}_max_inp_))\n'.format(i,i,i,i,i))
        else: 
            assert False, 'Unrecognized module {}'.format(m)
    print('        outp = {}'.format(outstr))
    outstr = 'outp'
    # Forward statement for reshaping
    print('        outp = outp.view(outp.size(0), -1)')
    inp_dim = (inp_dim * inp_size * inp_size)
    # Forward statement for fully connected-layer
    for i,m in enumerate(model_spike.module.classifier):
        if isinstance(m,nn.Dropout):
            outstr = 'self.classifier[{}]({})'.format(i,outstr)
        elif isinstance(m,nn.Linear):
            outstr = 'self.classifier[{}]({})'.format(i,outstr)
        elif isinstance(m,IFNeuron):
            print('        outp = {}'.format(outstr))
            outstr = 'outp'
            print('        c{}_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],c{}_max_inp)'.format(i,i))
            print('        outp,c{}_mem_potential = self.classifier[{}](outp,c{}_mem_potential)'.format(i,i,i))
            initstr1 += '    c{}_mem_potential = torch.zeros(inp.size(0),{}).cuda()\n'.format(i,inp_dim)
            initstr1 += '    c{}_max_inp = torch.zeros(inp.size(0),1).cuda()\n'.format(i)
            initstr2 += '    c{}_max_inp = torch.zeros(1).cuda()\n'.format(i)
            returnstr += ',c{}_max_inp'.format(i) 
            set1str += ',c{}_max_inp'.format(i) 
            # set2str.append('model_spike.module.classifier[{}].set_thres(float(torch.max(c{}_max_inp)))\n'.format(i,i))
            set2str.append('    c{}_max_inp_ = torch.max(c{}_max_inp_,torch.max(c{}_max_inp))\nmodel_spike.module.classifier[{}].set_thres(float(c{}_max_inp_))\n'.format(i,i,i,i,i))
        else: 
            assert False, 'Unrecognized module {}'.format(m)
    print('        outp = {}'.format(outstr))
    print('        outp_sum += outp')
    print()
    print(returnstr)
    # Print initialization statement
    print(initstr1)
    print()
    print(initstr2)
    set1str += ' = model_spike(inp)'
    for each in set2str:
        print(set1str)
        print(each)

    # # Generate code for baseline comparison
    # inp_dim = 3
    # inp_size = 224
    # outstr = 'inp'
    # initstr = ''
    # returnstr = '        return outp'
    # set1str = '    outp'
    # set2str = []
    # set3str = ['    prev_factor = 1']
    # # Forward statement for convolutional layers
    # for i,m in enumerate(model_rate.features.module):
    #     if isinstance(m,PoissonGen) or isinstance(m,nn.Dropout):
    #         outstr = 'self.features.module[{}]({})'.format(i,outstr)
    #     elif isinstance(m,nn.Conv2d):
    #         outstr = 'self.features.module[{}]({})'.format(i,outstr)
    #         inp_dim = int(m.out_channels)
    #         inp_size = int((inp_size-m.kernel_size[0]+2*m.padding[0])/m.stride[0]+1)
    #         set3str += ['    l{}_maxw = torch.max(model_seq.features.module[{}].weight)'.format(i,i)]
    #         set3str += ['    scale_factor = torch.max(l{}_hmax_outp, l{}_maxw)'.format(i+1,i)]
    #         set3str += ['    apply_factor = torch.div(scale_factor, prev_factor)']
    #         set3str += ['    model_seq.features.module[{}].weight.data = torch.div(model_seq.features.module[{}].weight, apply_factor)'.format(i,i)]
    #         set3str += ['    prev_factor = scale_factor']
    #     elif isinstance(m,nn.AvgPool2d):
    #         outstr = 'self.features.module[{}]({})'.format(i,outstr)
    #         inp_size = int((inp_size-m.kernel_size[0])/m.stride[0]+1)
    #     elif isinstance(m,nn.ReLU):
    #         outstr = 'self.features.module[{}]({})'.format(i,outstr)
    #         print('        outp = {}'.format(outstr))
    #         outstr = 'outp'
    #         print('        l{}_max_outp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l{}_max_outp)'.format(i,i))
    #         initstr += '        l{}_max_outp = torch.zeros(inp.size(0),1).cuda()\n'.format(i)
    #         returnstr += ',l{}_max_outp'.format(i) 
    #         set1str += ',l{}_max_outp'.format(i) 
    #     else: 
    #         assert False, 'Unrecognized module {}'.format(m)
    # print('        outp = {}'.format(outstr))
    # outstr = 'outp'
    # # Forward statement for reshaping
    # print('        outp = outp.view(outp.size(0), -1)')
    # inp_dim = (inp_dim * inp_size * inp_size)
    # # Forward statement for fully connected-layer
    # for i,m in enumerate(model_rate.classifier):
    #     if isinstance(m,nn.Dropout):
    #         outstr = 'self.classifier[{}]({})'.format(i,outstr)
    #     elif isinstance(m,nn.Linear):
    #         outstr = 'self.classifier[{}]({})'.format(i,outstr)
    #         set3str += ['    c{}_maxw = torch.max(model_seq.classifier[{}].weight)'.format(i,i)]
    #         set3str += ['    scale_factor = torch.max(c{}_hmax_outp, c{}_maxw)'.format(i+1,i)]
    #         set3str += ['    apply_factor = torch.div(scale_factor, prev_factor)']
    #         set3str += ['    model_seq.classifier[{}].weight.data = torch.div(model_seq.classifier[{}].weight, apply_factor)'.format(i,i)]
    #         set3str += ['    prev_factor = scale_factor']
    #     elif isinstance(m,nn.ReLU):
    #         outstr = 'self.classifier[{}]({})'.format(i,outstr)
    #         print('        outp = {}'.format(outstr))
    #         outstr = 'outp'
    #         print('        c{}_max_outp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],c{}_max_outp)'.format(i,i))
    #         initstr += '        c{}_max_outp = torch.zeros(inp.size(0),1).cuda()\n'.format(i)
    #         returnstr += ',c{}_max_outp'.format(i) 
    #         set1str += ',c{}_max_outp'.format(i) 
    #     else: 
    #         assert False, 'Unrecognized module {}'.format(m)
    # print('        outp = {}'.format(outstr))
    # print(returnstr)
    # # Print initialization statement
    # print(initstr)
    # set1str += ' = model_seq(inp)'
    # for each in set2str:
    #     print(set1str)
    # for each in set3str:
    #     print(each)
    # print(list(model_rate.state_dict().keys()))
    # import sys
    # sys.exit(0)

