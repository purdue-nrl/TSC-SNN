
import torch
import torch.nn as nn
import math

# Poisson spike generator
#   This module generates spike based on assumption that input is between 1 and -1
#   Positive spike is generated (i.e. 1 is return) if rand()<abs(input) and sign(input)=1
#   Negative spike is generated (i.e. -1 is return) if rand()<abs(input) and sign(input)=-1
#   This method is corresponding to Method 1 on Page 5 of lecture note http://www.cns.nyu.edu/~david/handouts/poisson.pdf
class PoissonGen(nn.Module):
    def __init__(self):
        super(PoissonGen, self).__init__()
    def forward(self, inp, t, N, en_IN):
        # nbits = 32
        # inp_disc= torch.round(inp*(2^nbits-1))/(2^nbits-1)
        if en_IN:
            op=1.0
        else:
            op=0.0
        # return op*torch.mul(torch.le(torch.rand_like(inp), torch.abs(inp_disc)).float(), torch.sign(inp))
        return op*torch.mul(torch.le(torch.rand_like(inp), torch.abs(inp)).float(), torch.sign(inp))

# Temporal spikes generator
class TemporalGen(nn.Module):
    def __init__(self):
        super(TemporalGen, self).__init__()
    def forward(self, inp, t, N, en_IN):

        if en_IN:
            op=1.0
        else:
            op=0.0
         
        outp = op * torch.mul(torch.le(inp*0+t,(N+0.5)*torch.abs(inp)).float(), torch.sign(inp))
        return outp


# Integrate-and-fire neuron (IFNeuron)
#   This module is slightly from IFNeuron module in the script that I have sent to Gopal and Priya earlier.
#   This module models simple IFNeuron without any refractory period
#   This modeule does not have state information, thus allowing it to be parallelized across GPUs when torch.nn.DataParallel is wrapped around
#   As a result, this module takes two arguments: input and previous IFNeuron membrane potential
#   Spike is generated if IFNeuron membrane potential reachs defined threshold
#   Spike output is return with new IFNeuron membrane potential
class IFNeuron(nn.Module):
    # Argument inplace does not have any use. You can ignore it. 
    def __init__(self, inplace=True, thres=1.0):
        super(IFNeuron, self).__init__()
        self.thres = thres
    def forward(self, inp, mem_potential, IF_spiking, IF_residual):
        mem_potential += inp
        outp = mem_potential*0.0
        if IF_spiking:
            outp = torch.ge(mem_potential, self.thres)
            if IF_residual:
                mem_potential[outp] = (mem_potential[outp] - self.thres)*1.0  # Residual-IF neuron
            else:
                mem_potential[outp] = (mem_potential[outp] - self.thres)*0.0  # IF neuron
        return outp.float(), mem_potential
    def set_thres(self, thres):
        self.thres = thres
    def get_thres(self):
        return self.thres
    def extra_repr(self):
        return 'thres={}'.format(self.thres)

# Identity module
#   This module returns whatever it recieves
class Identity(nn.Module):
    def __init__(self):
        super(Identity, self).__init__()
    def forward(self, inp):
        return inp

# Following are dummy modules
#   Those modules do not have any function
class DelayMark(nn.Module):
    def __init__(self):
        super(DelayMark, self).__init__()
class ResidueMark(nn.Module):
    def __init__(self):
        super(ResidueMark, self).__init__()
class MergeMark0(nn.Module):
    def __init__(self):
        super(MergeMark0, self).__init__()
class MergeMark1(nn.Module):
    def __init__(self):
        super(MergeMark1, self).__init__()

# Basic block in ResNet-34
class BasicBlock1(nn.Module):
    def __init__(self, in_channels, out_channels, stride, dropout_prob):
        super(BasicBlock1, self).__init__()
        # Construct delay path
        self.delay_path = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=(3,3), stride=(stride,stride), padding=(1,1), bias=False),
            nn.ReLU(),
            nn.Dropout(p=dropout_prob),
            nn.Conv2d(out_channels, out_channels, kernel_size=(3,3), stride=(1,1), padding=(1,1), bias=False)
        )
        # Construt residue path
        self.residual_path = Identity()
        self.relu = nn.ReLU(inplace=True)
    def forward(self, inp):
        # Output of basic block is sum of value from residue path and delay path
        outp = self.delay_path(inp)
        outp += self.residual_path(inp)
        outp = self.relu(outp)
        return outp

class BasicBlock0(nn.Module):
    def __init__(self, in_channels, out_channels, stride, dropout_prob):
        super(BasicBlock0, self).__init__()
        # Construct delay path
        self.delay_path = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=(3,3), stride=(stride,stride), padding=(1,1), bias=False),
            nn.ReLU(),
            nn.Dropout(p=dropout_prob),
            nn.Conv2d(out_channels, out_channels, kernel_size=(3,3), stride=(1,1), padding=(1,1), bias=False)
        )
        # Construt residue path
        self.residual_path = nn.AvgPool2d(kernel_size=(1,1), stride=(stride,stride), padding=(0,0))
        self.relu = nn.ReLU(inplace=True)
        self.pad_channels = out_channels - in_channels
    def forward(self, inp):
        # Output of basic block is sum of value from residue path and delay path
        outp = self.delay_path(inp)
        outp_res = self.delay_path(inp)
        outp += torch.cat((self.residual_path(inp),torch.zeros(inp.size(0), self.pad_channels, outp.size(2), outp.size(3)).cuda()), 1)
        outp = self.relu(outp)
        return outp

# Make basic block in specially for spiking ResNet
#   forward path of ResNet will be automatically generated with script in __main__ 
def make_basic_block(is_spike, in_channels, out_channels, stride, dropout_prob):
    if is_spike:
        delay_path = [nn.Conv2d(in_channels, out_channels, kernel_size=(3,3), stride=(stride,stride), padding=(1,1), bias=False),
                IFNeuron(inplace=True),
                nn.Dropout(p=dropout_prob),
                nn.Conv2d(out_channels, out_channels, kernel_size=(3,3), stride=(1,1), padding=(1,1), bias=False)]
        if in_channels == out_channels:
            residual_path = [Identity()]
            return [ResidueMark()] + delay_path + [DelayMark()] + residual_path + [MergeMark1()] + [IFNeuron(inplace=True)]
        else:
            residual_path = [nn.AvgPool2d(kernel_size=(1,1), stride=(stride,stride), padding=(0,0))]
            return [ResidueMark()] + delay_path + [DelayMark()] + residual_path + [MergeMark0()] + [IFNeuron(inplace=True)]
    else:
        if in_channels == out_channels:
            return [BasicBlock1(in_channels, out_channels, stride, dropout_prob)]
        else:
            return [BasicBlock0(in_channels, out_channels, stride, dropout_prob)]

# Function to create convolutional layer
#   When is_spike=False, this function creates convolutional layer for rate-based ResNet
#   When is_spike=True, this function creates convolutional layer for spiking ResNet
def make_features(is_spike, is_temp, dropout_prob_list):
    list_m = []
    in_channels = 3
    if is_spike:
        if is_temp:
            list_m.append(TemporalGen())
        else:
            list_m.append(PoissonGen())
        act_func = IFNeuron
    else:
        act_func = nn.ReLU

    list_m += [nn.Conv2d(in_channels, 64, kernel_size=(3,3), stride=(2,2), padding=(1,1), bias=False)]
    list_m += [act_func(inplace=True)]
    list_m += [nn.Dropout(p=dropout_prob_list[0])]
    list_m += [nn.Conv2d(64, 64, kernel_size=(3,3), stride=(1,1), padding=(1,1), bias=False)]
    list_m += [act_func(inplace=True)]
    list_m += [nn.Dropout(p=dropout_prob_list[1])]
    list_m += [nn.Conv2d(64, 64, kernel_size=(3,3), stride=(1,1), padding=(1,1), bias=False)]
    list_m += [act_func(inplace=True)]
    list_m += [nn.Dropout(p=dropout_prob_list[2])]
    list_m += [nn.AvgPool2d(kernel_size=(3,3), stride=(2,2), padding=(1,1))]
    in_channels = 64

    for out_channels,strides,nblock in zip([64, 128, 256, 512],[1, 2, 2, 2], [3, 4, 6, 3]):
        strides = [strides] + [1]*(nblock-1)
        for j,stride in zip(range(nblock),strides):
            list_m.extend(make_basic_block(is_spike, in_channels, out_channels, stride, dropout_prob_list[3]))
            in_channels = out_channels
    list_m += [nn.AvgPool2d(kernel_size=(7,7), stride=(1,1))]
    return make_hierarchy(list_m,is_spike)

# Make fully connected layer 
#   When is_spike=False, this function creates fully-connected layer for rate-based ResNet network
#   When is_spike=True, this function creates fully-connected layer for spiking ResNet network 
def make_classifier(is_spike):
    list_m = []
    list_m += [nn.Linear(512, 1000, bias=False)]
    return make_hierarchy(list_m,is_spike)

# Convert list of modules into torch.nn.ModuleList or torch.nn.Sequentual
#   For spiking simulation, we prefer modules to be stacked in torch.nn.ModuleList because output of modules are accessed at multiple points
#   During threshold balancing, we, for example, need to get maximum input to a particular IFNeuron. Having module in torch.nn.Sequential does allow us to access intermediate values easily 
def make_hierarchy(list_m,is_spike):
    if is_spike:
        return nn.ModuleList(list_m)
    else:
        return nn.Sequential(*list_m)

# Spiking version of simple network
class ResNetSpike(nn.Module):
    def __init__(self, dt=0.001, t_end=2.000, in_coding='rate', snn_mode='full', if_mode='if', TTS=256, fpi=128, dropout_prob_list=[0.1,0.1,0.1,0.1]):
        super(ResNetSpike, self).__init__()
        # Save network parameters
        self.dt = dt
        self.t_end = t_end
        self.TTS = TTS
        self.fpi = fpi+1
        self.in_coding = in_coding
        self.snn_mode = snn_mode
        self.if_mode = if_mode

        self.is_residual = []
        if self.if_mode == 'residual':
            self.is_residual = True
        elif self.if_mode == 'if':
            self.is_residual = False

        if self.in_coding == 'temp':
            is_temp = True
        elif self.in_coding == 'rate':
            is_temp = False

        # Instantiate layers
        self.features = make_features(is_spike=True, is_temp=is_temp, dropout_prob_list=dropout_prob_list)
        self.classifier = make_classifier(is_spike=True)
    def forward(self, inp):
        # Code in this forward function is automatically generated by running this script
        #   $ python model_resnet34_imagenet.py
        # XX_mem_potential stores membrane potential of IFNeuron at layer XX
        # XX_max_inp stores maximum input to IFNeuon at layer XX
        outp_sum = torch.zeros(inp.size(0),1000).cuda()

        l2_mem_potential = torch.zeros(inp.size(0),64,112,112).cuda()
        l2_max_inp = torch.zeros(inp.size(0),1).cuda()
        l2_pre_inp = torch.zeros(inp.size(0),64,112,112).cuda()
        l3_pre_inp = torch.zeros(inp.size(0),64,112,112).cuda()

        l5_mem_potential = torch.zeros(inp.size(0),64,112,112).cuda()
        l5_max_inp = torch.zeros(inp.size(0),1).cuda()
        l5_pre_inp = torch.zeros(inp.size(0),64,112,112).cuda()
        l6_pre_inp = torch.zeros(inp.size(0),64,112,112).cuda()

        l8_mem_potential = torch.zeros(inp.size(0),64,112,112).cuda()
        l8_max_inp = torch.zeros(inp.size(0),1).cuda()
        l8_pre_inp = torch.zeros(inp.size(0),64,112,112).cuda()
        l9_pre_inp = torch.zeros(inp.size(0),64,112,112).cuda()

        l13_mem_potential = torch.zeros(inp.size(0),64,56,56).cuda()
        l13_pre_inp = torch.zeros(inp.size(0),64,56,56).cuda()

        l19_mem_potential = torch.zeros(inp.size(0),64,56,56).cuda()
        l19_pre_inp = torch.zeros(inp.size(0),64,112,112).cuda()
        l21_pre_inp = torch.zeros(inp.size(0),64,112,112).cuda()

        l22_mem_potential = torch.zeros(inp.size(0),64,56,56).cuda()
        l22_pre_inp = torch.zeros(inp.size(0),64,56,56).cuda()
        l23_pre_inp = torch.zeros(inp.size(0),64,56,56).cuda()

        l28_mem_potential = torch.zeros(inp.size(0),64,56,56).cuda()
        l28_pre_inp = torch.zeros(inp.size(0),64,56,56).cuda()

        l31_mem_potential = torch.zeros(inp.size(0),64,56,56).cuda()
        l37_mem_potential = torch.zeros(inp.size(0),64,56,56).cuda()
        l39_pre_inp = torch.zeros(inp.size(0),64,56,56).cuda()

        l40_mem_potential = torch.zeros(inp.size(0),128,28,28).cuda()
        l40_pre_inp = torch.zeros(inp.size(0),128,28,28).cuda()
        l41_pre_inp = torch.zeros(inp.size(0),128,28,28).cuda()

        l46_mem_potential = torch.zeros(inp.size(0),128,28,28).cuda()
        l46_pre_inp = torch.zeros(inp.size(0),128,28,28).cuda()
        l48_pre_inp = torch.zeros(inp.size(0),128,28,28).cuda()

        l49_mem_potential = torch.zeros(inp.size(0),128,28,28).cuda()
        l49_pre_inp = torch.zeros(inp.size(0),128,28,28).cuda()
        l50_pre_inp = torch.zeros(inp.size(0),128,28,28).cuda()

        l55_mem_potential = torch.zeros(inp.size(0),128,28,28).cuda()
        l55_pre_inp = torch.zeros(inp.size(0),128,28,28).cuda()
        l57_pre_inp = torch.zeros(inp.size(0),128,28,28).cuda()

        l58_mem_potential = torch.zeros(inp.size(0),128,28,28).cuda()
        l58_pre_inp = torch.zeros(inp.size(0),128,28,28).cuda()
        l59_pre_inp = torch.zeros(inp.size(0),128,28,28).cuda()

        l64_mem_potential = torch.zeros(inp.size(0),128,28,28).cuda()
        l64_pre_inp = torch.zeros(inp.size(0),128,28,28).cuda()
        l66_pre_inp = torch.zeros(inp.size(0),128,28,28).cuda()

        l67_mem_potential = torch.zeros(inp.size(0),128,28,28).cuda()
        l67_pre_inp = torch.zeros(inp.size(0),128,28,28).cuda()
        l68_pre_inp = torch.zeros(inp.size(0),128,28,28).cuda()

        l73_mem_potential = torch.zeros(inp.size(0),128,28,28).cuda()
        l73_pre_inp = torch.zeros(inp.size(0),128,28,28).cuda()
        l75_pre_inp = torch.zeros(inp.size(0),128,28,28).cuda()

        l76_mem_potential = torch.zeros(inp.size(0),256,14,14).cuda()
        l76_pre_inp = torch.zeros(inp.size(0),256,14,14).cuda()
        l77_pre_inp = torch.zeros(inp.size(0),256,14,14).cuda()

        l82_mem_potential = torch.zeros(inp.size(0),256,14,14).cuda()
        l82_pre_inp = torch.zeros(inp.size(0),256,14,14).cuda()
        l84_pre_inp = torch.zeros(inp.size(0),256,14,14).cuda()

        l85_mem_potential = torch.zeros(inp.size(0),256,14,14).cuda()
        l85_pre_inp = torch.zeros(inp.size(0),256,14,14).cuda()
        l86_pre_inp = torch.zeros(inp.size(0),256,14,14).cuda()

        l91_mem_potential = torch.zeros(inp.size(0),256,14,14).cuda()
        l91_pre_inp = torch.zeros(inp.size(0),256,14,14).cuda()
        l93_pre_inp = torch.zeros(inp.size(0),256,14,14).cuda()

        l94_mem_potential = torch.zeros(inp.size(0),256,14,14).cuda()
        l94_pre_inp = torch.zeros(inp.size(0),256,14,14).cuda()
        l95_pre_inp = torch.zeros(inp.size(0),256,14,14).cuda()

        l100_mem_potential = torch.zeros(inp.size(0),256,14,14).cuda()
        l100_pre_inp = torch.zeros(inp.size(0),256,14,14).cuda()
        l102_pre_inp = torch.zeros(inp.size(0),256,14,14).cuda()

        l103_mem_potential = torch.zeros(inp.size(0),256,14,14).cuda()
        l103_pre_inp = torch.zeros(inp.size(0),256,14,14).cuda()
        l104_pre_inp = torch.zeros(inp.size(0),256,14,14).cuda()

        l109_mem_potential = torch.zeros(inp.size(0),256,14,14).cuda()
        l109_pre_inp = torch.zeros(inp.size(0),256,14,14).cuda()
        l111_pre_inp = torch.zeros(inp.size(0),256,14,14).cuda()

        l112_mem_potential = torch.zeros(inp.size(0),256,14,14).cuda()
        l112_pre_inp = torch.zeros(inp.size(0),256,14,14).cuda()
        l113_pre_inp = torch.zeros(inp.size(0),256,14,14).cuda()

        l118_mem_potential = torch.zeros(inp.size(0),256,14,14).cuda()
        l118_pre_inp = torch.zeros(inp.size(0),256,14,14).cuda()
        l120_pre_inp = torch.zeros(inp.size(0),256,14,14).cuda()

        l121_mem_potential = torch.zeros(inp.size(0),256,14,14).cuda()
        l121_pre_inp = torch.zeros(inp.size(0),256,14,14).cuda()
        l122_pre_inp = torch.zeros(inp.size(0),256,14,14).cuda()

        l127_mem_potential = torch.zeros(inp.size(0),256,14,14).cuda()
        l127_pre_inp = torch.zeros(inp.size(0),256,14,14).cuda()
        l129_pre_inp = torch.zeros(inp.size(0),256,14,14).cuda()

        l130_mem_potential = torch.zeros(inp.size(0),512,7,7).cuda()
        l130_pre_inp = torch.zeros(inp.size(0),512,7,7).cuda()
        l131_pre_inp = torch.zeros(inp.size(0),512,7,7).cuda()

        l136_mem_potential = torch.zeros(inp.size(0),512,7,7).cuda()
        l136_pre_inp = torch.zeros(inp.size(0),512,7,7).cuda()
        l138_pre_inp = torch.zeros(inp.size(0),512,7,7).cuda()

        l139_mem_potential = torch.zeros(inp.size(0),512,7,7).cuda()
        l139_pre_inp = torch.zeros(inp.size(0),512,7,7).cuda()
        l140_pre_inp = torch.zeros(inp.size(0),512,7,7).cuda()

        l145_mem_potential = torch.zeros(inp.size(0),512,7,7).cuda()
        l145_pre_inp = torch.zeros(inp.size(0),512,7,7).cuda()
        l147_pre_inp = torch.zeros(inp.size(0),512,7,7).cuda()

        l148_mem_potential = torch.zeros(inp.size(0),512,7,7).cuda()
        l148_pre_inp = torch.zeros(inp.size(0),512,7,7).cuda()
        l149_pre_inp = torch.zeros(inp.size(0),512,7,7).cuda()

        l154_mem_potential = torch.zeros(inp.size(0),512,7,7).cuda()
        l154_pre_inp = torch.zeros(inp.size(0),512,7,7).cuda()
        l155_pre_inp = torch.zeros(inp.size(0),512,7,7).cuda()

        classifier_pre_inp = torch.zeros(inp.size(0),512,1,1).cuda()

        spike_count = torch.zeros(1,160).cuda()
        spike_count_ = torch.zeros(1,160).cuda()
        # Simulating spiking network over time inside the module, thus allow simulation to be parallelized across GPUs when torch.nn.DataParallel is wrapped around

        count = torch.zeros(1).cuda()

        self.en_IN = True
        self.en_IF = True

        l2_on = True
        l5_on = True
        l8_on = True

        l19_on = True
        l28_on = True
        l37_on = True

        l46_on = True
        l55_on = True
        l64_on = True
        l73_on = True

        l82_on = True
        l91_on = True
        l100_on = True
        l109_on = True
        l118_on = True
        l127_on = True

        l136_on = True
        l145_on = True
        l154_on = True

        
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            # generate delta-frame inputs to synapse of layer 1
            if count == 1:
                outp = self.features[0](inp, count, self.fpi, self.en_IN) # spike-input
            else:
                outp = self.features[0](inp, count, self.fpi, self.en_IN) - self.features[0](inp, count-1, self.fpi, self.en_IN)
            spike_count_[0,1] += torch.sum(torch.abs(outp))
            spike_count[0,1] += torch.sum(torch.abs(self.features[0](inp, count, self.fpi, self.en_IN)))
            # print(count, spike_count[0,1], spike_count_[0,1])
            outp = self.features[1](outp) # synapse
            # reconstruct spiking neuron full-frame inputs to layer 2
            if count == 1:
                l2_pre_inp = outp
            else:
                outp += l2_pre_inp
                l2_pre_inp = outp
            l2_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l2_max_inp)
            outp,l2_mem_potential = self.features[2](outp,l2_mem_potential, self.en_IF, self.is_residual)
            # print('       layer 2, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l2_mem_potential), torch.min(l2_mem_potential), l2_mem_potential.shape))
            spike_count[0,2] += torch.sum(outp)

            # outp = self.features[1](self.features[0](inp, count, self.fpi,self.en_IN))
            # l2_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l2_max_inp)
            # outp,l2_mem_potential = self.features[2](outp,l2_mem_potential, self.en_IF, self.is_residual)
            # spike_count[0,2] += torch.sum(outp)
            # outp = self.features[4](self.features[3](outp))


        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp = 0*l2_mem_potential
            outp,l2_mem_potential = self.features[2](outp,l2_mem_potential, True, self.is_residual)
            # print('        layer 2, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l2_mem_potential), torch.min(l2_mem_potential), l2_mem_potential.shape))
            spike_count[0,2] += torch.sum(torch.abs(outp))
            # generate delta-frame inputs to synapse of layer 3 
            if count == 1:
                l3_pre_inp = outp
            else:
                outp = outp - l3_pre_inp
                l3_pre_inp = l3_pre_inp + outp
            spike_count_[0,2] += torch.sum(torch.abs(outp))
            print(count, spike_count[0,2], spike_count_[0,2])
            outp = self.features[3](outp) # dropout
            outp = self.features[4](outp) # synapse
            # reconstruct spiking neuron full-frame inputs to layer 5
            if count == 1:
                l5_pre_inp = outp
            else:
                outp += l5_pre_inp
                l5_pre_inp = outp
            l5_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l5_max_inp)
            outp,l5_mem_potential = self.features[5](outp,l5_mem_potential, False, self.is_residual)
            # print('        layer 5, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l5_mem_potential), torch.min(l5_mem_potential), l5_mem_potential.shape))
            spike_count[0,5] += torch.sum(outp)

            # l5_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l5_max_inp)
            # outp,l5_mem_potential = self.features[5](outp,l5_mem_potential, self.en_IF, self.is_residual)
            # spike_count[0,5] += torch.sum(outp)
            # outp = self.features[7](self.features[6](outp))


        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp = 0*l5_mem_potential
            outp,l5_mem_potential = self.features[5](outp,l5_mem_potential, True, self.is_residual)
            # print('        layer 5, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l5_mem_potential), torch.min(l5_mem_potential), l5_mem_potential.shape))
            spike_count[0,5] += torch.sum(torch.abs(outp))
            # generate delta-frame inputs to synapse of layer 7      
            if count == 1:
                l6_pre_inp = outp
            else:
                outp = outp - l6_pre_inp
                l6_pre_inp = l6_pre_inp + outp
            spike_count[1,5] += torch.sum(torch.abs(outp))
            # print(count, spike_count[1,5], spike_count[0,5])
            outp = self.features[6](outp) # pooling
            outp = self.features[7](outp) # synapse
            # reconstruct spiking neuron full-frame inputs to layer 8
            if count == 1:
                l8_pre_inp = outp
            else:
                outp += l8_pre_inp
                l8_pre_inp = outp
            l8_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l8_max_inp)
            outp,l8_mem_potential = self.features[8](outp,l8_mem_potential, False, self.is_residual)
            # print('        layer 8, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l8_mem_potential), torch.min(l8_mem_potential), l8_mem_potential.shape))
            spike_count[0,8] += torch.sum(outp)

            # l8_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l8_max_inp)
            # outp,l8_mem_potential = self.features[8](outp,l8_mem_potential, self.en_IF, self.is_residual)
            # spike_count[0,8] += torch.sum(outp)
            # outp = self.features[9](outp)
            # outp = self.features[10](outp)

        #++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++#
        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp = 0*l8_mem_potential
            outp,l8_mem_potential = self.features[8](outp,l8_mem_potential, True, self.is_residual)        
            # print('        layer 8, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l8_mem_potential), torch.min(l8_mem_potential), l8_mem_potential.shape))
            spike_count[0,8] += torch.sum(outp)
            # generate delta-frame inputs to synapse of layer 9
            if count == 1:
                l9_pre_inp = outp
            else:
                outp = outp - l9_pre_inp
                l9_pre_inp = l9_pre_inp + outp
            spike_count[1,8] += torch.sum(torch.abs(outp))
            # print(count, spike_count[1,8], spike_count[0,8])
            outp = self.features[9](outp)      # dropout
            outp = self.features[10](outp)     # pooling
            outp_r = self.features[12](outp)    # <------- synapses
            # reconstruct spiking neuron full-frame inputs to layer 12
            if count == 1:
                l13_pre_inp = outp_r
            else:
                outp_r += l13_pre_inp
                l13_pre_inp = outp_r
            outp_r,l13_mem_potential = self.features[13](outp_r,l13_mem_potential, self.en_IF, self.is_residual)
            spike_count[0,13] += torch.sum(outp_r)
            outp_d = self.features[17](outp)    # <------- identity
             # reconstruct spiking neuron full-frame inputs to layer 19
            if count == 1:
                l19_pre_inp = outp_d
            else:
                outp_d += l19_pre_inp
                l19_pre_inp = outp_d
            outp_d,l19_mem_potential = self.features[19](outp_d,l19_mem_potential, False, self.is_residual)

        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp_r = 0*l13_mem_potential
            outp_r,l13_mem_potential = self.features[13](outp_r,l13_mem_potential, True, self.is_residual)
            # print('        layer 13, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l13_mem_potential), torch.min(l13_mem_potential), l13_mem_potential.shape))
            spike_count[0,13] += torch.sum(outp_r)
             # generate delta-frame inputs to synapse of layer 14
            if count == 1:
                l14_pre_inp = outp_r
            else:
                outp_r = outp_r - l14_pre_inp
                l14_pre_inp = l14_pre_inp + outp_r
            spike_count[1,13] += torch.sum(torch.abs(outp_r))
            outp_r = self.features[14](outp_r) # dropout
            outp_r = self.features[15](outp_r) # synapse  <-------
             # reconstruct spiking neuron full-frame inputs to layer 19
            if count == 1:
                l19_pre_inp = outp_r
            else:
                outp_r += l19_pre_inp
                l19_pre_inp = outp_r
            outp_r,l19_mem_potential = self.features[19](outp_r,l19_mem_potential, False, self.is_residual)
            spike_count[0,19] += torch.sum(outp_r)


            # outp_r = self.features[14](outp_r)  # <------- dropout
            # outp_r = self.features[15](outp_r)  # <------- synapses
            # outp_d = self.features[17](outp)    # <------- identity
            # outp = torch.add(outp_d, outp_r)    # ------->
            # outp,l19_mem_potential = self.features[19](outp,l19_mem_potential, self.en_IF, self.is_residual)
            # spike_count[0,19] += torch.sum(outp)

        #++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++#
        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp_r = 0*l19_mem_potential
            outp,l21_mem_potential = self.features[19](outp_r,l19_mem_potential, True, self.is_residual)
            spike_count[0,19] += torch.sum(outp)
            # print('        layer 19, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l19_mem_potential), torch.min(l19_mem_potential), l19_mem_potential.shape))
            # generate delta-frame inputs to synapse of layer 21
            if count == 1:
                l21_pre_inp = outp
            else:
                outp = outp - l21_pre_inp
                l21_pre_inp = l21_pre_inp + outp
            spike_count[1,19] += torch.sum(torch.abs(outp))
            outp_r = self.features[21](outp)   # synapse  <-------
            # reconstruct spiking neuron full-frame inputs to layer 22
            if count == 1:
                l22_pre_inp = outp_r
            else:
                outp_r += l22_pre_inp
                l22_pre_inp = outp_r
            outp_r,l22_mem_potential = self.features[22](outp_r,l22_mem_potential, False, self.is_residual)
            # print('        layer 22, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l22_mem_potential), torch.min(l22_mem_potential), l22_mem_potential.shape))
            spike_count[0,22] += torch.sum(outp_r)
            outp_d = self.features[26](outp)   # identity <-------
            # reconstruct spiking neuron full-frame inputs to layer 28
            if count == 1:
                l28_pre_inp = outp_d
            else:
                outp_d += l28_pre_inp
                l28_pre_inp = outp_d
            outp_d,l28_mem_potential = self.features[28](outp_d,l28_mem_potential, False, self.is_residual)
            # print('        layer 28, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l28_mem_potential), torch.min(l28_mem_potential), l28_mem_potential.shape))

        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp_r = 0*l22_mem_potential
            outp_r,l22_mem_potential = self.features[22](outp_r,l22_mem_potential, True, self.is_residual)
            # print('        layer 22, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l22_mem_potential), torch.min(l22_mem_potential), l22_mem_potential.shape))
            spike_count[0,22] += torch.sum(outp_r)
             # generate delta-frame inputs to synapse of layer 23
            if count == 1:
                l23_pre_inp = outp_r
            else:
                outp_r = outp_r - l23_pre_inp
                l23_pre_inp = l23_pre_inp + outp_r
            spike_count[1,23] += torch.sum(torch.abs(outp_r))
            outp_r = self.features[23](outp_r) # dropout
            outp_r = self.features[24](outp_r) # synapse  <-------
             # reconstruct spiking neuron full-frame inputs to layer 28
            if count == 1:
                l28_pre_inp = outp_r
            else:
                outp_r += l28_pre_inp
                l28_pre_inp = outp_r
            outp_r,l28_mem_potential = self.features[28](outp_r,l28_mem_potential, False, self.is_residual)
            # print('        layer 28, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l28_mem_potential), torch.min(l28_mem_potential), l28_mem_potential.shape))
            spike_count[0,28] += torch.sum(outp_r)


            # outp_r = self.features[21](outp)    # <------- synapses
            # outp_r,l22_mem_potential = self.features[22](outp_r,l22_mem_potential, self.en_IF, self.is_residual)
            # spike_count[0,22] += torch.sum(outp_r)
            # outp_r = self.features[23](outp_r)  # <------- dropout
            # outp_r = self.features[24](outp_r)  # <------- synapses
            # outp_d = self.features[26](outp)    # <------- identity
            # outp = torch.add(outp_d, outp_r)    # ------->
            # outp,l28_mem_potential = self.features[28](outp,l28_mem_potential, self.en_IF, self.is_residual)
            # spike_count[0,28] += torch.sum(outp)

        #++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++#
        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp_r = 0*l28_mem_potential
            outp,l28_mem_potential = self.features[28](outp_r,l28_mem_potential, True, self.is_residual)
            spike_count[0,28] += torch.sum(outp)
            # print('        layer 28, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l28_mem_potential), torch.min(l28_mem_potential), l28_mem_potential.shape))
            # generate delta-frame inputs to synapse of layer 30
            if count == 1:
                l30_pre_inp = outp
            else:
                outp = outp - l30_pre_inp
                l30_pre_inp = l30_pre_inp + outp
            spike_count[1,28] += torch.sum(torch.abs(outp))
            outp_r = self.features[30](outp)   # synapse  <-------
            # reconstruct spiking neuron full-frame inputs to layer 31
            if count == 1:
                l31_pre_inp = outp_r
            else:
                outp_r += l31_pre_inp
                l31_pre_inp = outp_r
            outp_r,l31_mem_potential = self.features[31](outp_r,l31_mem_potential, False, self.is_residual)
            # print('        layer 31, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l31_mem_potential), torch.min(l31_mem_potential), l31_mem_potential.shape))
            spike_count[0,31] += torch.sum(outp_r)
            outp_d = self.features[35](outp)   # identity <-------
            # reconstruct spiking neuron full-frame inputs to layer 37
            if count == 1:
                l37_pre_inp = outp_d
            else:
                outp_d += l37_pre_inp
                l37_pre_inp = outp_d
            outp_d,l37_mem_potential = self.features[37](outp_d,l37_mem_potential, False, self.is_residual)
            # print('        layer 37, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l37_mem_potential), torch.min(l37_mem_potential), l37_mem_potential.shape))

        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp_r = 0*l31_mem_potential
            outp_r,l31_mem_potential = self.features[31](outp_r,l31_mem_potential, True, self.is_residual)
            # print('        layer 31, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l31_mem_potential), torch.min(l31_mem_potential), l31_mem_potential.shape))
            spike_count[0,31] += torch.sum(outp_r)
             # generate delta-frame inputs to synapse of layer 32
            if count == 1:
                l32_pre_inp = outp_r
            else:
                outp_r = outp_r - l32_pre_inp
                l32_pre_inp = l32_pre_inp + outp_r
            spike_count[1,31] += torch.sum(torch.abs(outp_r))
            outp_r = self.features[32](outp_r) # dropout
            outp_r = self.features[33](outp_r) # synapse  <-------
             # reconstruct spiking neuron full-frame inputs to layer 37
            if count == 1:
                l37_pre_inp = outp_r
            else:
                outp_r += l37_pre_inp
                l37_pre_inp = outp_r
            outp_r,l37_mem_potential = self.features[37](outp_r,l37_mem_potential, False, self.is_residual)
            # print('        layer 37, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l37_mem_potential), torch.min(l37_mem_potential), l37_mem_potential.shape))
            spike_count[0,37] += torch.sum(outp_r)


            # outp_r = self.features[30](outp)    # <------- synapses
            # outp_r,l31_mem_potential = self.features[31](outp_r,l31_mem_potential, self.en_IF, self.is_residual)
            # spike_count[0,31] += torch.sum(outp_r)
            # outp_r = self.features[32](outp_r)  # <------- dropout
            # outp_r = self.features[33](outp_r)  # <------- synapses
            # outp_d = self.features[35](outp)    # <------- identity
            # outp = torch.add(outp_d, outp_r)    # ------->
            # outp,l37_mem_potential = self.features[37](outp,l37_mem_potential, self.en_IF, self.is_residual)
            # spike_count[0,37] += torch.sum(outp)

        #++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++#
        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp_r = 0*l37_mem_potential
            outp,l37_mem_potential = self.features[37](outp_r,l37_mem_potential, True, self.is_residual)
            spike_count[0,37] += torch.sum(outp)
            # print('        layer 37, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l37_mem_potential), torch.min(l37_mem_potential), l37_mem_potential.shape))
            # generate delta-frame inputs to synapse of layer 39
            if count == 1:
                l39_pre_inp = outp
            else:
                outp = outp - l39_pre_inp
                l39_pre_inp = l39_pre_inp + outp
            spike_count[1,37] += torch.sum(torch.abs(outp))
            outp_r = self.features[39](outp)   # synapse  <-------
            # reconstruct spiking neuron full-frame inputs to layer 40
            if count == 1:
                l40_pre_inp = outp_r
            else:
                outp_r += l40_pre_inp
                l40_pre_inp = outp_r
            outp_r,l40_mem_potential = self.features[40](outp_r,l40_mem_potential, False, self.is_residual)
            # print('        layer 40, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l40_mem_potential), torch.min(l40_mem_potential), l40_mem_potential.shape))
            spike_count[0,40] += torch.sum(outp_r)
            outp_d = torch.cat((self.features[44](outp),torch.zeros(outp_r.size(0),64,outp_r.size(2),outp_r.size(3)).cuda()),1)    # <------- identity
            # reconstruct spiking neuron full-frame inputs to layer 46
            if count == 1:
                l46_pre_inp = outp_d
            else:
                outp_d += l46_pre_inp
                l46_pre_inp = outp_d
            outp_d,l46_mem_potential = self.features[46](outp_d,l46_mem_potential, False, self.is_residual)
            # print('        layer 46, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l46_mem_potential), torch.min(l46_mem_potential), l46_mem_potential.shape))

        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp_r = 0*l40_mem_potential
            outp_r,l40_mem_potential = self.features[40](outp_r,l40_mem_potential, True, self.is_residual)
            # print('        layer 40, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l40_mem_potential), torch.min(l40_mem_potential), l40_mem_potential.shape))
            spike_count[0,40] += torch.sum(outp_r)
             # generate delta-frame inputs to synapse of layer 41
            if count == 1:
                l41_pre_inp = outp_r
            else:
                outp_r = outp_r - l41_pre_inp
                l41_pre_inp = l41_pre_inp + outp_r
            spike_count[1,40] += torch.sum(torch.abs(outp_r))
            outp_r = self.features[41](outp_r) # dropout
            outp_r = self.features[42](outp_r) # synapse  <-------
             # reconstruct spiking neuron full-frame inputs to layer 46
            if count == 1:
                l46_pre_inp = outp_r
            else:
                outp_r += l46_pre_inp
                l46_pre_inp = outp_r
            outp_r,l46_mem_potential = self.features[46](outp_r,l46_mem_potential, False, self.is_residual)
            # print('        layer 46, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l46_mem_potential), torch.min(l46_mem_potential), l46_mem_potential.shape))
            spike_count[0,46] += torch.sum(outp_r)
    

            # outp_r = self.features[39](outp)    # <------- synapses
            # outp_r,l40_mem_potential = self.features[40](outp_r,l40_mem_potential, self.en_IF, self.is_residual)
            # spike_count[0,40] += torch.sum(outp_r)
            # outp_r = self.features[41](outp_r)  # <------- dropout
            # outp_r = self.features[42](outp_r)  # <------- synapses
            # outp_d = torch.cat((self.features[44](outp),torch.zeros(outp_r.size(0),64,outp_r.size(2),outp_r.size(3)).cuda()),1)    # <------- identity
            # outp = torch.add(outp_d, outp_r)    # ------->
            # outp,l46_mem_potential = self.features[46](outp,l46_mem_potential, self.en_IF, self.is_residual)
            # spike_count[0,46] += torch.sum(outp)

        #++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++#
        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp_r = 0*l46_mem_potential
            outp,l46_mem_potential = self.features[46](outp_r,l46_mem_potential, True, self.is_residual)
            spike_count[0,46] += torch.sum(outp)
            # print('        layer 46, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l46_mem_potential), torch.min(l46_mem_potential), l46_mem_potential.shape))
            # generate delta-frame inputs to synapse of layer 48
            if count == 1:
                l48_pre_inp = outp
            else:
                outp = outp - l48_pre_inp
                l48_pre_inp = l48_pre_inp + outp
            spike_count[1,46] += torch.sum(torch.abs(outp))
            outp_r = self.features[48](outp)   # synapse  <-------
            # reconstruct spiking neuron full-frame inputs to layer 49
            if count == 1:
                l49_pre_inp = outp_r
            else:
                outp_r += l49_pre_inp
                l49_pre_inp = outp_r
            outp_r,l49_mem_potential = self.features[49](outp_r,l49_mem_potential, False, self.is_residual)
            # print('        layer 49, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l49_mem_potential), torch.min(l49_mem_potential), l49_mem_potential.shape))
            spike_count[0,49] += torch.sum(outp_r)
            outp_d = self.features[53](outp)    # <------- identity
            # reconstruct spiking neuron full-frame inputs to layer 55
            if count == 1:
                l55_pre_inp = outp_d
            else:
                outp_d += l55_pre_inp
                l55_pre_inp = outp_d
            outp_d,l55_mem_potential = self.features[55](outp_d,l55_mem_potential, False, self.is_residual)
            # print('        layer 55, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l55_mem_potential), torch.min(l55_mem_potential), l55_mem_potential.shape))

        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp_r = 0*l49_mem_potential
            outp_r,l49_mem_potential = self.features[49](outp_r,l49_mem_potential, True, self.is_residual)
            # print('        layer 49, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l49_mem_potential), torch.min(l49_mem_potential), l49_mem_potential.shape))
            spike_count[0,49] += torch.sum(outp_r)
             # generate delta-frame inputs to synapse of layer 50
            if count == 1:
                l50_pre_inp = outp_r
            else:
                outp_r = outp_r - l50_pre_inp
                l50_pre_inp = l50_pre_inp + outp_r
            spike_count[1,49] += torch.sum(torch.abs(outp_r))
            outp_r = self.features[50](outp_r) # dropout
            outp_r = self.features[51](outp_r) # synapse  <-------
             # reconstruct spiking neuron full-frame inputs to layer 55
            if count == 1:
                l55_pre_inp = outp_r
            else:
                outp_r += l55_pre_inp
                l55_pre_inp = outp_r
            outp_r,l55_mem_potential = self.features[55](outp_r,l55_mem_potential, False, self.is_residual)
            # print('        layer 55, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l55_mem_potential), torch.min(l55_mem_potential), l55_mem_potential.shape))
            spike_count[0,55] += torch.sum(outp_r)

            # outp_r = self.features[48](outp)    # <------- synapses
            # outp_r,l49_mem_potential = self.features[49](outp_r,l49_mem_potential, self.en_IF, self.is_residual)
            # spike_count[0,49] += torch.sum(outp_r)
            # outp_r = self.features[50](outp_r)  # <------- dropout
            # outp_r = self.features[51](outp_r)  # <------- synapses
            # outp_d = self.features[53](outp)    # <------- identity
            # outp = torch.add(outp_d, outp_r)    # ------->
            # outp,l55_mem_potential = self.features[55](outp,l55_mem_potential, self.en_IF, self.is_residual)
            # spike_count[0,55] += torch.sum(outp)

        #++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++#
        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp_r = 0*l55_mem_potential
            outp,l55_mem_potential = self.features[55](outp_r,l55_mem_potential, True, self.is_residual)
            spike_count[0,55] += torch.sum(outp)
            # print('        layer 55, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l55_mem_potential), torch.min(l55_mem_potential), l55_mem_potential.shape))
            # generate delta-frame inputs to synapse of layer 57
            if count == 1:
                l57_pre_inp = outp
            else:
                outp = outp - l57_pre_inp
                l57_pre_inp = l57_pre_inp + outp
            spike_count[1,55] += torch.sum(torch.abs(outp))
            outp_r = self.features[57](outp)   # synapse  <-------
            # reconstruct spiking neuron full-frame inputs to layer 58
            if count == 1:
                l58_pre_inp = outp_r
            else:
                outp_r += l58_pre_inp
                l58_pre_inp = outp_r
            outp_r,l58_mem_potential = self.features[58](outp_r,l58_mem_potential, False, self.is_residual)
            # print('        layer 58, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l58_mem_potential), torch.min(l58_mem_potential), l58_mem_potential.shape))
            spike_count[0,58] += torch.sum(outp_r)
            outp_d = self.features[62](outp)    # <------- identity
            # reconstruct spiking neuron full-frame inputs to layer 64
            if count == 1:
                l64_pre_inp = outp_d
            else:
                outp_d += l64_pre_inp
                l64_pre_inp = outp_d
            outp_d,l64_mem_potential = self.features[64](outp_d,l64_mem_potential, False, self.is_residual)
            # print('        layer 64, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l64_mem_potential), torch.min(l64_mem_potential), l64_mem_potential.shape))

        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp_r = 0*l58_mem_potential
            outp_r,l58_mem_potential = self.features[58](outp_r,l58_mem_potential, True, self.is_residual)
            # print('        layer 58, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l58_mem_potential), torch.min(l58_mem_potential), l58_mem_potential.shape))
            spike_count[0,58] += torch.sum(outp_r)
             # generate delta-frame inputs to synapse of layer 59
            if count == 1:
                l59_pre_inp = outp_r
            else:
                outp_r = outp_r - l59_pre_inp
                l59_pre_inp = l59_pre_inp + outp_r
            spike_count[1,58] += torch.sum(torch.abs(outp_r))
            outp_r = self.features[59](outp_r) # dropout
            outp_r = self.features[60](outp_r) # synapse  <-------
             # reconstruct spiking neuron full-frame inputs to layer 64
            if count == 1:
                l64_pre_inp = outp_r
            else:
                outp_r += l64_pre_inp
                l64_pre_inp = outp_r
            outp_r,l64_mem_potential = self.features[64](outp_r,l64_mem_potential, False, self.is_residual)
            # print('        layer 64, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l64_mem_potential), torch.min(l64_mem_potential), l64_mem_potential.shape))
            spike_count[0,64] += torch.sum(outp_r)

            # outp_r = self.features[57](outp)    # <------- synapses
            # outp_r,l58_mem_potential = self.features[58](outp_r,l58_mem_potential, self.en_IF, self.is_residual)
            # spike_count[0,58] += torch.sum(outp_r)
            # outp_r = self.features[59](outp_r)  # <------- dropout
            # outp_r = self.features[60](outp_r)  # <------- synapses
            # outp_d = self.features[62](outp)    # <------- identity
            # outp = torch.add(outp_d, outp_r)    # ------->
            # outp,l64_mem_potential = self.features[64](outp,l64_mem_potential, self.en_IF, self.is_residual)
            # spike_count[0,64] += torch.sum(outp)

        #++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++#
        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp_r = 0*l64_mem_potential
            outp,l64_mem_potential = self.features[64](outp_r,l64_mem_potential, True, self.is_residual)
            spike_count[0,64] += torch.sum(outp)
            # print('        layer 64, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l64_mem_potential), torch.min(l64_mem_potential), l64_mem_potential.shape))
            # generate delta-frame inputs to synapse of layer 66
            if count == 1:
                l66_pre_inp = outp
            else:
                outp = outp - l66_pre_inp
                l66_pre_inp = l66_pre_inp + outp
            spike_count[1,64] += torch.sum(torch.abs(outp))
            outp_r = self.features[66](outp)   # synapse  <-------
            # reconstruct spiking neuron full-frame inputs to layer 67
            if count == 1:
                l67_pre_inp = outp_r
            else:
                outp_r += l67_pre_inp
                l67_pre_inp = outp_r
            outp_r,l67_mem_potential = self.features[67](outp_r,l67_mem_potential, False, self.is_residual)
            # print('        layer 67, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l67_mem_potential), torch.min(l67_mem_potential), l67_mem_potential.shape))
            spike_count[0,67] += torch.sum(outp_r)
            outp_d = self.features[71](outp)    # <------- identity
            # reconstruct spiking neuron full-frame inputs to layer 73
            if count == 1:
                l73_pre_inp = outp_d
            else:
                outp_d += l73_pre_inp
                l73_pre_inp = outp_d
            outp_d,l73_mem_potential = self.features[73](outp_d,l73_mem_potential, False, self.is_residual)
            # print('        layer 73, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l73_mem_potential), torch.min(l73_mem_potential), l73_mem_potential.shape))

        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp_r = 0*l67_mem_potential
            outp_r,l67_mem_potential = self.features[67](outp_r,l67_mem_potential, True, self.is_residual)
            # print('        layer 67, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l67_mem_potential), torch.min(l67_mem_potential), l67_mem_potential.shape))
            spike_count[0,67] += torch.sum(outp_r)
             # generate delta-frame inputs to synapse of layer 68
            if count == 1:
                l68_pre_inp = outp_r
            else:
                outp_r = outp_r - l68_pre_inp
                l68_pre_inp = l68_pre_inp + outp_r
            spike_count[1,67] += torch.sum(torch.abs(outp_r))
            outp_r = self.features[68](outp_r) # dropout
            outp_r = self.features[69](outp_r) # synapse  <-------
             # reconstruct spiking neuron full-frame inputs to layer 73
            if count == 1:
                l73_pre_inp = outp_r
            else:
                outp_r += l73_pre_inp
                l73_pre_inp = outp_r
            outp_r,l73_mem_potential = self.features[73](outp_r,l73_mem_potential, False, self.is_residual)
            # print('        layer 73, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l73_mem_potential), torch.min(l73_mem_potential), l73_mem_potential.shape))
            spike_count[0,73] += torch.sum(outp_r)

            # outp_r = self.features[66](outp)    # <------- synapses
            # outp_r,l67_mem_potential = self.features[67](outp_r,l67_mem_potential, self.en_IF, self.is_residual)
            # spike_count[0,67] += torch.sum(outp_r)
            # outp_r = self.features[68](outp_r)  # <------- dropout
            # outp_r = self.features[69](outp_r)  # <------- synapses
            # outp_d = self.features[71](outp)    # <------- identity
            # outp = torch.add(outp_d, outp_r)    # ------->
            # outp,l73_mem_potential = self.features[73](outp,l73_mem_potential, self.en_IF, self.is_residual)
            # spike_count[0,73] += torch.sum(outp)

        #++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++#
        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp_r = 0*l73_mem_potential
            outp,l73_mem_potential = self.features[73](outp_r,l73_mem_potential, True, self.is_residual)
            spike_count[0,73] += torch.sum(outp)
            # print('        layer 73, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l73_mem_potential), torch.min(l73_mem_potential), l73_mem_potential.shape))
            # generate delta-frame inputs to synapse of layer 75
            if count == 1:
                l75_pre_inp = outp
            else:
                outp = outp - l75_pre_inp
                l75_pre_inp = l75_pre_inp + outp
            spike_count[1,73] += torch.sum(torch.abs(outp))
            outp_r = self.features[75](outp)   # synapse  <-------
            # reconstruct spiking neuron full-frame inputs to layer 76
            if count == 1:
                l76_pre_inp = outp_r
            else:
                outp_r += l76_pre_inp
                l76_pre_inp = outp_r
            outp_r,l76_mem_potential = self.features[76](outp_r,l76_mem_potential, False, self.is_residual)
            # print('        layer 76, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l76_mem_potential), torch.min(l76_mem_potential), l76_mem_potential.shape))
            spike_count[0,76] += torch.sum(outp_r)
            outp_d = torch.cat((self.features[80](outp),torch.zeros(outp_r.size(0),128,outp_r.size(2),outp_r.size(3)).cuda()),1)    # <------- identity
            # reconstruct spiking neuron full-frame inputs to layer 82
            if count == 1:
                l82_pre_inp = outp_d
            else:
                outp_d += l82_pre_inp
                l82_pre_inp = outp_d
            outp_d,l82_mem_potential = self.features[82](outp_d,l82_mem_potential, False, self.is_residual)
            # print('        layer 82, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l82_mem_potential), torch.min(l82_mem_potential), l82_mem_potential.shape))

        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp_r = 0*l76_mem_potential
            outp_r,l76_mem_potential = self.features[76](outp_r,l76_mem_potential, True, self.is_residual)
            # print('        layer 76, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l76_mem_potential), torch.min(l76_mem_potential), l76_mem_potential.shape))
            spike_count[0,76] += torch.sum(outp_r)
             # generate delta-frame inputs to synapse of layer 77
            if count == 1:
                l77_pre_inp = outp_r
            else:
                outp_r = outp_r - l77_pre_inp
                l77_pre_inp = l77_pre_inp + outp_r
            spike_count[1,76] += torch.sum(torch.abs(outp_r))
            outp_r = self.features[77](outp_r) # dropout
            outp_r = self.features[78](outp_r) # synapse  <-------
             # reconstruct spiking neuron full-frame inputs to layer 82
            if count == 1:
                l82_pre_inp = outp_r
            else:
                outp_r += l82_pre_inp
                l82_pre_inp = outp_r
            outp_r,l82_mem_potential = self.features[82](outp_r,l82_mem_potential, False, self.is_residual)
            # print('        layer 82, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l82_mem_potential), torch.min(l82_mem_potential), l82_mem_potential.shape))
            spike_count[0,82] += torch.sum(outp_r)


            # outp_r = self.features[75](outp)    # <------- synapses
            # outp_r,l76_mem_potential = self.features[76](outp_r,l76_mem_potential, self.en_IF, self.is_residual)
            # spike_count[0,76] += torch.sum(outp_r)
            # outp_r = self.features[77](outp_r)  # <------- dropout    
            # outp_r = self.features[78](outp_r)  # <------- synapses
            # outp_d = torch.cat((self.features[80](outp),torch.zeros(outp_r.size(0),128,outp_r.size(2),outp_r.size(3)).cuda()),1)    # <------- identity
            # outp = torch.add(outp_d, outp_r)    # ------->
            # outp,l82_mem_potential = self.features[82](outp,l82_mem_potential, self.en_IF, self.is_residual)
            # spike_count[0,82] += torch.sum(outp)

        #++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++#
        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp_r = 0*l82_mem_potential
            outp,l82_mem_potential = self.features[82](outp_r,l82_mem_potential, True, self.is_residual)
            spike_count[0,82] += torch.sum(outp)
            # print('        layer 82, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l82_mem_potential), torch.min(l82_mem_potential), l82_mem_potential.shape))
            # generate delta-frame inputs to synapse of layer 84
            if count == 1:
                l84_pre_inp = outp
            else:
                outp = outp - l84_pre_inp
                l84_pre_inp = l84_pre_inp + outp
            spike_count[1,82] += torch.sum(torch.abs(outp))
            outp_r = self.features[84](outp)   # synapse  <-------
            # reconstruct spiking neuron full-frame inputs to layer 85
            if count == 1:
                l85_pre_inp = outp_r
            else:
                outp_r += l85_pre_inp
                l85_pre_inp = outp_r
            outp_r,l85_mem_potential = self.features[85](outp_r,l85_mem_potential, False, self.is_residual)
            # print('        layer 85, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l85_mem_potential), torch.min(l85_mem_potential), l85_mem_potential.shape))
            spike_count[0,85] += torch.sum(outp_r)
            outp_d = self.features[89](outp)    # <------- identity
            # reconstruct spiking neuron full-frame inputs to layer 91
            if count == 1:
                l91_pre_inp = outp_d
            else:
                outp_d += l91_pre_inp
                l91_pre_inp = outp_d
            outp_d,l91_mem_potential = self.features[91](outp_d,l91_mem_potential, False, self.is_residual)
            # print('        layer 91, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l91_mem_potential), torch.min(l91_mem_potential), l91_mem_potential.shape))

        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp_r = 0*l85_mem_potential
            outp_r,l85_mem_potential = self.features[85](outp_r,l85_mem_potential, True, self.is_residual)
            # print('        layer 85, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l85_mem_potential), torch.min(l85_mem_potential), l85_mem_potential.shape))
            spike_count[0,85] += torch.sum(outp_r)
             # generate delta-frame inputs to synapse of layer 86
            if count == 1:
                l86_pre_inp = outp_r
            else:
                outp_r = outp_r - l86_pre_inp
                l86_pre_inp = l86_pre_inp + outp_r
            spike_count[1,85] += torch.sum(torch.abs(outp_r))
            outp_r = self.features[86](outp_r) # dropout
            outp_r = self.features[87](outp_r) # synapse  <-------
             # reconstruct spiking neuron full-frame inputs to layer 91
            if count == 1:
                l91_pre_inp = outp_r
            else:
                outp_r += l91_pre_inp
                l91_pre_inp = outp_r
            outp_r,l91_mem_potential = self.features[91](outp_r,l91_mem_potential, False, self.is_residual)
            # print('        layer 91, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l91_mem_potential), torch.min(l91_mem_potential), l91_mem_potential.shape))
            spike_count[0,91] += torch.sum(outp_r)


            # outp_r = self.features[84](outp)    # <------- synapses
            # outp_r,l85_mem_potential = self.features[85](outp_r,l85_mem_potential, self.en_IF, self.is_residual)
            # spike_count[0,85] += torch.sum(outp_r)
            # outp_r = self.features[86](outp_r)  # <------- dropout
            # outp_r = self.features[87](outp_r)  # <------- synapses
            # outp_d = self.features[89](outp)    # <------- identity
            # outp = torch.add(outp_d, outp_r)    # ------->
            # outp,l91_mem_potential = self.features[91](outp,l91_mem_potential, self.en_IF, self.is_residual)
            # spike_count[0,91] += torch.sum(outp)

        #++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++#
        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp_r = 0*l91_mem_potential
            outp,l91_mem_potential = self.features[91](outp_r,l91_mem_potential, True, self.is_residual)
            spike_count[0,91] += torch.sum(outp)
            # print('        layer 91, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l91_mem_potential), torch.min(l91_mem_potential), l91_mem_potential.shape))
            # generate delta-frame inputs to synapse of layer 93
            if count == 1:
                l93_pre_inp = outp
            else:
                outp = outp - l93_pre_inp
                l93_pre_inp = l93_pre_inp + outp
            spike_count[1,91] += torch.sum(torch.abs(outp))
            outp_r = self.features[93](outp)   # synapse  <-------
            # reconstruct spiking neuron full-frame inputs to layer 94
            if count == 1:
                l94_pre_inp = outp_r
            else:
                outp_r += l94_pre_inp
                l94_pre_inp = outp_r
            outp_r,l94_mem_potential = self.features[94](outp_r,l94_mem_potential, False, self.is_residual)
            # print('        layer 94, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l94_mem_potential), torch.min(l94_mem_potential), l94_mem_potential.shape))
            spike_count[0,94] += torch.sum(outp_r)
            outp_d = self.features[98](outp)    # <------- identity
            # reconstruct spiking neuron full-frame inputs to layer 100
            if count == 1:
                l100_pre_inp = outp_d
            else:
                outp_d += l100_pre_inp
                l100_pre_inp = outp_d
            outp_d,l100_mem_potential = self.features[100](outp_d,l100_mem_potential, False, self.is_residual)
            # print('        layer 100, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l100_mem_potential), torch.min(l100_mem_potential), l100_mem_potential.shape))

        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp_r = 0*l94_mem_potential
            outp_r,l94_mem_potential = self.features[94](outp_r,l94_mem_potential, True, self.is_residual)
            # print('        layer 94, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l94_mem_potential), torch.min(l94_mem_potential), l94_mem_potential.shape))
            spike_count[0,94] += torch.sum(outp_r)
             # generate delta-frame inputs to synapse of layer 95
            if count == 1:
                l95_pre_inp = outp_r
            else:
                outp_r = outp_r - l95_pre_inp
                l95_pre_inp = l95_pre_inp + outp_r
            spike_count[1,94] += torch.sum(torch.abs(outp_r))
            outp_r = self.features[95](outp_r) # dropout
            outp_r = self.features[96](outp_r) # synapse  <-------
             # reconstruct spiking neuron full-frame inputs to layer 100
            if count == 1:
                l100_pre_inp = outp_r
            else:
                outp_r += l100_pre_inp
                l100_pre_inp = outp_r
            outp_r,l100_mem_potential = self.features[100](outp_r,l100_mem_potential, False, self.is_residual)
            # print('        layer 100, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l100_mem_potential), torch.min(l100_mem_potential), l100_mem_potential.shape))
            spike_count[0,100] += torch.sum(outp_r)


            # outp_r = self.features[93](outp)    # <------- synapses
            # outp_r,l94_mem_potential = self.features[94](outp_r,l94_mem_potential, self.en_IF, self.is_residual)
            # spike_count[0,94] += torch.sum(outp_r)
            # outp_r = self.features[95](outp_r)  # <------- dropout
            # outp_r = self.features[96](outp_r)  # <------- synapses
            # outp_d = self.features[98](outp)    # <------- identity
            # outp = torch.add(outp_d, outp_r)    # ------->
            # outp,l100_mem_potential = self.features[100](outp,l100_mem_potential, self.en_IF, self.is_residual)
            # spike_count[0,100] += torch.sum(outp)

        #++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++#
        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp_r = 0*l100_mem_potential
            outp,l100_mem_potential = self.features[100](outp_r,l100_mem_potential, True, self.is_residual)
            spike_count[0,100] += torch.sum(outp)
            # print('        layer 100, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l100_mem_potential), torch.min(l100_mem_potential), l100_mem_potential.shape))
            # generate delta-frame inputs to synapse of layer 102
            if count == 1:
                l102_pre_inp = outp
            else:
                outp = outp - l102_pre_inp
                l102_pre_inp = l102_pre_inp + outp
            spike_count[1,100] += torch.sum(torch.abs(outp))
            outp_r = self.features[102](outp)   # synapse  <-------
            # reconstruct spiking neuron full-frame inputs to layer 103
            if count == 1:
                l103_pre_inp = outp_r
            else:
                outp_r += l103_pre_inp
                l103_pre_inp = outp_r
            outp_r,l103_mem_potential = self.features[103](outp_r,l103_mem_potential, False, self.is_residual)
            # print('        layer 103, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l103_mem_potential), torch.min(l103_mem_potential), l103_mem_potential.shape))
            spike_count[0,103] += torch.sum(outp_r)
            outp_d = self.features[107](outp)    # <------- identity
            # reconstruct spiking neuron full-frame inputs to layer 109
            if count == 1:
                l109_pre_inp = outp_d
            else:
                outp_d += l109_pre_inp
                l109_pre_inp = outp_d
            outp_d,l109_mem_potential = self.features[109](outp_d,l109_mem_potential, False, self.is_residual)
            # print('        layer 109, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l109_mem_potential), torch.min(l109_mem_potential), l109_mem_potential.shape))

        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp_r = 0*l103_mem_potential
            outp_r,l103_mem_potential = self.features[103](outp_r,l103_mem_potential, True, self.is_residual)
            # print('        layer 103, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l103_mem_potential), torch.min(l103_mem_potential), l103_mem_potential.shape))
            spike_count[0,103] += torch.sum(outp_r)
             # generate delta-frame inputs to synapse of layer 104
            if count == 1:
                l104_pre_inp = outp_r
            else:
                outp_r = outp_r - l104_pre_inp
                l104_pre_inp = l104_pre_inp + outp_r
            spike_count[1,103] += torch.sum(torch.abs(outp_r))
            outp_r = self.features[104](outp_r) # dropout
            outp_r = self.features[105](outp_r) # synapse  <-------
             # reconstruct spiking neuron full-frame inputs to layer 109
            if count == 1:
                l109_pre_inp = outp_r
            else:
                outp_r += l109_pre_inp
                l109_pre_inp = outp_r
            outp_r,l109_mem_potential = self.features[109](outp_r,l109_mem_potential, False, self.is_residual)
            # print('        layer 109, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l109_mem_potential), torch.min(l109_mem_potential), l109_mem_potential.shape))
            spike_count[0,109] += torch.sum(outp_r)


            # outp_r = self.features[102](outp)    # <------- synapses
            # outp_r,l103_mem_potential = self.features[103](outp_r,l103_mem_potential, self.en_IF, self.is_residual)
            # spike_count[0,103] += torch.sum(outp_r)
            # outp_r = self.features[104](outp_r)  # <------- dropout
            # outp_r = self.features[105](outp_r)  # <------- synapses
            # outp_d = self.features[107](outp)    # <------- identity
            # outp = torch.add(outp_d, outp_r)     # ------->
            # outp,l109_mem_potential = self.features[109](outp,l109_mem_potential, self.en_IF, self.is_residual)
            # spike_count[0,109] += torch.sum(outp)

        #++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++#
        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp_r = 0*l109_mem_potential
            outp,l109_mem_potential = self.features[109](outp_r,l109_mem_potential, True, self.is_residual)
            spike_count[0,109] += torch.sum(outp)
            # print('        layer 109, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l109_mem_potential), torch.min(l109_mem_potential), l109_mem_potential.shape))
            # generate delta-frame inputs to synapse of layer 111
            if count == 1:
                l111_pre_inp = outp
            else:
                outp = outp - l111_pre_inp
                l111_pre_inp = l111_pre_inp + outp
            spike_count[1,109] += torch.sum(torch.abs(outp))
            outp_r = self.features[111](outp)   # synapse  <-------
            # reconstruct spiking neuron full-frame inputs to layer 112
            if count == 1:
                l112_pre_inp = outp_r
            else:
                outp_r += l112_pre_inp
                l112_pre_inp = outp_r
            outp_r,l112_mem_potential = self.features[112](outp_r,l112_mem_potential, False, self.is_residual)
            # print('        layer 112, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l112_mem_potential), torch.min(l112_mem_potential), l112_mem_potential.shape))
            spike_count[0,112] += torch.sum(outp_r)
            outp_d = self.features[116](outp)    # <------- identity
            # reconstruct spiking neuron full-frame inputs to layer 118
            if count == 1:
                l118_pre_inp = outp_d
            else:
                outp_d += l118_pre_inp
                l118_pre_inp = outp_d
            outp_d,l118_mem_potential = self.features[118](outp_d,l118_mem_potential, False, self.is_residual)
            # print('        layer 118, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l118_mem_potential), torch.min(l118_mem_potential), l118_mem_potential.shape))

        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp_r = 0*l112_mem_potential
            outp_r,l112_mem_potential = self.features[112](outp_r,l112_mem_potential, True, self.is_residual)
            # print('        layer 112, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l112_mem_potential), torch.min(l112_mem_potential), l112_mem_potential.shape))
            spike_count[0,112] += torch.sum(outp_r)
             # generate delta-frame inputs to synapse of layer 113
            if count == 1:
                l113_pre_inp = outp_r
            else:
                outp_r = outp_r - l113_pre_inp
                l113_pre_inp = l113_pre_inp + outp_r
            spike_count[1,112] += torch.sum(torch.abs(outp_r))
            outp_r = self.features[113](outp_r) # dropout
            outp_r = self.features[114](outp_r) # synapse  <-------
             # reconstruct spiking neuron full-frame inputs to layer 118
            if count == 1:
                l118_pre_inp = outp_r
            else:
                outp_r += l118_pre_inp
                l118_pre_inp = outp_r
            outp_r,l118_mem_potential = self.features[118](outp_r,l118_mem_potential, False, self.is_residual)
            # print('        layer 118, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l118_mem_potential), torch.min(l118_mem_potential), l118_mem_potential.shape))
            spike_count[0,118] += torch.sum(outp_r)


            # outp_r = self.features[111](outp)    # <------- synapses
            # outp_r,l112_mem_potential = self.features[112](outp_r,l112_mem_potential, self.en_IF, self.is_residual)
            # spike_count[0,112] += torch.sum(outp_r)
            # outp_r = self.features[113](outp_r)  # <------- dropout
            # outp_r = self.features[114](outp_r)  # <------- synapses
            # outp_d = self.features[116](outp)    # <------- identity
            # outp = torch.add(outp_d, outp_r)     # ------->
            # outp,l118_mem_potential = self.features[118](outp,l118_mem_potential, self.en_IF, self.is_residual)
            # spike_count[0,118] += torch.sum(outp)

        #++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++#
        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp_r = 0*l118_mem_potential
            outp,l118_mem_potential = self.features[118](outp_r,l118_mem_potential, True, self.is_residual)
            spike_count[0,118] += torch.sum(outp)
            # print('        layer 118, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l118_mem_potential), torch.min(l118_mem_potential), l118_mem_potential.shape))
            # generate delta-frame inputs to synapse of layer 120
            if count == 1:
                l120_pre_inp = outp
            else:
                outp = outp - l120_pre_inp
                l120_pre_inp = l120_pre_inp + outp
            spike_count[1,118] += torch.sum(torch.abs(outp))
            outp_r = self.features[120](outp)   # synapse  <-------
            # reconstruct spiking neuron full-frame inputs to layer 121
            if count == 1:
                l121_pre_inp = outp_r
            else:
                outp_r += l121_pre_inp
                l121_pre_inp = outp_r
            outp_r,l121_mem_potential = self.features[121](outp_r,l121_mem_potential, False, self.is_residual)
            # print('        layer 121, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l121_mem_potential), torch.min(l121_mem_potential), l121_mem_potential.shape))
            spike_count[0,121] += torch.sum(outp_r)
            outp_d = self.features[125](outp)    # <------- identity
            # reconstruct spiking neuron full-frame inputs to layer 127
            if count == 1:
                l127_pre_inp = outp_d
            else:
                outp_d += l127_pre_inp
                l127_pre_inp = outp_d
            outp_d,l127_mem_potential = self.features[127](outp_d,l127_mem_potential, False, self.is_residual)
            # print('        layer 127, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l127_mem_potential), torch.min(l127_mem_potential), l127_mem_potential.shape))

        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp_r = 0*l121_mem_potential
            outp_r,l121_mem_potential = self.features[121](outp_r,l121_mem_potential, True, self.is_residual)
            # print('        layer 121, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l121_mem_potential), torch.min(l121_mem_potential), l121_mem_potential.shape))
            spike_count[0,121] += torch.sum(outp_r)
             # generate delta-frame inputs to synapse of layer 122
            if count == 1:
                l122_pre_inp = outp_r
            else:
                outp_r = outp_r - l122_pre_inp
                l122_pre_inp = l122_pre_inp + outp_r
            spike_count[1,121] += torch.sum(torch.abs(outp_r))
            outp_r = self.features[122](outp_r) # dropout
            outp_r = self.features[123](outp_r) # synapse  <-------
             # reconstruct spiking neuron full-frame inputs to layer 127
            if count == 1:
                l127_pre_inp = outp_r
            else:
                outp_r += l127_pre_inp
                l127_pre_inp = outp_r
            outp_r,l127_mem_potential = self.features[127](outp_r,l127_mem_potential, False, self.is_residual)
            # print('        layer 127, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l127_mem_potential), torch.min(l127_mem_potential), l127_mem_potential.shape))
            spike_count[0,127] += torch.sum(outp_r)


            # outp_r = self.features[120](outp)    # <------- synapses
            # outp_r,l121_mem_potential = self.features[121](outp_r,l121_mem_potential, self.en_IF, self.is_residual)
            # spike_count[0,121] += torch.sum(outp_r)
            # outp_r = self.features[122](outp_r)  # <------- dropout
            outp_r = self.features[123](outp_r)  # <------- synapses
            outp_d = self.features[125](outp)    # <------- identity
            outp = torch.add(outp_d, outp_r)     # ------->
            outp,l127_mem_potential = self.features[127](outp,l127_mem_potential, self.en_IF, self.is_residual)
            spike_count[0,127] += torch.sum(outp)

        #++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++#
        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp_r = 0*l127_mem_potential
            outp,l127_mem_potential = self.features[127](outp_r,l127_mem_potential, True, self.is_residual)
            spike_count[0,127] += torch.sum(outp)
            # print('        layer 127, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l127_mem_potential), torch.min(l127_mem_potential), l127_mem_potential.shape))
            # generate delta-frame inputs to synapse of layer 129
            if count == 1:
                l129_pre_inp = outp
            else:
                outp = outp - l129_pre_inp
                l129_pre_inp = l129_pre_inp + outp
            spike_count[1,127] += torch.sum(torch.abs(outp))
            outp_r = self.features[129](outp)   # synapse  <-------
            # reconstruct spiking neuron full-frame inputs to layer 130
            if count == 1:
                l130_pre_inp = outp_r
            else:
                outp_r += l130_pre_inp
                l130_pre_inp = outp_r
            outp_r,l130_mem_potential = self.features[130](outp_r,l130_mem_potential, False, self.is_residual)
            # print('        layer 130, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l130_mem_potential), torch.min(l130_mem_potential), l130_mem_potential.shape))
            spike_count[0,130] += torch.sum(outp_r)
            outp_d = torch.cat((self.features[134](outp),torch.zeros(outp_r.size(0),256,outp_r.size(2),outp_r.size(3)).cuda()),1)    # <------- identity
            # reconstruct spiking neuron full-frame inputs to layer 136
            if count == 1:
                l136_pre_inp = outp_d
            else:
                outp_d += l136_pre_inp
                l136_pre_inp = outp_d
            outp_d,l136_mem_potential = self.features[136](outp_d,l136_mem_potential, False, self.is_residual)
            # print('        layer 136, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l136_mem_potential), torch.min(l136_mem_potential), l136_mem_potential.shape))

        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp_r = 0*l130_mem_potential
            outp_r,l130_mem_potential = self.features[130](outp_r,l130_mem_potential, True, self.is_residual)
            # print('        layer 130, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l130_mem_potential), torch.min(l130_mem_potential), l130_mem_potential.shape))
            spike_count[0,130] += torch.sum(outp_r)
             # generate delta-frame inputs to synapse of layer 131
            if count == 1:
                l131_pre_inp = outp_r
            else:
                outp_r = outp_r - l131_pre_inp
                l131_pre_inp = l131_pre_inp + outp_r
            spike_count[1,130] += torch.sum(torch.abs(outp_r))
            outp_r = self.features[131](outp_r) # dropout
            outp_r = self.features[132](outp_r) # synapse  <-------
             # reconstruct spiking neuron full-frame inputs to layer 136
            if count == 1:
                l136_pre_inp = outp_r
            else:
                outp_r += l136_pre_inp
                l136_pre_inp = outp_r
            outp_r,l136_mem_potential = self.features[136](outp_r,l136_mem_potential, False, self.is_residual)
            # print('        layer 136, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l136_mem_potential), torch.min(l136_mem_potential), l136_mem_potential.shape))
            spike_count[0,136] += torch.sum(outp_r)


            # outp_r = self.features[129](outp)    # <------- synapses
            # outp_r,l130_mem_potential = self.features[130](outp_r,l130_mem_potential, self.en_IF, self.is_residual)
            # spike_count[0,130] += torch.sum(outp_r)
            # outp_r = self.features[131](outp_r)  # <------- dropout
            # outp_r = self.features[132](outp_r)  # <------- synapses
            # outp_d = torch.cat((self.features[134](outp),torch.zeros(outp_r.size(0),256,outp_r.size(2),outp_r.size(3)).cuda()),1)    # <------- identity
            # outp = torch.add(outp_d, outp_r)     # ------->
            # outp,l136_mem_potential = self.features[136](outp,l136_mem_potential, self.en_IF, self.is_residual)
            # spike_count[0,136] += torch.sum(outp)

        #++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++#
        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp_r = 0*l136_mem_potential
            outp,l136_mem_potential = self.features[136](outp_r,l136_mem_potential, True, self.is_residual)
            spike_count[0,136] += torch.sum(outp)
            # print('        layer 136, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l136_mem_potential), torch.min(l136_mem_potential), l136_mem_potential.shape))
            # generate delta-frame inputs to synapse of layer 138
            if count == 1:
                l138_pre_inp = outp
            else:
                outp = outp - l138_pre_inp
                l138_pre_inp = l138_pre_inp + outp
            spike_count[1,136] += torch.sum(torch.abs(outp))
            outp_r = self.features[138](outp)   # synapse  <-------
            # reconstruct spiking neuron full-frame inputs to layer 139
            if count == 1:
                l139_pre_inp = outp_r
            else:
                outp_r += l139_pre_inp
                l139_pre_inp = outp_r
            outp_r,l139_mem_potential = self.features[139](outp_r,l139_mem_potential, False, self.is_residual)
            # print('        layer 139, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l139_mem_potential), torch.min(l139_mem_potential), l139_mem_potential.shape))
            spike_count[0,139] += torch.sum(outp_r)
            outp_d = self.features[143](outp)    # <------- identity
            # reconstruct spiking neuron full-frame inputs to layer 145
            if count == 1:
                l145_pre_inp = outp_d
            else:
                outp_d += l145_pre_inp
                l145_pre_inp = outp_d
            outp_d,l145_mem_potential = self.features[145](outp_d,l145_mem_potential, False, self.is_residual)
            # print('        layer 145, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l145_mem_potential), torch.min(l145_mem_potential), l145_mem_potential.shape))

        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp_r = 0*l139_mem_potential
            outp_r,l139_mem_potential = self.features[139](outp_r,l139_mem_potential, True, self.is_residual)
            # print('        layer 139, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l139_mem_potential), torch.min(l139_mem_potential), l139_mem_potential.shape))
            spike_count[0,139] += torch.sum(outp_r)
             # generate delta-frame inputs to synapse of layer 140
            if count == 1:
                l140_pre_inp = outp_r
            else:
                outp_r = outp_r - l140_pre_inp
                l140_pre_inp = l140_pre_inp + outp_r
            spike_count[1,139] += torch.sum(torch.abs(outp_r))
            outp_r = self.features[140](outp_r) # dropout
            outp_r = self.features[141](outp_r) # synapse  <-------
             # reconstruct spiking neuron full-frame inputs to layer 145
            if count == 1:
                l145_pre_inp = outp_r
            else:
                outp_r += l145_pre_inp
                l145_pre_inp = outp_r
            outp_r,l145_mem_potential = self.features[145](outp_r,l145_mem_potential, False, self.is_residual)
            # print('        layer 145, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l145_mem_potential), torch.min(l145_mem_potential), l145_mem_potential.shape))
            spike_count[0,145] += torch.sum(outp_r)


            # outp_r = self.features[138](outp)    # <------- synapses
            # outp_r,l139_mem_potential = self.features[139](outp_r,l139_mem_potential, self.en_IF, self.is_residual)
            # spike_count[0,139] += torch.sum(outp_r)
            # outp_r = self.features[140](outp_r)  # <------- dropout
            # outp_r = self.features[141](outp_r)  # <------- synapses
            # outp_d = self.features[143](outp)    # <------- identity
            # outp = torch.add(outp_d, outp_r)     # ------->
            # outp,l145_mem_potential = self.features[145](outp,l145_mem_potential, self.en_IF, self.is_residual)
            # spike_count[0,145] += torch.sum(outp)

        #++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++#
        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp_r = 0*l145_mem_potential
            outp,l145_mem_potential = self.features[145](outp_r,l145_mem_potential, True, self.is_residual)
            spike_count[0,145] += torch.sum(outp)
            # print('        layer 145, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l145_mem_potential), torch.min(l145_mem_potential), l145_mem_potential.shape))
            # generate delta-frame inputs to synapse of layer 147
            if count == 1:
                l147_pre_inp = outp
            else:
                outp = outp - l147_pre_inp
                l147_pre_inp = l147_pre_inp + outp
            spike_count[1,145] += torch.sum(torch.abs(outp))
            outp_r = self.features[147](outp)   # synapse  <-------
            # reconstruct spiking neuron full-frame inputs to layer 148
            if count == 1:
                l148_pre_inp = outp_r
            else:
                outp_r += l148_pre_inp
                l148_pre_inp = outp_r
            outp_r,l148_mem_potential = self.features[148](outp_r,l148_mem_potential, False, self.is_residual)
            # print('        layer 148, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l148_mem_potential), torch.min(l148_mem_potential), l148_mem_potential.shape))
            spike_count[0,148] += torch.sum(outp_r)
            outp_d = self.features[152](outp)    # <------- identity
            # reconstruct spiking neuron full-frame inputs to layer 154
            if count == 1:
                l154_pre_inp = outp_d
            else:
                outp_d += l154_pre_inp
                l154_pre_inp = outp_d
            outp_d,l154_mem_potential = self.features[154](outp_d,l154_mem_potential, False, self.is_residual)
            # print('        layer 154, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l154_mem_potential), torch.min(l154_mem_potential), l154_mem_potential.shape))

        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp_r = 0*l148_mem_potential
            outp_r,l148_mem_potential = self.features[148](outp_r,l148_mem_potential, True, self.is_residual)
            # print('        layer 148, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l148_mem_potential), torch.min(l148_mem_potential), l148_mem_potential.shape))
            spike_count[0,148] += torch.sum(outp_r)
             # generate delta-frame inputs to synapse of layer 149
            if count == 1:
                l149_pre_inp = outp_r
            else:
                outp_r = outp_r - l149_pre_inp
                l149_pre_inp = l149_pre_inp + outp_r
            spike_count[1,148] += torch.sum(torch.abs(outp_r))
            outp_r = self.features[149](outp_r) # dropout
            outp_r = self.features[150](outp_r) # synapse  <-------
             # reconstruct spiking neuron full-frame inputs to layer 154
            if count == 1:
                l154_pre_inp = outp_r
            else:
                outp_r += l154_pre_inp
                l154_pre_inp = outp_r
            outp_r,l154_mem_potential = self.features[154](outp_r,l154_mem_potential, False, self.is_residual)
            # print('        layer 154, max {1:1.2f}, min {2:1.2f}, {3}'.format(ts, torch.max(l154_mem_potential), torch.min(l154_mem_potential), l154_mem_potential.shape))
            spike_count[0,154] += torch.sum(outp_r)


            # outp_r = self.features[147](outp)    # <------- synapses
            # outp_r,l148_mem_potential = self.features[148](outp_r,l148_mem_potential, self.en_IF, self.is_residual)
            # spike_count[0,148] += torch.sum(outp_r)
            # outp_r = self.features[149](outp_r)  # <------- dropout
            # outp_r = self.features[150](outp_r)  # <------- synapses
            # outp_d = self.features[152](outp)    # <------- identity
            # outp = torch.add(outp_d, outp_r)     # ------->
            # outp,l154_mem_potential = self.features[154](outp,l154_mem_potential, self.en_IF, self.is_residual)
            # spike_count[0,154] += torch.sum(outp)

        #++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++#
        count = 0
        for ts in range(self.TTS):
            count = count + 1
            if count%self.fpi==0:
                count = 1
            outp_r = 0*l154_mem_potential
            outp,l154_mem_potential = self.features[154](outp_r,l154_mem_potential, True, self.is_residual)
            spike_count[0,154] += torch.sum(outp)
            #------------------------------------------------------------
            # generate delta-frame inputs to synapse of layer 155
            if count == 1:
                l155_pre_inp = outp
            else:
                outp = outp - l155_pre_inp
                l155_pre_inp = l155_pre_inp + outp
            spike_count[1,154] += torch.sum(torch.abs(outp))
            outp = self.features[155](outp)
            # reconstruct spiking neuron full-frame inputs to classifier
            if count == 1:
                classifier_pre_inp = outp
            else:
                outp += classifier_pre_inp
                classifier_pre_inp = outp
            #------------------------------------------------------------
            outp = outp.view(outp.size(0), -1)
            outp = self.classifier[0](outp)
            outp_sum += outp
        return outp_sum,l2_max_inp,l5_max_inp,l8_max_inp, spike_count

# Rate version of simple network
class ResNetRate(nn.Module):
    def __init__(self, dropout_prob_list=[0.1,0.1,0.1,0.1]):
        super(ResNetRate, self).__init__()
        # Instantiate layers
        self.features = make_features(is_spike=False, is_temp=False, dropout_prob_list=dropout_prob_list)
        self.classifier = make_classifier(is_spike=False)
        print('Dropout Probability: {}'.format(dropout_prob_list))
        # Initialize weights in the MSR style (http://arxiv.org/pdf/1502.01852v1.pdf) which is more suitable for deep network than Xavier initialization (default initialization of convolutional layer in PyTorch)
        self.initialize_weights()
    def forward(self, inp):
        outp = self.features(inp)
        outp = outp.view(outp.size(0), -1)
        outp = self.classifier(outp)
        return outp
    def initialize_weights(self):
        # Initialize all convolutional layers
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                m.weight.data.normal_(0, math.sqrt(2./n))
                if m.bias is not None:
                    m.bias.data.zero_()
        # Reinitialize convolutional residual layer 
        for m in self.modules():
            if isinstance(m, BasicBlock0) or isinstance(m, BasicBlock1):
                for sm in m.modules():
                    if isinstance(sm, nn.Conv2d):
                        n = sm.kernel_size[0] * sm.kernel_size[1] * sm.out_channels
                        sm.weight.data.normal_(0, math.sqrt(2.)/float(n))
                        if sm.bias is not None:
                            sm.bias.data.zero_()

if __name__ == '__main__':

    # Test rate model with random input (batchsize of 4)
    inp = torch.rand(4,3,224,224) 
    print('-'*40)
    # Instantiate rate-baed ResNet model and parallelize model across GPUs, but only for convolutional layers (check this out https://arxiv.org/pdf/1404.5997.pdf)
    model_rate = ResNetRate()
    model_rate = torch.nn.DataParallel(model_rate).cuda()
    # Print model
    print(model_rate)
    # Compute output
    outp = model_rate(inp)
    print('Test successful!')
    
    # Test spiking model with random input (batchsize of 4)
    print('-'*40)
    # Instantiate spiking ResNet model and parallel model across multiple GPUs
    model_spike = ResNetSpike()
    model_spike = torch.nn.DataParallel(model_spike).cuda()
    # Print model
    print(model_spike)
    # Compute output
    model_spike.eval()
    with torch.no_grad():
        outp = model_spike(inp)
    print('Test successful!')

    # Automatically generate weight mapping list and forward statement
    print('-'*40)
    # After training rate-based model, weight of convolutional layers in the rate-based model is copied to that in the spiking model
    print(len(list(model_rate.state_dict().keys())))
    print(len(list(model_spike.state_dict().keys())))
    print(list(zip(list(model_rate.state_dict().keys()),list(model_spike.state_dict().keys()))))
    # Forward statement for spiking model
    print()
    print('    for j in range(int(self.t_end/self.dt)):')
    inp_dim = 3
    inp_size = 224
    pad_dim = None
    outstr = 'inp'
    initstr = '    outp_sum = torch.zeros(inp.size(0),10).cuda()\n'
    returnstr = '    return outp_sum'
    set1str = '    outp'
    set2str = []
    conv_count = 0
    delay_path = False
    residue_path = False
    # Forward statement for convolutional layers
    for i,m in enumerate(model_spike.module.features):
        if isinstance(m,PoissonGen):
            outstr = 'self.features[{}]({})'.format(i,outstr)
        elif isinstance(m,ResidueMark):
            if outstr != 'outp':
                print('        outp = {}'.format(outstr))
                outstr = 'outp'
            residue_path = True
            rpathstr = 'outp'
        elif isinstance(m,DelayMark):
            residue_path = False
            delay_path = True
            dpathstr = 'outp'
        elif isinstance(m,MergeMark1):
            delay_path = False
            print('        outp_r = {}'.format(rpathstr))
            print('        outp_d = {}'.format(dpathstr))
            print('        outp = torch.add(outp_d, outp_r)')
        elif isinstance(m,MergeMark0):
            delay_path = False
            print('        outp_r = {}'.format(rpathstr))
            print('        outp_d = torch.cat(({},torch.zeros(outp_r.size(0),{},outp_r.size(2),outp_r.size(3)).cuda()),1)'.format(dpathstr,pad_dim))
            print('        outp = torch.add(outp_d, outp_r)')
        elif isinstance(m,nn.Conv2d):
            if residue_path:
                if int(m.in_channels) != int(m.out_channels):
                    pad_dim = int(m.out_channels) - int(m.in_channels)
                inp_dim = int(m.out_channels)
                inp_size = math.floor((inp_size-m.kernel_size[0]+2*m.padding[0])/m.stride[0])+1
                rpathstr = 'self.features[{}]({})'.format(i,rpathstr)
            else:
                inp_dim = int(m.out_channels)
                inp_size = math.floor((inp_size-m.kernel_size[0]+2*m.padding[0])/m.stride[0])+1
                outstr = 'self.features[{}]({})'.format(i,outstr)
        elif isinstance(m,Identity):
            dpathstr = 'self.features[{}]({})'.format(i,dpathstr)
        elif isinstance(m,nn.Dropout):
            if residue_path: 
                rpathstr = 'self.features[{}]({})'.format(i,rpathstr)
            else: 
                outstr = 'self.features[{}]({})'.format(i,outstr)
        elif isinstance(m,nn.AvgPool2d):
            if delay_path: 
                dpathstr = 'self.features[{}]({})'.format(i,dpathstr)
            else:
                outstr = 'self.features[{}]({})'.format(i,outstr)
                inp_size = int((inp_size-m.kernel_size[0])/m.stride[0]+1)
        elif isinstance(m,IFNeuron):
            if residue_path: 
                # rpathstr = 'self.features[{}]({})'.format(i,rpathstr)
                print('        outp_r = {}'.format(rpathstr))
                rpathstr = 'outp_r'
                print('        outp_r,l{}_mem_potential = self.features[{}](outp_r,l{}_mem_potential)'.format(i,i,i))
                initstr += '    l{}_mem_potential = torch.zeros(inp.size(0),{},{},{}).cuda()\n'.format(i,inp_dim,inp_size,inp_size)
            else:
                if outstr != 'outp':
                    print('        outp = {}'.format(outstr))
                    outstr = 'outp'
                if conv_count < 3:
                    print('        l{}_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l{}_max_inp)'.format(i,i))
                    print('        outp,l{}_mem_potential = self.features[{}](outp,l{}_mem_potential)'.format(i,i,i))
                    initstr += '    l{}_mem_potential = torch.zeros(inp.size(0),{},{},{}).cuda()\n'.format(i,inp_dim,inp_size,inp_size)
                    initstr += '    l{}_max_inp = torch.zeros(inp.size(0),1).cuda()\n'.format(i)
                    returnstr += ',l{}_max_inp'.format(i) 
                    set1str += ',l{}_max_inp'.format(i) 
                    set2str.append('model_spike.module.features[{}].set_thres(float(torch.max(l{}_max_inp)))\n'.format(i,i))
                    conv_count += 1
                else:
                    print('        outp,l{}_mem_potential = self.features[{}](outp,l{}_mem_potential)'.format(i,i,i))
                    initstr += '    l{}_mem_potential = torch.zeros(inp.size(0),{},{},{}).cuda()\n'.format(i,inp_dim,inp_size,inp_size)

        else: 
            assert False, 'Unrecognized module {}'.format(m)
    print('        outp = {}'.format(outstr))
    # Forward statement for reshaping
    outstr = 'outp'
    print('        outp = outp.view(outp.size(0), -1)')
    inp_dim = (inp_dim * inp_size * inp_size)
    # Forward statement for fully connected-layer
    for i,m in enumerate(model_spike.module.classifier):
        if isinstance(m,nn.Linear):
            outstr = 'self.classifier[{}]({})'.format(i,outstr)
        else: 
            assert False, 'Unrecognized module {}'.format(m)
    print('        outp = {}'.format(outstr))
    print('        outp_sum += outp')
    print()
    print(returnstr)
    # Print initialization statement
    print(initstr)
    print()
    set1str += ' = model_spike(inp)'
    for each in set2str:
        print(set1str)
        print(each)
