import argparse
import os
import time
import sys

import numpy as np

import torch
import torch.nn as nn
import torch.nn.parallel
import torch.backends.cudnn as cudnn
import torch.optim
from torchvision import datasets, transforms
from tqdm import tqdm

parser = argparse.ArgumentParser(description='Comparison of ANN-SNN Conversion Techniques - ResNet20 with CIFAR-100', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
parser.add_argument('--start_epoch', default=1, type=int, help='starting epoch number (this value is set automatically if resume)')
parser.add_argument('--max_epoch', default=600, type=int, help='number of total epochs to run')
parser.add_argument('--batch_size', default=100, type=int, help='batch size')
parser.add_argument('--learning_rate', default=0.05, type=float, help='initial learning rate')
parser.add_argument('--momentum', default=0.9, type=float, help='momentum')
parser.add_argument('--num_workers', default=16, type=int, help='number of workers')
parser.add_argument('--weight_decay', default=1e-4, type=float, help='weight decay')
parser.add_argument('--resume', default='', type=str, help='path to latest checkpoint')
parser.add_argument('--evaluate', dest='evaluate', action='store_true', help='evaluate model on validation set')
parser.add_argument('--seed', default=10, type=int, help='random seed')
parser.add_argument('--log', default=None, help='log file location')
parser.add_argument('--save_dir', default=None, help='saved directory location')
parser.add_argument('--dt', default=0.001, type=float, help='simulation timestep')
parser.add_argument('--t_end', default=2.500, type=float, help='single example simulation time')
parser.add_argument('--dropout_prob_0', default=0.0, type=float, help='dropout probability of 1st feature')
parser.add_argument('--dropout_prob_1', default=0.0, type=float, help='dropout probability of 2nd feature')
parser.add_argument('--dropout_prob_2', default=0.0, type=float, help='dropout probability of 3rd feature')
parser.add_argument('--dropout_prob_3', default=0.0, type=float, help='dropout probability of other features')
parser.add_argument('--testing', dest='not_testing', action='store_false', help='skip conversion testing if specified')

parser.add_argument('--gpu_id', default='0,1,2,3', type=str, help='id(s) for CUDA_VISIBLE_DEVICES')
parser.add_argument('--vth_vb', default=0.73, type=float, help='Spiking Neurons Threshold Value')
parser.add_argument('--vth_vu', default=0.0, type=float, help='Spiking Neurons Threshold Value')
parser.add_argument('--snn_fpi', default=64, type=int, help='Number of frames per input image')
parser.add_argument('--snn_TTS', default=128, type=int, help='Simulation timesteps per example')
parser.add_argument('--in_coding', default='rate', type=str, help='rate or temp')
parser.add_argument('--snn_mode', default='snn', type=str, help='snn or vthc')
parser.add_argument('--if_mode', default='if', type=str, help='if or residual')

def main():
    start_time = time.time()

    # Parse argument
    global args
    args = parser.parse_args()
   
    os.environ['CUDA_VISIBLE_DEVICES'] = args.gpu_id
    use_cuda = torch.cuda.is_available()

    if args.log is None:
        f = sys.stdout
    else:
        f = open(args.log, 'w', buffering=1)

    # Initialize seed and best accuracy
    torch.manual_seed(args.seed)
    torch.cuda.manual_seed_all(args.seed)
    best_prec1 = 0

    # Check the save_dir exists or not
    if (not args.save_dir is None) and (not os.path.exists(args.save_dir)):
        os.makedirs(args.save_dir)

    # Load model and parallelize on GPU
    import model_resnet20_cifar100
    model_rate = model_resnet20_cifar100.ResNetRate([args.dropout_prob_0,args.dropout_prob_1,args.dropout_prob_2,args.dropout_prob_3])
    model_rate = torch.nn.DataParallel(model_rate).cuda()
    f.write(str(model_rate)+'\n')

    # Define loss function (criterion) and optimizer
    criterion = nn.CrossEntropyLoss().cuda()
    optimizer = torch.optim.SGD(model_rate.parameters(), lr=args.learning_rate,
                                momentum=args.momentum,
                                weight_decay=args.weight_decay)

    # Optionally resume from checkpoint
    if args.resume:
        if os.path.isfile(args.resume):
            checkpoint = torch.load(args.resume)
            args.start_epoch = checkpoint['epoch']
            # best_prec1 = checkpoint['best_prec1']
            model_rate.load_state_dict(checkpoint['state_dict'])
            optimizer.load_state_dict(checkpoint['optimizer'])
            f.write("=> Load checkpoint from {} (start_epoch={})\n".format(args.resume, checkpoint['epoch']))
        else:
            f.write("=> No checkpoint found at {}\n".format(args.resume))
            sys.exit(0)

    # Set CUDNN to look for optimal running alogrithm 
    cudnn.benchmark = True

    # Normalization function
    class normalize(object):
        def __init__(self, mean, absmax):
            self.mean = mean
            self.absmax = absmax
        def __call__(self, tensor):
            # Args: tensor (Tensor): Tensor image of size (C, H, W) to be normalized.
            # Returns: Tensor: Normalized image.
            for t, m, am in zip(tensor, self.mean, self.absmax):
                t.sub_(m).div_(am)
            return tensor

    # Mean and SD are calculuated by get_dataset_stat.py
    train_transform = transforms.Compose([
        transforms.RandomHorizontalFlip(p=0.5),
        transforms.ToTensor(),
        normalize(mean=[0.4914, 0.4821, 0.4465],absmax=[0.5086, 0.5179, 0.5535])
        ])
    train_set = datasets.CIFAR100(root='./dataset/cifar100', train=True, download=True, transform=train_transform)
    train_loader = torch.utils.data.DataLoader(train_set, batch_size=args.batch_size, shuffle=True, num_workers=args.num_workers, pin_memory=True)
    test_transform = transforms.Compose([
        transforms.ToTensor(),
        normalize(mean=[0.4914, 0.4821, 0.4465],absmax=[0.5086, 0.5179, 0.5535])
        ])
    test_set = datasets.CIFAR100(root='./dataset/cifar100', train=False, transform=test_transform)
    test_loader = torch.utils.data.DataLoader(test_set, batch_size=args.batch_size, shuffle=False, num_workers=args.num_workers, pin_memory=True)

    if args.evaluate:
        best_prec1 = 0
        prec1 = validate_rate(test_loader, model_rate, criterion, f)
        is_best = prec1 > best_prec1
        best_prec1 = max(prec1, best_prec1)
    else:
        for epoch in range(args.start_epoch, args.max_epoch+1):
            adjust_learning_rate(optimizer, epoch)

            # Train for one epoch
            train_rate(train_loader, model_rate, criterion, optimizer, epoch, f)
            
            # Evaluate on validation set
            prec1 = validate_rate(test_loader, model_rate, criterion, f)

            # Save checkpoint
            is_best = prec1 > best_prec1
            best_prec1 = max(prec1, best_prec1)
            if (epoch % 100 == 0) and (not args.save_dir is None):
                save_checkpoint({
                    'epoch': epoch + 1,
                    'state_dict': model_rate.state_dict(),
                    'best_prec1': best_prec1,
                    'optimizer' : optimizer.state_dict(),            
                }, is_best, filename=os.path.join(args.save_dir, 'checkpoint_{}.tar'.format(epoch)))

        best_prec1 = 0
        prec1 = validate_rate(test_loader, model_rate, criterion, f)
        is_best = prec1 > best_prec1
        best_prec1 = max(prec1, best_prec1)

    f.write('Summary\t/\tTotal time {:.3f}\t/\tBest prec@1 {:.3f}\n'.format(time.time()-start_time, best_prec1))
   
    args.not_testing = False
    if args.not_testing:
        sys.exit(0)

    f.write("==> Testing Bing's ANN-SNN Conversion:\n")
    # Instantiate spike network
    
    import model_resnet20_cifar100_baseline
    model_rate_wprobe = model_resnet20_cifar100_baseline.ResNetRate([args.dropout_prob_0,args.dropout_prob_1,args.dropout_prob_2,args.dropout_prob_3])
    model_rate_wprobe = torch.nn.DataParallel(model_rate_wprobe).cuda()

    model_spike = model_resnet20_cifar100.ResNetSpike(dt=args.dt, t_end=args.t_end, in_coding=args.in_coding, snn_mode=args.snn_mode, if_mode=args.if_mode, TTS=args.snn_TTS, fpi=args.snn_fpi)
    model_spike = torch.nn.DataParallel(model_spike).cuda()
    f.write(str(model_spike)+'\n')
   
    # Run trained network through training dataset again to find maximum input to IFNeuron
    weight_mapping = [('module.features.0.weight', 'module.features.1.weight'), 
                      ('module.features.3.weight', 'module.features.4.weight'),
                      ('module.features.6.weight', 'module.features.7.weight'), 
                      ('module.features.9.delay_path.0.weight', 'module.features.11.weight'), 
                      ('module.features.9.delay_path.3.weight', 'module.features.14.weight'), 
                      ('module.features.10.delay_path.0.weight', 'module.features.20.weight'),
                      ('module.features.10.delay_path.3.weight', 'module.features.23.weight'), 
                      ('module.features.11.delay_path.0.weight', 'module.features.29.weight'),
                      ('module.features.11.delay_path.3.weight', 'module.features.32.weight'), 
                      ('module.features.12.delay_path.0.weight', 'module.features.38.weight'),
                      ('module.features.12.delay_path.3.weight', 'module.features.41.weight'), 
                      ('module.features.13.delay_path.0.weight', 'module.features.47.weight'),
                      ('module.features.13.delay_path.3.weight', 'module.features.50.weight'), 
                      ('module.features.14.delay_path.0.weight', 'module.features.56.weight'),
                      ('module.features.14.delay_path.3.weight', 'module.features.59.weight'), 
                      ('module.features.15.delay_path.0.weight', 'module.features.65.weight'),
                      ('module.features.15.delay_path.3.weight', 'module.features.68.weight'), 
                      ('module.features.16.delay_path.0.weight', 'module.features.74.weight'),
                      ('module.features.16.delay_path.3.weight', 'module.features.77.weight'), 
                      ('module.features.17.delay_path.0.weight', 'module.features.83.weight'),
                      ('module.features.17.delay_path.3.weight', 'module.features.86.weight'), 
                      ('module.classifier.0.weight', 'module.classifier.0.weight')]
    model_rate_dict = model_rate.state_dict() 
    model_spike_dict = model_spike.state_dict() 
    for source,target in weight_mapping:
        model_spike_dict[target].copy_(model_rate_dict[source])

    # Normalize threshold value
    # Following lines are generated automatically from model_vgg16_cifar10.py


    l1_hmax_outp =  torch.zeros(args.batch_size,1).cuda()
    l4_hmax_outp =  torch.zeros(args.batch_size,1).cuda()
    l7_hmax_outp =  torch.zeros(args.batch_size,1).cuda() 
    l11_hmax_outp = torch.zeros(args.batch_size,1).cuda()
    l14_hmax_outp = torch.zeros(args.batch_size,1).cuda()
    l20_hmax_outp = torch.zeros(args.batch_size,1).cuda()
    l23_hmax_outp = torch.zeros(args.batch_size,1).cuda()
    l29_hmax_outp = torch.zeros(args.batch_size,1).cuda()
    l32_hmax_outp = torch.zeros(args.batch_size,1).cuda()
    l38_hmax_outp = torch.zeros(args.batch_size,1).cuda()
    l41_hmax_outp = torch.zeros(args.batch_size,1).cuda()
    l47_hmax_outp = torch.zeros(args.batch_size,1).cuda()
    l50_hmax_outp = torch.zeros(args.batch_size,1).cuda()
    l56_hmax_outp = torch.zeros(args.batch_size,1).cuda()
    l59_hmax_outp = torch.zeros(args.batch_size,1).cuda()
    l65_hmax_outp = torch.zeros(args.batch_size,1).cuda()
    l68_hmax_outp = torch.zeros(args.batch_size,1).cuda()
    l74_hmax_outp = torch.zeros(args.batch_size,1).cuda()
    l77_hmax_outp = torch.zeros(args.batch_size,1).cuda()
    l83_hmax_outp = torch.zeros(args.batch_size,1).cuda()
    l86_hmax_outp = torch.zeros(args.batch_size,1).cuda()

    with torch.no_grad():
        for i, (inp, target) in enumerate(train_loader):
            if i == 500:  break

            inp = inp.cuda(non_blocking=True)
            target = target.cuda(non_blocking=True)
            outp,l1_max_outp,l4_max_outp,l7_max_outp,l11_max_outp,l14_max_outp,l20_max_outp,l23_max_outp,l29_max_outp,l32_max_outp,l38_max_outp,l41_max_outp,l47_max_outp,l50_max_outp,l56_max_outp,l59_max_outp,l65_max_outp,l68_max_outp,l74_max_outp,l77_max_outp,l83_max_outp,l86_max_outp = model_rate_wprobe(inp)
            # print(i, l1_hmax_outp.shape, l1_max_outp.shape)
            l1_hmax_outp = torch.max(l1_hmax_outp,l1_max_outp)
            l4_hmax_outp = torch.max(l4_hmax_outp,l4_max_outp)
            l7_hmax_outp = torch.max(l7_hmax_outp,l7_max_outp)

            l11_hmax_outp = torch.max(l11_hmax_outp,l11_max_outp)
            l14_hmax_outp = torch.max(l14_hmax_outp,l14_max_outp)
            l20_hmax_outp = torch.max(l20_hmax_outp,l20_max_outp)
            l23_hmax_outp = torch.max(l23_hmax_outp,l23_max_outp)
            l29_hmax_outp = torch.max(l29_hmax_outp,l29_max_outp)
            l32_hmax_outp = torch.max(l32_hmax_outp,l32_max_outp)
            l38_hmax_outp = torch.max(l38_hmax_outp,l38_max_outp)
            l41_hmax_outp = torch.max(l41_hmax_outp,l41_max_outp)
            l47_hmax_outp = torch.max(l47_hmax_outp,l47_max_outp)
            l50_hmax_outp = torch.max(l50_hmax_outp,l50_max_outp)
            l56_hmax_outp = torch.max(l56_hmax_outp,l56_max_outp)
            l59_hmax_outp = torch.max(l59_hmax_outp,l59_max_outp)
            l65_hmax_outp = torch.max(l65_hmax_outp,l65_max_outp)
            l68_hmax_outp = torch.max(l68_hmax_outp,l68_max_outp)
            l74_hmax_outp = torch.max(l74_hmax_outp,l74_max_outp)
            l77_hmax_outp = torch.max(l77_hmax_outp,l77_max_outp)
            l83_hmax_outp = torch.max(l83_hmax_outp,l83_max_outp)
            l86_hmax_outp = torch.max(l86_hmax_outp,l86_max_outp)            

    l1_hmax_outp = torch.max(l1_hmax_outp)
    l4_hmax_outp = torch.max(l4_hmax_outp)
    l7_hmax_outp = torch.max(l7_hmax_outp)

    l11_hmax_outp = torch.max(l11_hmax_outp)
    l14_hmax_outp = torch.max(l14_hmax_outp)
    l20_hmax_outp = torch.max(l20_hmax_outp)
    l23_hmax_outp = torch.max(l23_hmax_outp)
    l29_hmax_outp = torch.max(l29_hmax_outp)
    l32_hmax_outp = torch.max(l32_hmax_outp)
    l38_hmax_outp = torch.max(l38_hmax_outp)
    l41_hmax_outp = torch.max(l41_hmax_outp)
    l47_hmax_outp = torch.max(l47_hmax_outp)
    l50_hmax_outp = torch.max(l50_hmax_outp)
    l56_hmax_outp = torch.max(l56_hmax_outp)
    l59_hmax_outp = torch.max(l59_hmax_outp)
    l65_hmax_outp = torch.max(l65_hmax_outp)
    l68_hmax_outp = torch.max(l68_hmax_outp)
    l74_hmax_outp = torch.max(l74_hmax_outp)
    l77_hmax_outp = torch.max(l77_hmax_outp)
    l83_hmax_outp = torch.max(l83_hmax_outp)
    l86_hmax_outp = torch.max(l86_hmax_outp)

    V_b = args.vth_vb
    V_u = args.vth_vu    
    V_d = 1.0
    # vth_l2 = 11.211
    # vth_l5 = 4.991
    # vth_l8 = 5.632

    prev_factor = 1.0
    l1_maxw = torch.max(model_rate_wprobe.module.features[0].weight)
    # print('max l1_outp = ', l1_hmax_outp, ', l1_maxw = ', l1_maxw, ' , prev_factor = ', prev_factor)
    scale_factor = torch.max(l1_hmax_outp, l1_maxw)
    apply_factor = torch.div(scale_factor, prev_factor)*V_b + V_u
    # apply_factor = 11.211*V_b + V_u
    f.write('\tl2 threshold balancing {:.3f}\n'.format(apply_factor))
    model_spike.module.features[2].set_thres(float(apply_factor))
    prev_factor = scale_factor


    l4_maxw = torch.max(model_rate_wprobe.module.features[3].weight)
    # print('max l4_outp = ', l4_hmax_outp, ', l4_maxw = ', l4_maxw, ' , prev_factor = ', prev_factor)
    scale_factor = torch.max(l4_hmax_outp, l4_maxw)
    apply_factor = torch.div(scale_factor, prev_factor)*V_b + V_u
    # apply_factor = 4.991*V_b + V_u
    f.write('\tl5 threshold balancing {:.3f}\n'.format(apply_factor))
    model_spike.module.features[5].set_thres(float(apply_factor))
    prev_factor = scale_factor


    l7_maxw = torch.max(model_rate_wprobe.module.features[6].weight)
    # print('max l7_outp = ', l7_hmax_outp, ', l7_maxw = ', l7_maxw, ' , prev_factor = ', prev_factor)
    scale_factor = torch.max(l7_hmax_outp, l7_maxw)
    apply_factor = torch.div(scale_factor, prev_factor)*V_b + V_u
    # apply_factor = 5.632*V_b + V_u
    f.write('\tl8 threshold balancing {:.3f}\n'.format(apply_factor))
    model_spike.module.features[8].set_thres(float(apply_factor))
    prev_factor = scale_factor

    """
    prev_factor_I = 0.0686
    prev_factor_II = 1.266
    l11_maxw = torch.max(model_rate_wprobe.module.features[9].delay_path[0].weight)
    print('max l11_outp = ', l11_hmax_outp, ', l11_maxw = ', l11_maxw, ' , prev_factor_I = ', prev_factor_I)
    scale_factor_I = torch.max(l11_hmax_outp, l11_maxw)
    apply_factor = torch.div(scale_factor_I, prev_factor_I)*V_d + V_u
    f.write('\tl12 threshold balancing {:.3f}\n'.format(apply_factor))
    model_spike.module.features[12].set_thres(float(apply_factor))
    prev_factor_I = scale_factor_I

    l14_maxw = torch.max(model_rate_wprobe.module.features[9].delay_path[3].weight)
    print('max l14_outp = ', l14_hmax_outp, ', l14_maxw = ', l14_maxw, ' , prev_factor_II = ', prev_factor_II)
    scale_factor_II = torch.max(l14_hmax_outp, l14_maxw)
    apply_factor = torch.div(scale_factor_II, prev_factor_II)*V_d + V_u
    f.write('\tl18 threshold balancing {:.3f}\n'.format(apply_factor))
    model_spike.module.features[18].set_thres(float(apply_factor))
    prev_factor_II = scale_factor_II


    l20_maxw = torch.max(model_rate_wprobe.module.features[10].delay_path[0].weight)
    scale_factor_I = torch.max(l20_hmax_outp, l20_maxw)
    apply_factor = torch.div(scale_factor_I, prev_factor_I)*V_d + V_u
    f.write('\tl21 threshold balancing {:.3f}\n'.format(apply_factor))
    model_spike.module.features[21].set_thres(float(apply_factor))
    prev_factor_I = scale_factor_I

    l23_maxw = torch.max(model_rate_wprobe.module.features[10].delay_path[3].weight)
    scale_factor_II = torch.max(l23_hmax_outp, l23_maxw)
    apply_factor = torch.div(scale_factor_II, prev_factor_II)*V_d + V_u
    f.write('\tl27 threshold balancing {:.3f}\n'.format(apply_factor))
    model_spike.module.features[27].set_thres(float(apply_factor))
    prev_factor_II = scale_factor_II


    l29_maxw = torch.max(model_rate_wprobe.module.features[11].delay_path[0].weight)
    scale_factor_I = torch.max(l20_hmax_outp, l20_maxw)
    apply_factor = torch.div(scale_factor_I, prev_factor_I)*V_d + V_u
    f.write('\tl30 threshold balancing {:.3f}\n'.format(apply_factor))
    model_spike.module.features[30].set_thres(float(apply_factor))
    prev_factor_I = scale_factor_I

    l32_maxw = torch.max(model_rate_wprobe.module.features[11].delay_path[3].weight)
    scale_factor_II = torch.max(l32_hmax_outp, l32_maxw)
    apply_factor = torch.div(scale_factor_II, prev_factor_II)*V_d + V_u
    f.write('\tl36 threshold balancing {:.3f}\n'.format(apply_factor))
    model_spike.module.features[36].set_thres(float(apply_factor))
    prev_factor_II = scale_factor_II


    l38_maxw = torch.max(model_rate_wprobe.module.features[12].delay_path[0].weight)
    scale_factor_I = torch.max(l38_hmax_outp, l38_maxw)
    apply_factor = torch.div(scale_factor_I, prev_factor_I)*V_d + V_u
    f.write('\tl39 threshold balancing {:.3f}\n'.format(apply_factor))
    model_spike.module.features[39].set_thres(float(apply_factor))
    prev_factor_I = scale_factor_I

    l41_maxw = torch.max(model_rate_wprobe.module.features[12].delay_path[3].weight)
    scale_factor_II = torch.max(l41_hmax_outp, l41_maxw)
    apply_factor = torch.div(scale_factor_II, prev_factor_II)*V_d + V_u
    f.write('\tl45 threshold balancing {:.3f}\n'.format(apply_factor))
    model_spike.module.features[45].set_thres(float(apply_factor))
    prev_factor_II = scale_factor_II


    l47_maxw = torch.max(model_rate_wprobe.module.features[13].delay_path[0].weight)
    scale_factor_I = torch.max(l47_hmax_outp, l47_maxw)
    apply_factor = torch.div(scale_factor_I, prev_factor_I)*V_d + V_u
    f.write('\tl48 threshold balancing {:.3f}\n'.format(apply_factor))
    model_spike.module.features[48].set_thres(float(apply_factor))
    prev_factor_I = scale_factor_I

    l50_maxw = torch.max(model_rate_wprobe.module.features[13].delay_path[3].weight)
    scale_factor_II = torch.max(l50_hmax_outp, l50_maxw)
    apply_factor = torch.div(scale_factor_II, prev_factor_II)*V_d + V_u
    f.write('\tl54 threshold balancing {:.3f}\n'.format(apply_factor))
    model_spike.module.features[54].set_thres(float(apply_factor))
    prev_factor_II = scale_factor_II


    l56_maxw = torch.max(model_rate_wprobe.module.features[14].delay_path[0].weight)
    scale_factor_I = torch.max(l56_hmax_outp, l56_maxw)
    apply_factor = torch.div(scale_factor_I, prev_factor_I)*V_d + V_u
    f.write('\tl57 threshold balancing {:.3f}\n'.format(apply_factor))
    model_spike.module.features[57].set_thres(float(apply_factor))
    prev_factor_I = scale_factor_I

    l59_maxw = torch.max(model_rate_wprobe.module.features[14].delay_path[3].weight)
    scale_factor_II = torch.max(l59_hmax_outp, l59_maxw)
    apply_factor = torch.div(scale_factor_II, prev_factor_II)*V_d + V_u
    f.write('\tl63 threshold balancing {:.3f}\n'.format(apply_factor))
    model_spike.module.features[63].set_thres(float(apply_factor))
    prev_factor_II = scale_factor_II


    l65_maxw = torch.max(model_rate_wprobe.module.features[15].delay_path[0].weight)
    scale_factor_I = torch.max(l65_hmax_outp, l65_maxw)
    apply_factor = torch.div(scale_factor_I, prev_factor_I)*V_d + V_u
    f.write('\tl66 threshold balancing {:.3f}\n'.format(apply_factor))
    model_spike.module.features[66].set_thres(float(apply_factor))
    prev_factor_I = scale_factor_I

    l68_maxw = torch.max(model_rate_wprobe.module.features[15].delay_path[3].weight)
    scale_factor_II = torch.max(l68_hmax_outp, l68_maxw)
    apply_factor = torch.div(scale_factor_II, prev_factor_II)*V_d + V_u
    f.write('\tl72 threshold balancing {:.3f}\n'.format(apply_factor))
    model_spike.module.features[72].set_thres(float(apply_factor))
    prev_factor_II = scale_factor_II


    l74_maxw = torch.max(model_rate_wprobe.module.features[16].delay_path[0].weight)
    scale_factor_I = torch.max(l74_hmax_outp, l74_maxw)
    apply_factor = torch.div(scale_factor_I, prev_factor_I)*V_d + V_u
    f.write('\tl75 threshold balancing {:.3f}\n'.format(apply_factor))
    model_spike.module.features[75].set_thres(float(apply_factor))
    prev_factor_I = scale_factor_I

    l77_maxw = torch.max(model_rate_wprobe.module.features[16].delay_path[3].weight)
    scale_factor_II = torch.max(l77_hmax_outp, l77_maxw)
    apply_factor = torch.div(scale_factor_II, prev_factor_II)*V_d + V_u
    f.write('\tl81 threshold balancing {:.3f}\n'.format(apply_factor))
    model_spike.module.features[81].set_thres(float(apply_factor))
    prev_factor_II = scale_factor_II


    l83_maxw = torch.max(model_rate_wprobe.module.features[17].delay_path[0].weight)
    scale_factor_I = torch.max(l83_hmax_outp, l83_maxw)
    apply_factor = torch.div(scale_factor_I, prev_factor_I)*V_d + V_u
    f.write('\tl84 threshold balancing {:.3f}\n'.format(apply_factor))
    model_spike.module.features[84].set_thres(float(apply_factor))
    prev_factor_I = scale_factor_I

    l86_maxw = torch.max(model_rate_wprobe.module.features[17].delay_path[3].weight)
    scale_factor_II = torch.max(l86_hmax_outp, l86_maxw)
    apply_factor = torch.div(scale_factor_II, prev_factor_II)*V_d + V_u
    f.write('\tl90 threshold balancing {:.3f}\n'.format(apply_factor))
    model_spike.module.features[90].set_thres(float(apply_factor))
    prev_factor_II = scale_factor_II    
    """

    # Evaluate on validation set
    validate_spike(test_loader, model_spike, criterion, f)

    if not args.log is None:
        f.close()

def train_rate(train_loader, model, criterion, optimizer, epoch, f):
    """
        Run one train epoch
    """
    # switch to train mode
    model.train()

    start_time = time.time()
    acc_top1 = []
    acc_top5 = []
    acc_loss = []

    for i, (inp, target) in enumerate(train_loader):
        target = target.cuda(non_blocking=True)

        # compute outp
        outp = model(inp)
        loss = criterion(outp, target)

        # measure accuracy and record loss
        prec1, prec5 = accuracy(outp, target, topk=(1, 5))
        acc_top1.append(float(prec1))
        acc_top5.append(float(prec5))
        acc_loss.append(float(loss))

        # compute gradient and do SGD step
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

    f.write('Epoch {:>3}\t/\tTrain:\tTime {:.3f}\tPrec@1 {:.3f}\tPrec@5 {:.3f}\tLoss {:.3f}\t'.format(epoch,time.time()-start_time, np.mean(acc_top1), np.mean(acc_top5), np.mean(acc_loss)))

def validate_spike(test_loader, model, criterion, f):
    """
    Run evaluation
    """
    # switch to evaluate mode
    model.eval()
    
    start_time = time.time()
    acc_top1 = []
    acc_top5 = []

    l2_neuron_count = 128*32*32
    l5_neuron_count = 128*32*32
    l8_neuron_count = 128*32*32
    l12_neuron_count = 128*32*32
    l18_neuron_count = 128*32*32
    l21_neuron_count = 128*32*32
    l27_neuron_count = 128*32*32
    l30_neuron_count = 128*32*32
    l36_neuron_count = 128*32*32
    l39_neuron_count = 256*16*16
    l45_neuron_count = 256*16*16
    l48_neuron_count = 256*16*16
    l54_neuron_count = 256*16*16
    l57_neuron_count = 256*16*16
    l63_neuron_count = 256*16*16
    l66_neuron_count = 512*8*8
    l72_neuron_count = 512*8*8
    l75_neuron_count = 512*8*8
    l81_neuron_count = 512*8*8
    l84_neuron_count = 512*8*8
    l90_neuron_count = 512*8*8
    spike_total = torch.zeros(100,1).cuda()

    with torch.no_grad():
        for i, (inp, target) in enumerate(tqdm(test_loader)):
            target = target.cuda(non_blocking=True)
            outp,l2_max_inp,l5_max_inp,l8_max_inp,spike_count = model(inp)
            loss = criterion(outp, target)
            # measure accuracy and record loss
            prec1, prec5 = accuracy(outp, target, topk=(1, 5))
            acc_top1.append(float(prec1))
            acc_top5.append(float(prec5))

            spike_total[2] += spike_count[2]
            spike_total[5] += spike_count[5]
            spike_total[8] += spike_count[8]
            spike_total[12] += spike_count[12]
            spike_total[18] += spike_count[18]
            spike_total[21] += spike_count[21]
            spike_total[27] += spike_count[27]
            spike_total[30] += spike_count[30]
            spike_total[36] += spike_count[36]
            spike_total[39] += spike_count[39]
            spike_total[45] += spike_count[45]
            spike_total[48] += spike_count[48]
            spike_total[54] += spike_count[54]
            spike_total[57] += spike_count[57]
            spike_total[63] += spike_count[63]
            spike_total[66] += spike_count[66]
            spike_total[72] += spike_count[72]
            spike_total[75] += spike_count[75]
            spike_total[81] += spike_count[81]
            spike_total[84] += spike_count[84]
            spike_total[90] += spike_count[90]
            
            if (i!=0) and (i%2==0):         
                f.write('\tTest {:>5} :\tTime {:.3f}\tPrec@1 {:.3f}\tPrec@5 {:.3f}\n'.format(i, time.time()-start_time, np.mean(acc_top1), np.mean(acc_top5)))
        f.write('\tTest {:>5} :\tTime {:.3f}\tPrec@1 {:.3f}\tPrec@5 {:.3f}\n'.format(i, time.time()-start_time, np.mean(acc_top1), np.mean(acc_top5)))
	print('Layer  2  Total spikes/image: ',  spike_total[2]/10000, 'Total neurons: ',  l2_neuron_count)
        print('Layer  5  Total spikes/image: ',  spike_total[5]/10000, 'Total Neurons: ',  l5_neuron_count)
        print('Layer  8  Total spikes/image: ',  spike_total[8]/10000, 'Total Neurons: ',  l8_neuron_count)
        print('Layer 12  Total spikes/image: ', spike_total[12]/10000, 'Total Neurons: ', l12_neuron_count)
        print('Layer 18  Total spikes/image: ', spike_total[18]/10000, 'Total Neurons: ', l18_neuron_count)
        print('Layer 21  Total spikes/image: ', spike_total[21]/10000, 'Total Neurons: ', l21_neuron_count)
        print('Layer 27  Total spikes/image: ', spike_total[27]/10000, 'Total Neurons: ', l27_neuron_count)
        print('Layer 30  Total spikes/image: ', spike_total[30]/10000, 'Total Neurons: ', l30_neuron_count)
        print('Layer 36  Total spikes/image: ', spike_total[36]/10000, 'Total Neurons: ', l36_neuron_count)
        print('Layer 39  Total spikes/image: ', spike_total[39]/10000, 'Total Neurons: ', l39_neuron_count)
        print('Layer 45  Total spikes/image: ', spike_total[45]/10000, 'Total Neurons: ', l45_neuron_count)
        print('Layer 48  Total spikes/image: ', spike_total[48]/10000, 'Total Neurons: ', l48_neuron_count)
        print('Layer 54  Total spikes/image: ', spike_total[54]/10000, 'Total Neurons: ', l54_neuron_count)
        print('Layer 57  Total spikes/image: ', spike_total[57]/10000, 'Total Neurons: ', l57_neuron_count)
        print('Layer 63  Total spikes/image: ', spike_total[63]/10000, 'Total Neurons: ', l63_neuron_count)
        print('Layer 66  Total spikes/image: ', spike_total[66]/10000, 'Total Neurons: ', l66_neuron_count)
        print('Layer 72  Total spikes/image: ', spike_total[72]/10000, 'Total Neurons: ', l72_neuron_count)
        print('Layer 75  Total spikes/image: ', spike_total[75]/10000, 'Total Neurons: ', l75_neuron_count)
        print('Layer 81  Total spikes/image: ', spike_total[81]/10000, 'Total Neurons: ', l81_neuron_count)
        print('Layer 84  Total spikes/image: ', spike_total[84]/10000, 'Total Neurons: ', l84_neuron_count)
        print('Layer 90  Total spikes/image: ', spike_total[90]/10000, 'Total Neurons: ', l90_neuron_count)

    return np.mean(acc_top1)

def validate_rate(test_loader, model, criterion, f):
    """
    Run evaluation
    """
    # switch to evaluate mode
    model.eval()
    
    start_time = time.time()
    acc_top1 = []
    acc_top5 = []

    with torch.no_grad():

        for i, (inp, target) in enumerate(test_loader):
            target = target.cuda(non_blocking=True)

            # compute outp
            outp = model(inp)
            loss = criterion(outp, target)

            # measure accuracy and record loss
            prec1, prec5 = accuracy(outp, target, topk=(1, 5))
            acc_top1.append(float(prec1))
            acc_top5.append(float(prec5))

    f.write('/\tTest:\tTime {:.3f}\tPrec@1 {:.3f}\tPrec@5 {:.3f}\n'.format(time.time()-start_time, np.mean(acc_top1), np.mean(acc_top5)))

    return np.mean(acc_top1)

def save_checkpoint(state, is_best, filename='checkpoint.tar'):
    """
    Save the training model
    """
    torch.save(state, filename)

def adjust_learning_rate(optimizer, cur_epoch):
    # Reduce learning rate by 10 twice at epoch 81 and 122
    if cur_epoch == 100 or cur_epoch == 200 or cur_epoch == 300 or cur_epoch == 400:
        for param_group in optimizer.param_groups:
            param_group['lr'] /= 10


def accuracy(outp, target, topk=(1,)):
    """Computes the precision@k for the specified values of k"""
    with torch.no_grad():
        maxk = max(topk)
        batch_size = target.size(0)

        _, pred = outp.topk(maxk, 1, True, True)
        pred = pred.t()
        correct = pred.eq(target.view(1, -1).expand_as(pred))

        res = []
        for k in topk:
            correct_k = correct[:k].view(-1).float().sum(0, keepdim=True)
            res.append(correct_k.mul_(100.0 / batch_size))
        return res

if __name__ == '__main__':
    main()
