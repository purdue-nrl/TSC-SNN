import argparse
import os
import time
import sys

import numpy as np

import torch
import torch.nn as nn
import torch.nn.parallel
import torch.backends.cudnn as cudnn
import torch.optim
from torchvision import datasets, transforms
from tqdm import tqdm

parser = argparse.ArgumentParser(description='Comparison of ANN-SNN Conversion Techniques - ResNet20 with CIFAR-10', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
parser.add_argument('--start_epoch', default=1, type=int, help='starting epoch number (this value is set automatically if resume)')
parser.add_argument('--max_epoch', default=600, type=int, help='number of total epochs to run')
parser.add_argument('--batch_size', default=2500, type=int, help='batch size')
parser.add_argument('--learning_rate', default=0.05, type=float, help='initial learning rate')
parser.add_argument('--momentum', default=0.9, type=float, help='momentum')
parser.add_argument('--num_workers', default=16, type=int, help='number of workers')
parser.add_argument('--weight_decay', default=1e-4, type=float, help='weight decay')
parser.add_argument('--resume', default='', type=str, help='path to latest checkpoint')
parser.add_argument('--evaluate', dest='evaluate', action='store_true', help='evaluate model on validation set')
parser.add_argument('--seed', default=10, type=int, help='random seed')
parser.add_argument('--log', default=None, help='log file location')
parser.add_argument('--save_dir', default=None, help='saved directory location')
parser.add_argument('--dt', default=0.001, type=float, help='simulation timestep')
parser.add_argument('--t_end', default=2.500, type=float, help='single example simulation time')
parser.add_argument('--dropout_prob_0', default=0.0, type=float, help='dropout probability of 1st feature')
parser.add_argument('--dropout_prob_1', default=0.0, type=float, help='dropout probability of 2nd feature')
parser.add_argument('--dropout_prob_2', default=0.0, type=float, help='dropout probability of 3rd feature')
parser.add_argument('--dropout_prob_3', default=0.0, type=float, help='dropout probability of other features')
parser.add_argument('--testing', dest='not_testing', action='store_false', help='skip conversion testing if specified')

parser.add_argument('--gpu_id', default='0,1,2,3', type=str, help='id(s) for CUDA_VISIBLE_DEVICES')
parser.add_argument('--vth_vb', default=0.73, type=float, help='Spiking Neurons Threshold Value')
parser.add_argument('--vth_vu', default=0.0, type=float, help='Spiking Neurons Threshold Value')
parser.add_argument('--snn_fpi', default=128, type=int, help='Number of frames per input image')
parser.add_argument('--snn_TTS', default=256, type=int, help='Simulation timesteps per example')
parser.add_argument('--in_coding', default='rate', type=str, help='rate or temp')
parser.add_argument('--snn_mode', default='full', type=str, help='full or acc')
parser.add_argument('--if_mode', default='if', type=str, help='if or residual')

def main():
    start_time = time.time()
    
    # Parse argument
    global args
    args = parser.parse_args()
   
    os.environ['CUDA_VISIBLE_DEVICES'] = args.gpu_id
    use_cuda = torch.cuda.is_available()

    if args.log is None:
        f = sys.stdout
    else:
        f = open(args.log, 'w', buffering=1)

    # Initialize seed and best accuracy
    torch.manual_seed(args.seed)
    torch.cuda.manual_seed_all(args.seed)
    best_prec1 = 0

    # Check the save_dir exists or not
    if (not args.save_dir is None) and (not os.path.exists(args.save_dir)):
        os.makedirs(args.save_dir)

    # Load model and parallelize on GPU
    import model_resnet20_cifar10
    model_rate = model_resnet20_cifar10.ResNetRate([args.dropout_prob_0,args.dropout_prob_1,args.dropout_prob_2,args.dropout_prob_3])
    model_rate = torch.nn.DataParallel(model_rate).cuda()
    f.write(str(model_rate)+'\n')

    # Define loss function (criterion) and optimizer
    criterion = nn.CrossEntropyLoss().cuda()
    optimizer = torch.optim.SGD(model_rate.parameters(), lr=args.learning_rate,
                                momentum=args.momentum,
                                weight_decay=args.weight_decay)

    # Optionally resume from checkpoint
    if args.resume:
        if os.path.isfile(args.resume):
            checkpoint = torch.load(args.resume)
            args.start_epoch = checkpoint['epoch']
            # best_prec1 = checkpoint['best_prec1']
            model_rate.load_state_dict(checkpoint['state_dict'])
            optimizer.load_state_dict(checkpoint['optimizer'])
            f.write("=> Load checkpoint from {} (start_epoch={})\n".format(args.resume, checkpoint['epoch']))
        else:
            f.write("=> No checkpoint found at {}\n".format(args.resume))
            sys.exit(0)

    # Set CUDNN to look for optimal running alogrithm 
    cudnn.benchmark = True

    # Normalization function
    class normalize(object):
        def __init__(self, mean, absmax):
            self.mean = mean
            self.absmax = absmax
        def __call__(self, tensor):
            # Args: tensor (Tensor): Tensor image of size (C, H, W) to be normalized.
            # Returns: Tensor: Normalized image.
            for t, m, am in zip(tensor, self.mean, self.absmax):
                t.sub_(m).div_(am)
            return tensor

    # Mean and SD are calculuated by get_dataset_stat.py
    train_transform = transforms.Compose([
        transforms.RandomHorizontalFlip(p=0.5),
        transforms.ToTensor(),
        normalize(mean=[0.4914, 0.4821, 0.4465],absmax=[0.5086, 0.5179, 0.5535])
        ])
    train_set = datasets.CIFAR10(root='./dataset/cifar10', train=True, download=True, transform=train_transform)
    train_loader = torch.utils.data.DataLoader(train_set, batch_size=args.batch_size, shuffle=True, num_workers=args.num_workers, pin_memory=True)
    test_transform = transforms.Compose([
        transforms.ToTensor(),
        normalize(mean=[0.4914, 0.4821, 0.4465],absmax=[0.5086, 0.5179, 0.5535])
        ])
    test_set = datasets.CIFAR10(root='./dataset/cifar10', train=False, transform=test_transform)
    test_loader = torch.utils.data.DataLoader(test_set, batch_size=args.batch_size, shuffle=False, num_workers=args.num_workers, pin_memory=True)

    if args.evaluate:
        best_prec1 = 0
        prec1 = validate_rate(test_loader, model_rate, criterion, f)
        is_best = prec1 > best_prec1
        best_prec1 = max(prec1, best_prec1)
    else:
        for epoch in range(args.start_epoch, args.max_epoch+1):
            adjust_learning_rate(optimizer, epoch)

            # Train for one epoch
            train_rate(train_loader, model_rate, criterion, optimizer, epoch, f)
            
            # Evaluate on validation set
            prec1 = validate_rate(test_loader, model_rate, criterion, f)

            # Save checkpoint
            is_best = prec1 > best_prec1
            best_prec1 = max(prec1, best_prec1)
            if (epoch % 100 == 0) and (not args.save_dir is None):
                save_checkpoint({
                    'epoch': epoch + 1,
                    'state_dict': model_rate.state_dict(),
                    'best_prec1': best_prec1,
                    'optimizer' : optimizer.state_dict(),            
                }, is_best, filename=os.path.join(args.save_dir, 'checkpoint_{}.tar'.format(epoch)))

        best_prec1 = 0
        prec1 = validate_rate(test_loader, model_rate, criterion, f)
        is_best = prec1 > best_prec1
        best_prec1 = max(prec1, best_prec1)

    f.write('Summary\t/\tTotal time {:.3f}\t/\tBest prec@1 {:.3f}\n'.format(time.time()-start_time, best_prec1))
   
    args.not_testing = False
    if args.not_testing:
        sys.exit(0)

    f.write("==> Testing Bing's ANN-SNN Conversion:\n")
    # Instantiate spike network
    model_spike_probe = model_resnet20_cifar10.ResNetSpike(dt=args.dt, t_end=args.t_end, in_coding='rate', snn_mode='full', if_mode='if', TTS=args.snn_TTS, fpi=args.snn_TTS)
    model_spike_probe = torch.nn.DataParallel(model_spike_probe).cuda()
    f.write(str(model_spike_probe)+'\n')
   
    # Run trained network through training dataset again to find maximum input to IFNeuron
    weight_mapping = [('module.features.0.weight', 'module.features.1.weight'), 
                      ('module.features.3.weight', 'module.features.4.weight'),
                      ('module.features.6.weight', 'module.features.7.weight'), 
                      ('module.features.9.delay_path.0.weight', 'module.features.11.weight'), 
                      ('module.features.9.delay_path.3.weight', 'module.features.14.weight'), 
                      ('module.features.10.delay_path.0.weight', 'module.features.20.weight'),
                      ('module.features.10.delay_path.3.weight', 'module.features.23.weight'), 
                      ('module.features.11.delay_path.0.weight', 'module.features.29.weight'),
                      ('module.features.11.delay_path.3.weight', 'module.features.32.weight'), 
                      ('module.features.12.delay_path.0.weight', 'module.features.38.weight'),
                      ('module.features.12.delay_path.3.weight', 'module.features.41.weight'), 
                      ('module.features.13.delay_path.0.weight', 'module.features.47.weight'),
                      ('module.features.13.delay_path.3.weight', 'module.features.50.weight'), 
                      ('module.features.14.delay_path.0.weight', 'module.features.56.weight'),
                      ('module.features.14.delay_path.3.weight', 'module.features.59.weight'), 
                      ('module.features.15.delay_path.0.weight', 'module.features.65.weight'),
                      ('module.features.15.delay_path.3.weight', 'module.features.68.weight'), 
                      ('module.features.16.delay_path.0.weight', 'module.features.74.weight'),
                      ('module.features.16.delay_path.3.weight', 'module.features.77.weight'), 
                      ('module.features.17.delay_path.0.weight', 'module.features.83.weight'),
                      ('module.features.17.delay_path.3.weight', 'module.features.86.weight'), 
                      ('module.classifier.0.weight', 'module.classifier.0.weight')]
    model_rate_dict = model_rate.state_dict() 
    model_spike_probe_dict = model_spike_probe.state_dict() 
    for source,target in weight_mapping:
        model_spike_probe_dict[target].copy_(model_rate_dict[source])

    # Normalize threshold value
    # Following lines are generated automatically from model_vgg16_cifar10.py

    V_b = args.vth_vb
    V_u = args.vth_vu    
  
    """ 
    start_time = time.time()
    model_spike_probe.eval()
    with torch.no_grad():
        l2_max_inp_ = torch.zeros(1).cuda()
        l5_max_inp_ = torch.zeros(1).cuda()
        l8_max_inp_ = torch.zeros(1).cuda()
        for i, (inp, target) in enumerate(train_loader):
            if i == 4:  break
            outp,l2_max_inp,l5_max_inp,l8_max_inp,spike_count = model_spike_probe(inp)
            l2_max_inp_ = torch.max(l2_max_inp_,torch.max(l2_max_inp))
        model_spike_probe.module.features[2].set_thres(float(l2_max_inp_))
        f.write('\tl2 threshold balancing {:.3f}\ttime {:.3f}\n'.format(float(l2_max_inp_),time.time()-start_time)); start_time = time.time()
        for i, (inp, target) in enumerate(train_loader):
            if i == 4:  break
            outp,l2_max_inp,l5_max_inp,l8_max_inp,spike_count = model_spike_probe(inp)
            l5_max_inp_ = torch.max(l5_max_inp_,torch.max(l5_max_inp))
        model_spike_probe.module.features[5].set_thres(float(l5_max_inp_))
        f.write('\tl5 threshold balancing {:.3f}\ttime {:.3f}\n'.format(float(l5_max_inp_),time.time()-start_time)); start_time = time.time()
        for i, (inp, target) in enumerate(train_loader):
            if i == 4:  break
            outp,l2_max_inp,l5_max_inp,l8_max_inp,spike_count = model_spike_probe(inp)
            l8_max_inp_ = torch.max(l8_max_inp_,torch.max(l8_max_inp))
        model_spike_probe.module.features[8].set_thres(float(l8_max_inp_))
        f.write('\tl8 threshold balancing {:.3f}\ttime {:.3f}\n'.format(float(l8_max_inp_),time.time()-start_time)); start_time = time.time()
    """

    model_spike = model_resnet20_cifar10.ResNetSpike(dt=args.dt, t_end=args.t_end, in_coding=args.in_coding, snn_mode=args.snn_mode, if_mode=args.if_mode, TTS=args.snn_TTS, fpi=args.snn_fpi)
    model_spike = torch.nn.DataParallel(model_spike).cuda()
    model_rate_dict = model_rate.state_dict()
    model_spike_dict = model_spike.state_dict()
    for source,target in weight_mapping:
        model_spike_dict[target].copy_(model_rate_dict[source])


    print('Use pre-computed thresholds for SNN')
    if args.snn_TTS == 8:
        l2_max_inp_ = 9.497
        l5_max_inp_ = 4.184
        l8_max_inp_ = 3.041
    elif args.snn_TTS == 16:
        l2_max_inp_ = 9.86
        l5_max_inp_ = 4.41
        l8_max_inp_ = 3.11
    elif args.snn_TTS == 32:
        l2_max_inp_ = 10.111
        l5_max_inp_ = 4.657
        l8_max_inp_ = 3.335
    elif args.snn_TTS == 64:
        l2_max_inp_ = 9.743
        l5_max_inp_ = 4.618
        l8_max_inp_ = 3.643
    elif args.snn_TTS == 128:
        l2_max_inp_ = 10.09
        l5_max_inp_ = 4.567
        l8_max_inp_ = 3.573
    elif args.snn_TTS == 256:
        l2_max_inp_ = 10.199
        l5_max_inp_ = 5.031
        l8_max_inp_ = 5.02
    elif args.snn_TTS == 512:
        l2_max_inp_ = 10.503
        l5_max_inp_ = 5.032
        l8_max_inp_ = 4.49
    elif args.snn_TTS == 768:
        l2_max_inp_ = 11.101
        l5_max_inp_ = 4.698
        l8_max_inp_ = 5.43
    elif args.snn_TTS == 1024:
        l2_max_inp_ = 10.46
        l5_max_inp_ = 5.127
        l8_max_inp_ = 5.198
    elif args.snn_TTS == 1536:
        l2_max_inp_ = 10.617
        l5_max_inp_ = 4.878
        l8_max_inp_ = 4.995
    elif args.snn_TTS == 2048:
        l2_max_inp_ = 11.048
        l5_max_inp_ = 4.88
        l8_max_inp_ = 5.124

    f.write('\tl2 threshold balancing {:.3f} \n '.format(float(l2_max_inp_)))
    f.write('\tl5 threshold balancing {:.3f} \n '.format(float(l5_max_inp_)))
    f.write('\tl8 threshold balancing {:.3f} \n '.format(float(l8_max_inp_)))


    model_spike.module.features[2].set_thres(float(l2_max_inp_*V_b+V_u))
    model_spike.module.features[5].set_thres(float(l5_max_inp_*V_b+V_u))
    model_spike.module.features[8].set_thres(float(l8_max_inp_*V_b+V_u))

    # Setting thresholds according to Abhronil's conversion 2500 Timesteps simulation
    model_spike.module.features[12].set_thres(1.0)
    model_spike.module.features[18].set_thres(1.0)

    model_spike.module.features[21].set_thres(1.0)
    model_spike.module.features[27].set_thres(1.0)

    model_spike.module.features[30].set_thres(1.0)
    model_spike.module.features[36].set_thres(1.0)

    model_spike.module.features[39].set_thres(1.0)
    model_spike.module.features[45].set_thres(1.0)

    model_spike.module.features[48].set_thres(1.0)
    model_spike.module.features[54].set_thres(1.0)

    model_spike.module.features[57].set_thres(1.0)
    model_spike.module.features[63].set_thres(1.0)

    model_spike.module.features[66].set_thres(1.0)
    model_spike.module.features[72].set_thres(1.0)
    
    model_spike.module.features[75].set_thres(1.0)
    model_spike.module.features[81].set_thres(1.0)

    model_spike.module.features[84].set_thres(1.0)
    model_spike.module.features[90].set_thres(1.0)

    # Evaluate on validation set
    validate_spike(test_loader, model_spike, criterion, f)

    if not args.log is None:
        f.close()

def train_rate(train_loader, model, criterion, optimizer, epoch, f):
    """
        Run one train epoch
    """
    # switch to train mode
    model.train()

    start_time = time.time()
    acc_top1 = []
    acc_top5 = []
    acc_loss = []

    for i, (inp, target) in enumerate(train_loader):
        target = target.cuda(non_blocking=True)

        # compute outp
        outp = model(inp)
        loss = criterion(outp, target)

        # measure accuracy and record loss
        prec1, prec5 = accuracy(outp, target, topk=(1, 5))
        acc_top1.append(float(prec1))
        acc_top5.append(float(prec5))
        acc_loss.append(float(loss))

        # compute gradient and do SGD step
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

    f.write('Epoch {:>3}\t/\tTrain:\tTime {:.3f}\tPrec@1 {:.3f}\tPrec@5 {:.3f}\tLoss {:.3f}\t'.format(epoch,time.time()-start_time, np.mean(acc_top1), np.mean(acc_top5), np.mean(acc_loss)))

def validate_spike(test_loader, model, criterion, f):
    """
    Run evaluation
    """
    # switch to evaluate mode
    model.eval()
    
    start_time = time.time()
    acc_top1 = []
    acc_top5 = []
    spike_count = []

    inp_neuron_count = 32*32*3
    l2_neuron_count = 32*32*32
    l5_neuron_count = 32*32*32
    l8_neuron_count = 32*32*32
    l12_neuron_count = 32*32*32
    l18_neuron_count = 32*32*32
    l21_neuron_count = 32*32*32
    l27_neuron_count = 32*32*32
    l30_neuron_count = 32*32*32
    l36_neuron_count = 32*32*32
    l39_neuron_count = 64*16*16
    l45_neuron_count = 64*16*16
    l48_neuron_count = 64*16*16
    l54_neuron_count = 64*16*16
    l57_neuron_count = 64*16*16
    l63_neuron_count = 64*16*16
    l66_neuron_count = 128*8*8
    l72_neuron_count = 128*8*8
    l75_neuron_count = 128*8*8
    l81_neuron_count = 128*8*8
    l84_neuron_count = 128*8*8
    l90_neuron_count = 128*8*8
    spike_total = torch.zeros(1,200).cuda()

    with torch.no_grad():
        for i, (inp, target) in enumerate(tqdm(test_loader)):
            target = target.cuda(non_blocking=True)
            outp,l2_max_inp,l5_max_inp,l8_max_inp,spike_count = model(inp)
            loss = criterion(outp, target)
            # measure accuracy and record loss
            prec1, prec5 = accuracy(outp, target, topk=(1, 5))
            acc_top1.append(float(prec1))
            acc_top5.append(float(prec5))
            spike_total += torch.sum(spike_count, dim=0) 
            if (i!=0) and (i%1==0):         
                f.write('\tTest {:>5} :\tTime {:.3f}\tPrec@1 {:.3f}\tPrec@5 {:.3f}\n'.format(i, time.time()-start_time, np.mean(acc_top1), np.mean(acc_top5)))
        
        f.write('\t*****************************************************************************\n')
        f.write('\tSummary:\tTotal Time {:.3f}\tPrec@1 {:.3f}\tPrec@5 {:.3f}\n'.format(time.time()-start_time, np.mean(acc_top1), np.mean(acc_top5)))

        f.write('\t*****************************************************************************\n')
        f.write('\tFull-Frame Temporal RMP-SNN spike activities:\n')
        f.write('\tLayer IN  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format( spike_total[0,1]/10000., inp_neuron_count))
        f.write('\tLayer  2  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format( spike_total[0,2]/10000., l2_neuron_count))
        f.write('\tLayer  5  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format( spike_total[0,5]/10000., l5_neuron_count))
        f.write('\tLayer  8  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format( spike_total[0,8]/10000., l8_neuron_count))
        f.write('\tLayer 12  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,12]/10000., l12_neuron_count))
        f.write('\tLayer 18  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,18]/10000., l18_neuron_count))
        f.write('\tLayer 21  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,21]/10000., l21_neuron_count))
        f.write('\tLayer 27  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,27]/10000., l27_neuron_count))
        f.write('\tLayer 30  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,30]/10000., l30_neuron_count))
        f.write('\tLayer 36  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,36]/10000., l36_neuron_count))
        f.write('\tLayer 39  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,39]/10000., l39_neuron_count))
        f.write('\tLayer 45  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,45]/10000., l45_neuron_count))
        f.write('\tLayer 48  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,48]/10000., l48_neuron_count))
        f.write('\tLayer 54  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,54]/10000., l54_neuron_count))
        f.write('\tLayer 57  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,57]/10000., l57_neuron_count))
        f.write('\tLayer 63  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,63]/10000., l63_neuron_count))
        f.write('\tLayer 66  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,66]/10000., l66_neuron_count))
        f.write('\tLayer 72  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,72]/10000., l72_neuron_count))
        f.write('\tLayer 75  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,75]/10000., l75_neuron_count))
        f.write('\tLayer 81  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,81]/10000., l81_neuron_count))
        f.write('\tLayer 84  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,84]/10000., l84_neuron_count))
        f.write('\tLayer 90  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,90]/10000., l90_neuron_count))

        f.write('\t*****************************************************************************\n')
        f.write('\tDelta-Frame Temporal TSC-SNN spike activities:\n')
        f.write('\tLayer IN  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,101]/10000., inp_neuron_count))
        f.write('\tLayer  2  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,102]/10000., l2_neuron_count))
        f.write('\tLayer  5  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,105]/10000., l5_neuron_count))
        f.write('\tLayer  8  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,108]/10000., l8_neuron_count))
        f.write('\tLayer 12  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,112]/10000., l12_neuron_count))
        f.write('\tLayer 18  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,118]/10000., l18_neuron_count))
        f.write('\tLayer 21  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,121]/10000., l21_neuron_count))
        f.write('\tLayer 27  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,127]/10000., l27_neuron_count))
        f.write('\tLayer 30  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,130]/10000., l30_neuron_count))
        f.write('\tLayer 36  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,136]/10000., l36_neuron_count))
        f.write('\tLayer 39  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,139]/10000., l39_neuron_count))
        f.write('\tLayer 45  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,145]/10000., l45_neuron_count))
        f.write('\tLayer 48  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,148]/10000., l48_neuron_count))
        f.write('\tLayer 54  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,154]/10000., l54_neuron_count))
        f.write('\tLayer 57  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,157]/10000., l57_neuron_count))
        f.write('\tLayer 63  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,163]/10000., l63_neuron_count))
        f.write('\tLayer 66  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,166]/10000., l66_neuron_count))
        f.write('\tLayer 72  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,172]/10000., l72_neuron_count))
        f.write('\tLayer 75  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,175]/10000., l75_neuron_count))
        f.write('\tLayer 81  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,181]/10000., l81_neuron_count))
        f.write('\tLayer 84  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,184]/10000., l84_neuron_count))
        f.write('\tLayer 90  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,190]/10000., l90_neuron_count))

    return np.mean(acc_top1)

def validate_rate(test_loader, model, criterion, f):
    """
    Run evaluation
    """
    # switch to evaluate mode
    model.eval()
    
    start_time = time.time()
    acc_top1 = []
    acc_top5 = []

    with torch.no_grad():

        for i, (inp, target) in enumerate(test_loader):
            target = target.cuda(non_blocking=True)

            # compute outp
            outp = model(inp)
            loss = criterion(outp, target)

            # measure accuracy and record loss
            prec1, prec5 = accuracy(outp, target, topk=(1, 5))
            acc_top1.append(float(prec1))
            acc_top5.append(float(prec5))

    f.write('/\tTest:\tTime {:.3f}\tPrec@1 {:.3f}\tPrec@5 {:.3f}\n'.format(time.time()-start_time, np.mean(acc_top1), np.mean(acc_top5)))

    return np.mean(acc_top1)

def save_checkpoint(state, is_best, filename='checkpoint.tar'):
    """
    Save the training model
    """
    torch.save(state, filename)

def adjust_learning_rate(optimizer, cur_epoch):
    # Reduce learning rate by 10 twice at epoch 81 and 122
    if cur_epoch == 100 or cur_epoch == 200 or cur_epoch == 300 or cur_epoch == 400:
        for param_group in optimizer.param_groups:
            param_group['lr'] /= 10


def accuracy(outp, target, topk=(1,)):
    """Computes the precision@k for the specified values of k"""
    with torch.no_grad():
        maxk = max(topk)
        batch_size = target.size(0)

        _, pred = outp.topk(maxk, 1, True, True)
        pred = pred.t()
        correct = pred.eq(target.view(1, -1).expand_as(pred))

        res = []
        for k in topk:
            correct_k = correct[:k].view(-1).float().sum(0, keepdim=True)
            res.append(correct_k.mul_(100.0 / batch_size))
        return res

if __name__ == '__main__':
    main()
