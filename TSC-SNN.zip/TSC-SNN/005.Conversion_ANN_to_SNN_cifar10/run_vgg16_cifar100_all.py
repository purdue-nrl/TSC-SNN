import argparse
import os
import time
import sys

import numpy as np

import torch
import torch.nn as nn
import torch.nn.parallel
import torch.backends.cudnn as cudnn
import torch.optim
from torchvision import datasets, transforms
from tqdm import tqdm

parser = argparse.ArgumentParser(description='Comparison of ANN-SNN Conversion Techniques - VGG16 with CIFAR-100', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
parser.add_argument('--start_epoch', default=1, type=int, help='starting epoch number (this value is set automatically if resume)')
parser.add_argument('--max_epoch', default=400, type=int, help='number of total epochs to run')
parser.add_argument('--batch_size', default=256, type=int, help='batch size')
parser.add_argument('--learning_rate', default=0.1, type=float, help='initial learning rate')
parser.add_argument('--momentum', default=0.9, type=float, help='momentum')
parser.add_argument('--num_workers', default=16, type=int, help='number of workers')
parser.add_argument('--weight_decay', default=1e-4, type=float, help='weight decay')
parser.add_argument('--resume', default='', type=str, help='path to latest checkpoint')
parser.add_argument('--evaluate', dest='evaluate', action='store_true', help='evaluate model on validation set')
parser.add_argument('--seed', default=0, type=int, help='random seed')
parser.add_argument('--log', default=None, help='log file location')
parser.add_argument('--save_dir', default=None, help='saved directory location')
parser.add_argument('--dt', default=0.001, type=float, help='simulation timestep')
parser.add_argument('--t_end', default=2.5, type=float, help='single example simulation time')


def main():
    start_time = time.time()

    # Parse argument
    global args
    args = parser.parse_args()
   
    if args.log is None:
        f = sys.stdout
    else:
        f = open(args.log, 'w', buffering=1)

    # Initialize seed and best accuracy
    torch.manual_seed(args.seed)
    torch.cuda.manual_seed_all(args.seed)
    best_prec1 = 0

    # Check the save_dir exists or not
    if (not args.save_dir is None) and (not os.path.exists(args.save_dir)):
        os.makedirs(args.save_dir)

    # Load model and parallelize on GPU
    import model_vgg16_cifar100
    model_rate = model_vgg16_cifar100.VGGRate()
    model_rate.features = torch.nn.DataParallel(model_rate.features)
    model_rate.cuda()
    f.write(str(model_rate)+'\n')

    # Define loss function (criterion) and optimizer
    criterion = nn.CrossEntropyLoss().cuda()
    optimizer = torch.optim.SGD(model_rate.parameters(), lr=args.learning_rate,
                                momentum=args.momentum,
                                weight_decay=args.weight_decay)

    # Optionally resume from checkpoint
    if args.resume:
        if os.path.isfile(args.resume):
            checkpoint = torch.load(args.resume)
            args.start_epoch = checkpoint['epoch']
            # best_prec1 = checkpoint['best_prec1']

            # print("Model's state_dict:")
            # for param_tensor in model_rate.state_dict():
            #     print(param_tensor, model_rate.state_dict()[param_tensor].size())
            model_rate.load_state_dict(checkpoint['state_dict'])

            # print("Optimizer's state_dict:")
            # for var_name in optimizer.state_dict():
            #     print(var_name, optimizer.state_dict()[var_name])
            optimizer.load_state_dict(checkpoint['optimizer'])

            f.write("=> Load checkpoint from {} (start_epoch={})\n".format(args.resume, checkpoint['epoch']))
        else:
            f.write("=> No checkpoint found at {}\n".format(args.resume))
            sys.exit(0)

    # Set CUDNN to look for optimal running alogrithm 
    cudnn.benchmark = True

    # Normalization function
    class normalize(object):
        def __init__(self, mean, absmax):
            self.mean = mean
            self.absmax = absmax
        def __call__(self, tensor):
            # Args: tensor (Tensor): Tensor image of size (C, H, W) to be normalized.
            # Returns: Tensor: Normalized image.
            for t, m, am in zip(tensor, self.mean, self.absmax):
                t.sub_(m).div_(am)
            return tensor

    # Mean and SD are calculuated by get_dataset_stat.py
    train_transform = transforms.Compose([
                                         transforms.RandomHorizontalFlip(p=0.5),
                                         transforms.ToTensor(),
                                         normalize(mean=[0.4914, 0.4821, 0.4465],absmax=[0.5086, 0.5179, 0.5535])
                                        ])
    
    test_transform = transforms.Compose([
                                        transforms.ToTensor(),
                                        normalize(mean=[0.4914, 0.4821, 0.4465],absmax=[0.5086, 0.5179, 0.5535])
                                        ])

    dataloader = datasets.CIFAR100
    num_classes = 100

    train_set = dataloader(root='./dataset/cifar100', train=True, download=True, transform=train_transform)
    train_loader = torch.utils.data.DataLoader(train_set, batch_size=args.batch_size, shuffle=True, num_workers=args.num_workers)

    test_set = dataloader(root='./dataset/cifar100', train=False, download=False, transform=test_transform)
    test_loader = torch.utils.data.DataLoader(test_set, batch_size=args.batch_size, shuffle=False, num_workers=args.num_workers)

    if args.evaluate:
        best_prec1 = 0
        prec1 = validate_rate(test_loader, model_rate, criterion, f)
        is_best = prec1 > best_prec1
        best_prec1 = max(prec1, best_prec1)
    else:
        for epoch in range(args.start_epoch, args.max_epoch+1):
            adjust_learning_rate(optimizer, epoch)

            # Train for one epoch
            train_rate(train_loader, model_rate, criterion, optimizer, epoch, f)
            
            # Evaluate on validation set
            prec1 = validate_rate(test_loader, model_rate, criterion, f)

            # Save checkpoint
            is_best = prec1 > best_prec1
            best_prec1 = max(prec1, best_prec1)
            if (epoch % 20 == 0) and (not args.save_dir is None):
                save_checkpoint({
                    'epoch': epoch + 1,
                    'state_dict': model_rate.state_dict(),
                    'best_prec1': best_prec1,
                    'optimizer' : optimizer.state_dict(),            
                }, is_best, filename=os.path.join(args.save_dir, 'checkpoint_{}.tar'.format(epoch)))

        # Re-evaluate again for 10 times
        best_prec1 = 0
        prec1 = validate_rate(test_loader, model_rate, criterion, f)
        is_best = prec1 > best_prec1
        best_prec1 = max(prec1, best_prec1)

    f.write('Summary\t/\tTotal time {:.3f}\t/\tBest prec@1 {:.3f}\n'.format(time.time()-start_time, best_prec1))

    f.write("==> Testing Peter Diehl's ANN-SNN Conversion:\n")
    # Instantiate rate-based sequential model
    import model_vgg16_cifar100_baseline
    model_rate_wprobe = model_vgg16_cifar100_baseline.VGGRate()
    model_rate_wprobe.features = torch.nn.DataParallel(model_rate_wprobe.features)
    model_rate_wprobe.cuda()
    f.write(str(model_rate_wprobe)+'\n')
   
    # Run trained network through training dataset again to find maximum input to IFNeuron 
    weight_mapping = [('features.module.0.weight', 'features.module.0.weight'), 
                      ('features.module.3.weight', 'features.module.3.weight'),
                      ('features.module.7.weight', 'features.module.7.weight'), 
                      ('features.module.10.weight', 'features.module.10.weight'),
                      ('features.module.14.weight', 'features.module.14.weight'), 
                      ('features.module.17.weight', 'features.module.17.weight'),
                      ('features.module.20.weight', 'features.module.20.weight'), 
                      ('features.module.24.weight', 'features.module.24.weight'),
                      ('features.module.27.weight', 'features.module.27.weight'), 
                      ('features.module.30.weight', 'features.module.30.weight'),
                      ('features.module.34.weight', 'features.module.34.weight'), 
                      ('features.module.37.weight', 'features.module.37.weight'),
                      ('features.module.40.weight', 'features.module.40.weight'), 
                      ('classifier.0.weight', 'classifier.0.weight')]

    
    model_rate_dict = model_rate.state_dict() 
    model_rate_wprobe_dict = model_rate_wprobe.state_dict() 
    for source,target in weight_mapping:
        model_rate_wprobe_dict[target].copy_(model_rate_dict[source])

    l1_hmax_outp =  torch.zeros(args.batch_size,1).cuda()
    l4_hmax_outp =  torch.zeros(args.batch_size,1).cuda()
    l8_hmax_outp =  torch.zeros(args.batch_size,1).cuda()
    l11_hmax_outp = torch.zeros(args.batch_size,1).cuda()
    l15_hmax_outp = torch.zeros(args.batch_size,1).cuda()
    l18_hmax_outp = torch.zeros(args.batch_size,1).cuda()
    l21_hmax_outp = torch.zeros(args.batch_size,1).cuda()
    l25_hmax_outp = torch.zeros(args.batch_size,1).cuda()
    l28_hmax_outp = torch.zeros(args.batch_size,1).cuda()
    l31_hmax_outp = torch.zeros(args.batch_size,1).cuda()
    l35_hmax_outp = torch.zeros(args.batch_size,1).cuda()
    l38_hmax_outp = torch.zeros(args.batch_size,1).cuda()
    l41_hmax_outp = torch.zeros(args.batch_size,1).cuda()
    c0_hmax_outp =  torch.zeros(args.batch_size,1).cuda()
    with torch.no_grad():
        for i, (inp, target) in enumerate(train_loader):
            if i == 40:  break
            inp = inp.cuda(non_blocking=True)
            target = target.cuda(non_blocking=True)
            outp,l1_max_outp,l4_max_outp,l8_max_outp,l11_max_outp,l15_max_outp,l18_max_outp,l21_max_outp,l25_max_outp,l28_max_outp,l31_max_outp,l35_max_outp,l38_max_outp,l41_max_outp,c0_max_outp = model_rate_wprobe(inp)
            l1_hmax_outp = torch.max(l1_hmax_outp,l1_max_outp)
            l4_hmax_outp = torch.max(l4_hmax_outp,l4_max_outp)
            l8_hmax_outp = torch.max(l8_hmax_outp,l8_max_outp)
            l11_hmax_outp = torch.max(l11_hmax_outp,l11_max_outp)
            l15_hmax_outp = torch.max(l15_hmax_outp,l15_max_outp)
            l18_hmax_outp = torch.max(l18_hmax_outp,l18_max_outp)
            l21_hmax_outp = torch.max(l21_hmax_outp,l21_max_outp)
            l25_hmax_outp = torch.max(l25_hmax_outp,l25_max_outp)
            l28_hmax_outp = torch.max(l28_hmax_outp,l28_max_outp)
            l31_hmax_outp = torch.max(l31_hmax_outp,l31_max_outp)
            l35_hmax_outp = torch.max(l35_hmax_outp,l35_max_outp)
            l38_hmax_outp = torch.max(l38_hmax_outp,l38_max_outp)
            l41_hmax_outp = torch.max(l41_hmax_outp,l41_max_outp)
            c0_hmax_outp = torch.max(c0_hmax_outp,c0_max_outp)

    l1_hmax_outp = torch.max(l1_hmax_outp)
    l4_hmax_outp = torch.max(l4_hmax_outp)
    l8_hmax_outp = torch.max(l8_hmax_outp)
    l11_hmax_outp = torch.max(l11_hmax_outp)
    l15_hmax_outp = torch.max(l15_hmax_outp)
    l18_hmax_outp = torch.max(l18_hmax_outp)
    l21_hmax_outp = torch.max(l21_hmax_outp)
    l25_hmax_outp = torch.max(l25_hmax_outp)
    l28_hmax_outp = torch.max(l28_hmax_outp)
    l31_hmax_outp = torch.max(l31_hmax_outp)
    l35_hmax_outp = torch.max(l35_hmax_outp)
    l38_hmax_outp = torch.max(l38_hmax_outp)
    l41_hmax_outp = torch.max(l41_hmax_outp)
    c0_hmax_outp = torch.max(c0_hmax_outp)

    # Instantiate spiking module
    model_spike = model_vgg16_cifar100.VGGSpike(dt=args.dt, t_end=args.t_end)
    model_spike = torch.nn.DataParallel(model_spike).cuda()
    f.write(str(model_spike)+'\n')
    
    # Copy weight from sequential model
    weight_mapping = [('features.module.0.weight', 'module.features.1.weight'), 
                      ('features.module.3.weight', 'module.features.4.weight'),
                      ('features.module.7.weight', 'module.features.8.weight'), 
                      ('features.module.10.weight', 'module.features.11.weight'),
                      ('features.module.14.weight', 'module.features.15.weight'), 
                      ('features.module.17.weight', 'module.features.18.weight'),
                      ('features.module.20.weight', 'module.features.21.weight'), 
                      ('features.module.24.weight', 'module.features.25.weight'),
                      ('features.module.27.weight', 'module.features.28.weight'), 
                      ('features.module.30.weight', 'module.features.31.weight'),
                      ('features.module.34.weight', 'module.features.35.weight'), 
                      ('features.module.37.weight', 'module.features.38.weight'),
                      ('features.module.40.weight', 'module.features.41.weight'), 
                      ('classifier.0.weight', 'module.classifier.0.weight')]
    model_rate_wprobe_dict = model_rate_wprobe.state_dict() 
    model_spike_dict = model_spike.state_dict() 
    for source,target in weight_mapping:
        model_spike_dict[target].copy_(model_rate_wprobe_dict[source])

    # Copy mean from sequential model
    mean_mapping = [('features.module.1.running_mean', 'module.features.2.running_mean'),
                    ('features.module.4.running_mean', 'module.features.5.running_mean'),
                    ('features.module.8.running_mean', 'module.features.9.running_mean'),
                    ('features.module.11.running_mean', 'module.features.12.running_mean'),
                    ('features.module.15.running_mean', 'module.features.16.running_mean'),
                    ('features.module.18.running_mean', 'module.features.19.running_mean'),
                    ('features.module.21.running_mean', 'module.features.22.running_mean'),
                    ('features.module.25.running_mean', 'module.features.26.running_mean'),
                    ('features.module.28.running_mean', 'module.features.29.running_mean'),
                    ('features.module.31.running_mean', 'module.features.32.running_mean'),
                    ('features.module.35.running_mean', 'module.features.36.running_mean'),
                    ('features.module.38.running_mean', 'module.features.39.running_mean'),
                    ('features.module.41.running_mean', 'module.features.42.running_mean')]
    model_rate_wprobe_dict = model_rate_wprobe.state_dict()
    model_spike_dict = model_spike.state_dict()
    for source,target in mean_mapping:
        model_spike_dict[target].copy_(model_rate_wprobe_dict[source])


    # Copy var from sequential model
    var_mapping = [('features.module.1.running_var', 'module.features.2.running_var'),
                   ('features.module.4.running_var', 'module.features.5.running_var'),
                   ('features.module.8.running_var', 'module.features.9.running_var'),
                   ('features.module.11.running_var', 'module.features.12.running_var'),
                   ('features.module.15.running_var', 'module.features.16.running_var'),
                   ('features.module.18.running_var', 'module.features.19.running_var'),
                   ('features.module.21.running_var', 'module.features.22.running_var'),
                   ('features.module.25.running_var', 'module.features.26.running_var'),
                   ('features.module.28.running_var', 'module.features.29.running_var'),
                   ('features.module.31.running_var', 'module.features.32.running_var'),
                   ('features.module.35.running_var', 'module.features.36.running_var'),
                   ('features.module.38.running_var', 'module.features.39.running_var'),
                   ('features.module.41.running_var', 'module.features.42.running_var')]
    model_rate_wprobe_dict = model_rate_wprobe.state_dict()
    model_spike_dict = model_spike.state_dict()
    for source,target in var_mapping:
        model_spike_dict[target].copy_(model_rate_wprobe_dict[source])


    # Copy var from sequential model
    nBatch_mapping = [('features.module.1.num_batches_tracked', 'module.features.2.num_batches_tracked'),
                      ('features.module.4.num_batches_tracked', 'module.features.5.num_batches_tracked'),
                      ('features.module.8.num_batches_tracked', 'module.features.9.num_batches_tracked'),
                      ('features.module.11.num_batches_tracked', 'module.features.12.num_batches_tracked'),
                      ('features.module.15.num_batches_tracked', 'module.features.16.num_batches_tracked'),
                      ('features.module.18.num_batches_tracked', 'module.features.19.num_batches_tracked'),
                      ('features.module.21.num_batches_tracked', 'module.features.22.num_batches_tracked'),
                      ('features.module.25.num_batches_tracked', 'module.features.26.num_batches_tracked'),
                      ('features.module.28.num_batches_tracked', 'module.features.29.num_batches_tracked'),
                      ('features.module.31.num_batches_tracked', 'module.features.32.num_batches_tracked'),
                      ('features.module.35.num_batches_tracked', 'module.features.36.num_batches_tracked'),
                      ('features.module.38.num_batches_tracked', 'module.features.39.num_batches_tracked'),
                      ('features.module.41.num_batches_tracked', 'module.features.42.num_batches_tracked')]
    model_rate_wprobe_dict = model_rate_wprobe.state_dict()
    model_spike_dict = model_spike.state_dict()
    for source,target in nBatch_mapping:
        model_spike_dict[target].copy_(model_rate_wprobe_dict[source])




    V_b = 0.0
    V_u = 1.0

    prev_factor = 1.0
    l0_maxw = torch.max(model_rate_wprobe.features.module[0].weight)
    scale_factor = torch.max(l1_hmax_outp, l0_maxw)
    apply_factor = torch.div(scale_factor, prev_factor)*V_b + V_u
    f.write('\tl3 threshold balancing {:.3f}\n'.format(apply_factor))
    model_spike.module.features[3].set_thres(float(apply_factor))
    prev_factor = scale_factor

    l3_maxw = torch.max(model_rate_wprobe.features.module[3].weight)
    scale_factor = torch.max(l4_hmax_outp, l3_maxw)
    apply_factor = torch.div(scale_factor, prev_factor)*V_b + V_u
    f.write('\tl6 threshold balancing {:.3f}\n'.format(apply_factor))
    model_spike.module.features[6].set_thres(float(apply_factor))
    prev_factor = scale_factor

    l7_maxw = torch.max(model_rate_wprobe.features.module[7].weight)
    scale_factor = torch.max(l8_hmax_outp, l7_maxw)
    apply_factor = torch.div(scale_factor, prev_factor)*V_b + V_u
    f.write('\tl10 threshold balancing {:.3f}\n'.format(apply_factor))
    model_spike.module.features[10].set_thres(float(apply_factor))
    prev_factor = scale_factor

    l10_maxw = torch.max(model_rate_wprobe.features.module[10].weight)
    scale_factor = torch.max(l11_hmax_outp, l10_maxw)
    apply_factor = torch.div(scale_factor, prev_factor)*V_b + V_u
    f.write('\tl13 threshold balancing {:.3f}\n'.format(apply_factor))
    model_spike.module.features[13].set_thres(float(apply_factor))
    prev_factor = scale_factor

    l14_maxw = torch.max(model_rate_wprobe.features.module[14].weight)
    scale_factor = torch.max(l15_hmax_outp, l14_maxw)
    apply_factor = torch.div(scale_factor, prev_factor)*V_b + V_u
    f.write('\tl17 threshold balancing {:.3f}\n'.format(apply_factor))
    model_spike.module.features[17].set_thres(float(apply_factor))
    prev_factor = scale_factor

    l17_maxw = torch.max(model_rate_wprobe.features.module[17].weight)
    scale_factor = torch.max(l18_hmax_outp, l17_maxw)
    apply_factor = torch.div(scale_factor, prev_factor)*V_b + V_u
    f.write('\tl20 threshold balancing {:.3f}\n'.format(apply_factor))
    model_spike.module.features[20].set_thres(float(apply_factor))
    prev_factor = scale_factor

    l20_maxw = torch.max(model_rate_wprobe.features.module[20].weight)
    scale_factor = torch.max(l21_hmax_outp, l20_maxw)
    apply_factor = torch.div(scale_factor, prev_factor)*V_b + V_u
    f.write('\tl23 threshold balancing {:.3f}\n'.format(apply_factor))
    model_spike.module.features[23].set_thres(float(apply_factor))
    prev_factor = scale_factor

    l24_maxw = torch.max(model_rate_wprobe.features.module[24].weight)
    scale_factor = torch.max(l25_hmax_outp, l24_maxw)
    apply_factor = torch.div(scale_factor, prev_factor)*V_b + V_u
    f.write('\tl27 threshold balancing {:.3f}\n'.format(apply_factor))
    model_spike.module.features[27].set_thres(float(apply_factor))
    prev_factor = scale_factor

    l27_maxw = torch.max(model_rate_wprobe.features.module[27].weight)
    scale_factor = torch.max(l28_hmax_outp, l27_maxw)
    apply_factor = torch.div(scale_factor, prev_factor)*V_b + V_u
    f.write('\tl30 threshold balancing {:.3f}\n'.format(apply_factor))
    model_spike.module.features[30].set_thres(float(apply_factor))
    prev_factor = scale_factor

    l30_maxw = torch.max(model_rate_wprobe.features.module[30].weight)
    scale_factor = torch.max(l31_hmax_outp, l30_maxw)
    apply_factor = torch.div(scale_factor, prev_factor)*V_b + V_u
    f.write('\tl33 threshold balancing {:.3f}\n'.format(apply_factor))
    model_spike.module.features[33].set_thres(float(apply_factor))
    prev_factor = scale_factor

    l34_maxw = torch.max(model_rate_wprobe.features.module[34].weight)
    scale_factor = torch.max(l35_hmax_outp, l34_maxw)
    apply_factor = torch.div(scale_factor, prev_factor)*V_b + V_u
    f.write('\tl37 threshold balancing {:.3f}\n'.format(apply_factor))
    model_spike.module.features[37].set_thres(float(apply_factor))
    prev_factor = scale_factor

    l37_maxw = torch.max(model_rate_wprobe.features.module[37].weight)
    scale_factor = torch.max(l38_hmax_outp, l37_maxw)
    apply_factor = torch.div(scale_factor, prev_factor)*V_b + V_u
    f.write('\tl40 threshold balancing {:.3f}\n'.format(apply_factor))
    model_spike.module.features[40].set_thres(float(apply_factor))
    prev_factor = scale_factor

    l40_maxw = torch.max(model_rate_wprobe.features.module[40].weight)
    scale_factor = torch.max(l41_hmax_outp, l40_maxw)
    apply_factor = torch.div(scale_factor, prev_factor)*V_b + V_u
    f.write('\tl43 threshold balancing {:.3f}\n'.format(apply_factor))
    model_spike.module.features[43].set_thres(float(apply_factor))
    prev_factor = scale_factor

    # c0_maxw = torch.max(model_rate_wprobe.classifier[0].weight)
    # scale_factor = torch.max(c0_hmax_outp, c0_maxw)
    # apply_factor = torch.div(scale_factor, prev_factor)*V_b + V_u
    # f.write('\tc0 threshold balancing {:.3f}\n'.format(apply_factor))
    # model_spike.module.classifier.set_thres(float(apply_factor))
    # prev_factor = scale_factor

    # Evaluate on validation set
    validate_spike(test_loader, model_spike, criterion, f)

    #####################################################################################################################################


    f.write("==> Testing Abhronil ANN-SNN Conversion:\n")
    # Run trained network through training dataset again to find maximum input to IFNeuron 
    weight_mapping = [('features.module.0.weight', 'module.features.1.weight'), ('features.module.3.weight', 'module.features.4.weight'),
            ('features.module.6.weight', 'module.features.7.weight'), ('features.module.9.weight', 'module.features.10.weight'),
            ('features.module.12.weight', 'module.features.13.weight'), ('features.module.15.weight', 'module.features.16.weight'),
            ('features.module.18.weight', 'module.features.19.weight'), ('features.module.21.weight', 'module.features.22.weight'),
            ('features.module.24.weight', 'module.features.25.weight'), ('features.module.27.weight', 'module.features.28.weight'),
            ('features.module.30.weight', 'module.features.31.weight'), ('features.module.33.weight', 'module.features.34.weight'),
            ('features.module.36.weight', 'module.features.37.weight'), ('classifier.1.weight', 'module.classifier.1.weight'),
            ('classifier.4.weight', 'module.classifier.4.weight')]
    model_rate_dict = model_rate.state_dict() 
    model_spike_dict = model_spike.state_dict() 
    for source,target in weight_mapping:
        model_spike_dict[target].copy_(model_rate_dict[source])

    # Normalize threshold value
    # Following lines are generated automatically from model_vgg16_cifar10.py
    start_time = time.time()
    model_spike.eval()
    with torch.no_grad():
        l3_max_inp_ = torch.zeros(1).cuda()
        l6_max_inp_ = torch.zeros(1).cuda()
        l10_max_inp_ = torch.zeros(1).cuda()
        l13_max_inp_ = torch.zeros(1).cuda()
        l17_max_inp_ = torch.zeros(1).cuda()
        l20_max_inp_ = torch.zeros(1).cuda()
        l23_max_inp_ = torch.zeros(1).cuda()
        l27_max_inp_ = torch.zeros(1).cuda()
        l30_max_inp_ = torch.zeros(1).cuda()
        l33_max_inp_ = torch.zeros(1).cuda()
        l37_max_inp_ = torch.zeros(1).cuda()
        l40_max_inp_ = torch.zeros(1).cuda()
        l43_max_inp_ = torch.zeros(1).cuda()
        # c2_max_inp_ = torch.zeros(1).cuda()
        for i, (inp, target) in enumerate(train_loader):
            if i == 4:  break
            outp,l3_max_inp,l6_max_inp,l10_max_inp,l13_max_inp,l17_max_inp,l20_max_inp,l23_max_inp,l27_max_inp,l30_max_inp,l33_max_inp,l37_max_inp,l40_max_inp,l43_max_inp= model_spike(inp)
            l3_max_inp_ = torch.max(l3_max_inp_,torch.max(l3_max_inp))
        model_spike.module.features[3].set_thres(float(l3_max_inp_))
        f.write('\tl3 threshold balancing {:.3f}\ttime {:.3f}\n'.format(float(torch.max(l3_max_inp_)),time.time()-start_time)); start_time = time.time()

        for i, (inp, target) in enumerate(train_loader):
            if i == 4:  break
            outp,l2_max_inp,l5_max_inp,l8_max_inp,l11_max_inp,l14_max_inp,l17_max_inp,l20_max_inp,l23_max_inp,l26_max_inp,l29_max_inp,l32_max_inp,l35_max_inp,l38_max_inp,c2_max_inp = model_spike(inp)
            l5_max_inp_ = torch.max(l5_max_inp_,torch.max(l5_max_inp))
        model_spike.module.features[5].set_thres(float(l5_max_inp_))
        f.write('\tl5 threshold balancing {:.3f}\ttime {:.3f}\n'.format(float(torch.max(l5_max_inp_)),time.time()-start_time)); start_time = time.time()
        for i, (inp, target) in enumerate(train_loader):
            if i == 4:  break
            outp,l2_max_inp,l5_max_inp,l8_max_inp,l11_max_inp,l14_max_inp,l17_max_inp,l20_max_inp,l23_max_inp,l26_max_inp,l29_max_inp,l32_max_inp,l35_max_inp,l38_max_inp,c2_max_inp = model_spike(inp)
            l8_max_inp_ = torch.max(l8_max_inp_,torch.max(l8_max_inp))
        model_spike.module.features[8].set_thres(float(l8_max_inp_))
        f.write('\tl8 threshold balancing {:.3f}\ttime {:.3f}\n'.format(float(torch.max(l8_max_inp_)),time.time()-start_time)); start_time = time.time()
        for i, (inp, target) in enumerate(train_loader):
            if i == 4:  break
            outp,l2_max_inp,l5_max_inp,l8_max_inp,l11_max_inp,l14_max_inp,l17_max_inp,l20_max_inp,l23_max_inp,l26_max_inp,l29_max_inp,l32_max_inp,l35_max_inp,l38_max_inp,c2_max_inp = model_spike(inp)
            l11_max_inp_ = torch.max(l11_max_inp_,torch.max(l11_max_inp))
        model_spike.module.features[11].set_thres(float(l11_max_inp_))
        f.write('\tl11 threshold balancing {:.3f}\ttime {:.3f}\n'.format(float(torch.max(l11_max_inp_)),time.time()-start_time)); start_time = time.time()
        for i, (inp, target) in enumerate(train_loader):
            if i == 4:  break
            outp,l2_max_inp,l5_max_inp,l8_max_inp,l11_max_inp,l14_max_inp,l17_max_inp,l20_max_inp,l23_max_inp,l26_max_inp,l29_max_inp,l32_max_inp,l35_max_inp,l38_max_inp,c2_max_inp = model_spike(inp)
            l14_max_inp_ = torch.max(l14_max_inp_,torch.max(l14_max_inp))
        model_spike.module.features[14].set_thres(float(l14_max_inp_))
        f.write('\tl14 threshold balancing {:.3f}\ttime {:.3f}\n'.format(float(torch.max(l14_max_inp_)),time.time()-start_time)); start_time = time.time()
        for i, (inp, target) in enumerate(train_loader):
            if i == 4:  break
            outp,l2_max_inp,l5_max_inp,l8_max_inp,l11_max_inp,l14_max_inp,l17_max_inp,l20_max_inp,l23_max_inp,l26_max_inp,l29_max_inp,l32_max_inp,l35_max_inp,l38_max_inp,c2_max_inp = model_spike(inp)
            l17_max_inp_ = torch.max(l17_max_inp_,torch.max(l17_max_inp))
        model_spike.module.features[17].set_thres(float(l17_max_inp_))
        f.write('\tl17 threshold balancing {:.3f}\ttime {:.3f}\n'.format(float(torch.max(l17_max_inp_)),time.time()-start_time)); start_time = time.time()
        for i, (inp, target) in enumerate(train_loader):
            if i == 4:  break
            outp,l2_max_inp,l5_max_inp,l8_max_inp,l11_max_inp,l14_max_inp,l17_max_inp,l20_max_inp,l23_max_inp,l26_max_inp,l29_max_inp,l32_max_inp,l35_max_inp,l38_max_inp,c2_max_inp = model_spike(inp)
            l20_max_inp_ = torch.max(l20_max_inp_,torch.max(l20_max_inp))
        model_spike.module.features[20].set_thres(float(l20_max_inp_))
        f.write('\tl20 threshold balancing {:.3f}\ttime {:.3f}\n'.format(float(torch.max(l20_max_inp_)),time.time()-start_time)); start_time = time.time()
        for i, (inp, target) in enumerate(train_loader):
            if i == 4:  break
            outp,l2_max_inp,l5_max_inp,l8_max_inp,l11_max_inp,l14_max_inp,l17_max_inp,l20_max_inp,l23_max_inp,l26_max_inp,l29_max_inp,l32_max_inp,l35_max_inp,l38_max_inp,c2_max_inp = model_spike(inp)
            l23_max_inp_ = torch.max(l23_max_inp_,torch.max(l23_max_inp))
        model_spike.module.features[23].set_thres(float(l23_max_inp_))
        f.write('\tl23 threshold balancing {:.3f}\ttime {:.3f}\n'.format(float(torch.max(l23_max_inp_)),time.time()-start_time)); start_time = time.time()
        for i, (inp, target) in enumerate(train_loader):
            if i == 4:  break
            outp,l2_max_inp,l5_max_inp,l8_max_inp,l11_max_inp,l14_max_inp,l17_max_inp,l20_max_inp,l23_max_inp,l26_max_inp,l29_max_inp,l32_max_inp,l35_max_inp,l38_max_inp,c2_max_inp = model_spike(inp)
            l26_max_inp_ = torch.max(l26_max_inp_,torch.max(l26_max_inp))
        model_spike.module.features[26].set_thres(float(l26_max_inp_))
        f.write('\tl26 threshold balancing {:.3f}\ttime {:.3f}\n'.format(float(torch.max(l26_max_inp_)),time.time()-start_time)); start_time = time.time()
        for i, (inp, target) in enumerate(train_loader):
            if i == 4:  break
            outp,l2_max_inp,l5_max_inp,l8_max_inp,l11_max_inp,l14_max_inp,l17_max_inp,l20_max_inp,l23_max_inp,l26_max_inp,l29_max_inp,l32_max_inp,l35_max_inp,l38_max_inp,c2_max_inp = model_spike(inp)
            l29_max_inp_ = torch.max(l29_max_inp_,torch.max(l29_max_inp))
        model_spike.module.features[29].set_thres(float(l29_max_inp_))
        f.write('\tl29 threshold balancing {:.3f}\ttime {:.3f}\n'.format(float(torch.max(l29_max_inp_)),time.time()-start_time)); start_time = time.time()
        for i, (inp, target) in enumerate(train_loader):
            if i == 4:  break
            outp,l2_max_inp,l5_max_inp,l8_max_inp,l11_max_inp,l14_max_inp,l17_max_inp,l20_max_inp,l23_max_inp,l26_max_inp,l29_max_inp,l32_max_inp,l35_max_inp,l38_max_inp,c2_max_inp = model_spike(inp)
            l32_max_inp_ = torch.max(l32_max_inp_,torch.max(l32_max_inp))
        model_spike.module.features[32].set_thres(float(l32_max_inp_))
        f.write('\tl32 threshold balancing {:.3f}\ttime {:.3f}\n'.format(float(torch.max(l32_max_inp_)),time.time()-start_time)); start_time = time.time()
        for i, (inp, target) in enumerate(train_loader):
            if i == 4:  break
            outp,l2_max_inp,l5_max_inp,l8_max_inp,l11_max_inp,l14_max_inp,l17_max_inp,l20_max_inp,l23_max_inp,l26_max_inp,l29_max_inp,l32_max_inp,l35_max_inp,l38_max_inp,c2_max_inp = model_spike(inp)
            l35_max_inp_ = torch.max(l35_max_inp_,torch.max(l35_max_inp))
        model_spike.module.features[35].set_thres(float(l35_max_inp_))
        f.write('\tl35 threshold balancing {:.3f}\ttime {:.3f}\n'.format(float(torch.max(l35_max_inp_)),time.time()-start_time)); start_time = time.time()
        for i, (inp, target) in enumerate(train_loader):
            if i == 4:  break
            outp,l2_max_inp,l5_max_inp,l8_max_inp,l11_max_inp,l14_max_inp,l17_max_inp,l20_max_inp,l23_max_inp,l26_max_inp,l29_max_inp,l32_max_inp,l35_max_inp,l38_max_inp,c2_max_inp = model_spike(inp)
            l38_max_inp_ = torch.max(l38_max_inp_,torch.max(l38_max_inp))
        model_spike.module.features[38].set_thres(float(l38_max_inp_))
        f.write('\tl38 threshold balancing {:.3f}\ttime {:.3f}\n'.format(float(torch.max(l38_max_inp_)),time.time()-start_time)); start_time = time.time()
        for i, (inp, target) in enumerate(train_loader):
            if i == 4:  break
            outp,l2_max_inp,l5_max_inp,l8_max_inp,l11_max_inp,l14_max_inp,l17_max_inp,l20_max_inp,l23_max_inp,l26_max_inp,l29_max_inp,l32_max_inp,l35_max_inp,l38_max_inp,c2_max_inp = model_spike(inp)
            c2_max_inp_ = torch.max(c2_max_inp_,torch.max(c2_max_inp))
        model_spike.module.classifier[2].set_thres(float(c2_max_inp_))
        f.write('\tc2 threshold balancing {:.3f}\ttime {:.3f}\n'.format(float(torch.max(c2_max_inp_)),time.time()-start_time)); start_time = time.time()

    # # Set threshold value manually
    # model_spike.module.features[2].set_thres()
    # model_spike.module.features[5].set_thres()
    # model_spike.module.features[8].set_thres()
    # model_spike.module.features[11].set_thres()
    # model_spike.module.features[14].set_thres()
    # model_spike.module.features[17].set_thres()
    # model_spike.module.features[20].set_thres()
    # model_spike.module.features[23].set_thres()
    # model_spike.module.features[26].set_thres()
    # model_spike.module.features[29].set_thres()
    # model_spike.module.features[32].set_thres()
    # model_spike.module.features[35].set_thres()
    # model_spike.module.features[38].set_thres()
    # model_spike.module.classifier[2].set_thres()

    # Evaluate on validation set
    validate_spike(test_loader, model_spike, criterion, f)

    if not args.log is None:
        f.close()

def train_rate(train_loader, model, criterion, optimizer, epoch, f):
    """
        Run one train epoch
    """
    # switch to train mode
    model.train()

    start_time = time.time()
    acc_top1 = []
    acc_top5 = []
    acc_loss = []

    for i, (inp, target) in enumerate(train_loader):
        target = target.cuda(non_blocking=True)

        # compute outp
        outp = model(inp)
        loss = criterion(outp, target)

        # measure accuracy and record loss
        prec1, prec5 = accuracy(outp, target, topk=(1, 5))
        acc_top1.append(float(prec1))
        acc_top5.append(float(prec5))
        acc_loss.append(float(loss))

        # compute gradient and do SGD step
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

    f.write('Epoch {:>3}\t/\tTrain:\tTime {:.3f}\tPrec@1 {:.3f}\tPrec@5 {:.3f}\tLoss {:.3f}\t'.format(epoch,time.time()-start_time, np.mean(acc_top1), np.mean(acc_top5), np.mean(acc_loss)))

def validate_spike(test_loader, model, criterion, f):
    """
    Run evaluation
    """
    # switch to evaluate mode
    model.eval()
    
    start_time = time.time()
    acc_top1 = []
    acc_top5 = []

    with torch.no_grad():
        for i, (inp, target) in enumerate(tqdm(test_loader)):
            target = target.cuda(non_blocking=True)
            outp,l2_max_inp,l5_max_inp,l9_max_inp,l12_max_inp,l16_max_inp,l19_max_inp,l22_max_inp,l26_max_inp,l29_max_inp,l32_max_inp,l36_max_inp,l39_max_inp,l42_max_inp = model(inp)

            loss = criterion(outp, target)

            # measure accuracy and record loss
            prec1, prec5 = accuracy(outp, target, topk=(1, 5))
            acc_top1.append(float(prec1))
            acc_top5.append(float(prec5))
            
            if (i!=0) and (i%2==0):         
                f.write('\tTest {:>5} :\tTime {:.3f}\tPrec@1 {:.3f}\tPrec@5 {:.3f}\n'.format(i, time.time()-start_time, np.mean(acc_top1), np.mean(acc_top5)))
        f.write('\tSummary:\tTotal Time {:.3f}\tPrec@1 {:.3f}\tPrec@5 {:.3f}\n'.format(time.time()-start_time, np.mean(acc_top1), np.mean(acc_top5)))

    return np.mean(acc_top1)

def validate_seq(test_loader, model, criterion, f):
    """
    Run evaluation
    """
    # switch to evaluate mode
    model.eval()
    
    start_time = time.time()
    acc_top1 = []
    acc_top5 = []

    with torch.no_grad():
        for i, (inp, target) in enumerate(test_loader):
            inp = inp.cuda(non_blocking=True)
            target = target.cuda(non_blocking=True)

            # compute outp
            # outp = model(inp)
            outp,l1_max_outp,l4_max_outp,l8_max_outp,l11_max_outp,l15_max_outp,l18_max_outp,l21_max_outp,l25_max_outp,l28_max_outp,l31_max_outp,l35_max_outp,l38_max_outp,l41_max_outp,c0_max_outp = model(inp)
            loss = criterion(outp, target)

            # measure accuracy and record loss
            prec1, prec5 = accuracy(outp, target, topk=(1, 5))
            acc_top1.append(float(prec1))
            acc_top5.append(float(prec5))

    f.write('/\tTest:\tTime {:.3f}\tPrec@1 {:.3f}\tPrec@5 {:.3f}\n'.format(time.time()-start_time, np.mean(acc_top1), np.mean(acc_top5)))

    return np.mean(acc_top1)

def validate_rate(test_loader, model, criterion, f):
    """
    Run evaluation
    """
    # switch to evaluate mode
    model.eval()
    
    start_time = time.time()
    acc_top1 = []
    acc_top5 = []

    with torch.no_grad():
        for i, (inp, target) in enumerate(test_loader):
            target = target.cuda(non_blocking=True)

            # compute outp
            outp = model(inp)
            loss = criterion(outp, target)

            # measure accuracy and record loss
            prec1, prec5 = accuracy(outp, target, topk=(1, 5))
            acc_top1.append(float(prec1))
            acc_top5.append(float(prec5))

    f.write('/\tTest:\tTime {:.3f}\tPrec@1 {:.3f}\tPrec@5 {:.3f}\n'.format(time.time()-start_time, np.mean(acc_top1), np.mean(acc_top5)))

    return np.mean(acc_top1)

def save_checkpoint(state, is_best, filename='checkpoint.tar'):
    """
    Save the training model
    """
    torch.save(state, filename)

def adjust_learning_rate(optimizer, cur_epoch):
    # Reduce learning rate by 10 twice at epoch 81 and 122
    if cur_epoch == 81 or cur_epoch == 122:
        for param_group in optimizer.param_groups:
            param_group['lr'] /= 10


def accuracy(outp, target, topk=(1,)):
    """Computes the precision@k for the specified values of k"""
    with torch.no_grad():
        maxk = max(topk)
        batch_size = target.size(0)

        _, pred = outp.topk(maxk, 1, True, True)
        pred = pred.t()
        correct = pred.eq(target.view(1, -1).expand_as(pred))

        res = []
        for k in topk:
            correct_k = correct[:k].view(-1).float().sum(0, keepdim=True)
            res.append(correct_k.mul_(100.0 / batch_size))
        return res

if __name__ == '__main__':
    main()
