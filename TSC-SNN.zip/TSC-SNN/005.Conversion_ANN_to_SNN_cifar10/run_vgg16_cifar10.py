import argparse
import os
import time
import sys

import numpy as np

import torch
import torch.nn as nn
import torch.nn.parallel
import torch.backends.cudnn as cudnn
import torch.optim
from torchvision import datasets, transforms
from tqdm import tqdm

parser = argparse.ArgumentParser(description='PyTorch Implementation of Abhronil ANN-SNN Conversion Technique - VGG16 with CIFAR-10', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
parser.add_argument('--start_epoch', default=1, type=int, help='starting epoch number (this value is set automatically if resume)')
parser.add_argument('--max_epoch', default=200, type=int, help='number of total epochs to run')
parser.add_argument('--batch_size', default=2500, type=int, help='batch size')
parser.add_argument('--learning_rate', default=0.05, type=float, help='initial learning rate')
parser.add_argument('--momentum', default=0.9, type=float, help='momentum')
parser.add_argument('--num_workers', default=40, type=int, help='number of workers')
parser.add_argument('--weight_decay', default=1e-4, type=float, help='weight decay')
parser.add_argument('--resume', default='', type=str, help='path to latest checkpoint')
parser.add_argument('--evaluate', dest='evaluate', action='store_true', help='evaluate model on validation set')
parser.add_argument('--seed', default=0, type=int, help='random seed')
parser.add_argument('--log', default=None, help='log file location')
parser.add_argument('--save_dir', default=None, help='saved directory location')
parser.add_argument('--dt', default=0.001, type=float, help='simulation timestep')
parser.add_argument('--t_end', default=2.500, type=float, help='single example simulation time')
parser.add_argument('--dropout_prob_0', default=0.0, type=float, help='dropout probability of 1st feature')
parser.add_argument('--dropout_prob_1', default=0.0, type=float, help='dropout probability of 2nd feature')
parser.add_argument('--dropout_prob_2', default=0.0, type=float, help='dropout probability of 3rd feature')
parser.add_argument('--dropout_prob_3', default=0.0, type=float, help='dropout probability of other features')
parser.add_argument('--testing', dest='not_testing', action='store_false', help='skip conversion testing if specified')

parser.add_argument('--gpu_id', default='0,1,2,3', type=str, help='id(s) for CUDA_VISIBLE_DEVICES')
parser.add_argument('--vth_vb', default=0.73, type=float, help='Spiking Neurons Threshold Value')
parser.add_argument('--vth_vu', default=0.0, type=float, help='Spiking Neurons Threshold Value')
parser.add_argument('--snn_fpi', default=128, type=int, help='Number of frames per input image')
parser.add_argument('--snn_TTS', default=256, type=int, help='Simulation timesteps per example')
parser.add_argument('--in_coding', default='rate', type=str, help='rate or temp')
parser.add_argument('--snn_mode', default='full', type=str, help='full or acc or emp')
parser.add_argument('--if_mode', default='if', type=str, help='if or residual')

def main():
    start_time = time.time()

    # Parse argument
    global args
    args = parser.parse_args()
   
    os.environ['CUDA_VISIBLE_DEVICES'] = args.gpu_id
    use_cuda = torch.cuda.is_available()

    if args.log is None:
        f = sys.stdout
    else:
        f = open(args.log, 'w', buffering=1)

    # Initialize seed and best accuracy
    torch.manual_seed(args.seed)
    torch.cuda.manual_seed_all(args.seed)
    best_prec1 = 0

    # Check the save_dir exists or not
    if (not args.save_dir is None) and (not os.path.exists(args.save_dir)):
        os.makedirs(args.save_dir)

    # Load model and parallelize on GPU
    import model_vgg16_cifar10
    model_rate = model_vgg16_cifar10.VGGRate()
    model_rate.features = torch.nn.DataParallel(model_rate.features)
    model_rate.cuda()
    f.write(str(model_rate)+'\n')

    # Define loss function (criterion) and optimizer
    criterion = nn.CrossEntropyLoss().cuda()
    optimizer = torch.optim.SGD(model_rate.parameters(), lr=args.learning_rate,
                                momentum=args.momentum,
                                weight_decay=args.weight_decay)

    # Optionally resume from checkpoint
    if args.resume:
        if os.path.isfile(args.resume):
            checkpoint = torch.load(args.resume)
            args.start_epoch = checkpoint['epoch']
            # best_prec1 = checkpoint['best_prec1']
            model_rate.load_state_dict(checkpoint['state_dict'])
            optimizer.load_state_dict(checkpoint['optimizer'])
            f.write("=> Load checkpoint from {} (start_epoch={})\n".format(args.resume, checkpoint['epoch']))
        else:
            f.write("=> No checkpoint found at {}\n".format(args.resume))
            sys.exit(0)

    # Set CUDNN to look for optimal running alogrithm 
    cudnn.benchmark = True

    # Normalization function
    class normalize(object):
        def __init__(self, mean, absmax):
            self.mean = mean
            self.absmax = absmax
        def __call__(self, tensor):
            # Args: tensor (Tensor): Tensor image of size (C, H, W) to be normalized.
            # Returns: Tensor: Normalized image.
            for t, m, am in zip(tensor, self.mean, self.absmax):
                t.sub_(m).div_(am)
            return tensor

    # Mean and SD are calculuated by get_dataset_stat.py
    train_transform = transforms.Compose([
        transforms.RandomHorizontalFlip(p=0.5),
        transforms.ToTensor(),
        normalize(mean=[0.4914, 0.4821, 0.4465],absmax=[0.5086, 0.5179, 0.5535])
        ])
    train_set = datasets.CIFAR10(root='./dataset/cifar10', train=True, download=True, transform=train_transform)
    train_loader = torch.utils.data.DataLoader(train_set, batch_size=args.batch_size, shuffle=True, num_workers=args.num_workers, pin_memory=True)
    test_transform = transforms.Compose([
        transforms.ToTensor(),
        normalize(mean=[0.4914, 0.4821, 0.4465],absmax=[0.5086, 0.5179, 0.5535])
        ])
    test_set = datasets.CIFAR10(root='./dataset/cifar10', train=False, transform=test_transform)
    test_loader = torch.utils.data.DataLoader(test_set, batch_size=args.batch_size, shuffle=False, num_workers=args.num_workers, pin_memory=True)

    if args.evaluate:
        best_prec1 = 0
        prec1 = validate_rate(test_loader, model_rate, criterion, f)
        is_best = prec1 > best_prec1
        best_prec1 = max(prec1, best_prec1)
    else:
        for epoch in range(args.start_epoch, args.max_epoch+1):
            adjust_learning_rate(optimizer, epoch)

            # Train for one epoch
            train_rate(train_loader, model_rate, criterion, optimizer, epoch, f)
            
            # Evaluate on validation set
            prec1 = validate_rate(test_loader, model_rate, criterion, f)

            # Save checkpoint
            is_best = prec1 > best_prec1
            best_prec1 = max(prec1, best_prec1)
            if (epoch % 20 == 0) and (not args.save_dir is None):
                save_checkpoint({
                    'epoch': epoch + 1,
                    'state_dict': model_rate.state_dict(),
                    'best_prec1': best_prec1,
                    'optimizer' : optimizer.state_dict(),            
                }, is_best, filename=os.path.join(args.save_dir, 'checkpoint_{}.tar'.format(epoch)))

        best_prec1 = 0
        prec1 = validate_rate(test_loader, model_rate, criterion, f)
        is_best = prec1 > best_prec1
        best_prec1 = max(prec1, best_prec1)

    f.write('Summary\t/\tTotal time {:.3f}\t/\tBest prec@1 {:.3f}\n'.format(time.time()-start_time, best_prec1))
    
    f.write("==> Testing Bing's ANN-SNN Conversion:\n")
    # Instantiate spike network
    model_spike_probe = model_vgg16_cifar10.VGGSpike(dt=args.dt, t_end=args.t_end, in_coding='rate', snn_mode='full', if_mode='if', TTS=args.snn_TTS, fpi=args.snn_TTS)
    model_spike_probe = torch.nn.DataParallel(model_spike_probe).cuda()
    f.write(str(model_spike_probe)+'\n')
   
    # Run trained network through training dataset again to find maximum input to IFNeuron 
    weight_mapping = [('features.module.0.weight', 'module.features.1.weight'), 
                      ('features.module.3.weight', 'module.features.4.weight'),
                      ('features.module.6.weight', 'module.features.7.weight'), 
                      ('features.module.9.weight', 'module.features.10.weight'),
                      ('features.module.12.weight', 'module.features.13.weight'), 
                      ('features.module.15.weight', 'module.features.16.weight'),
                      ('features.module.18.weight', 'module.features.19.weight'), 
                      ('features.module.21.weight', 'module.features.22.weight'),
                      ('features.module.24.weight', 'module.features.25.weight'), 
                      ('features.module.27.weight', 'module.features.28.weight'),
                      ('features.module.30.weight', 'module.features.31.weight'), 
                      ('features.module.33.weight', 'module.features.34.weight'),
                      ('features.module.36.weight', 'module.features.37.weight'), 
                      ('classifier.weight', 'module.classifier.weight')]
    model_rate_dict = model_rate.state_dict() 
    model_spike_probe_dict = model_spike_probe.state_dict() 
    for source,target in weight_mapping:
        model_spike_probe_dict[target].copy_(model_rate_dict[source])

    # Normalize threshold value
    # Following lines are generated automatically from model_vgg16_cifar10.py

    V_b = args.vth_vb
    V_u = args.vth_vu
    """
    start_time = time.time()
    model_spike_probe.eval()
    with torch.no_grad():
        l2_max_inp_ = torch.zeros(1).cuda()
        l5_max_inp_ = torch.zeros(1).cuda()
        l8_max_inp_ = torch.zeros(1).cuda()
        l11_max_inp_ = torch.zeros(1).cuda()
        l14_max_inp_ = torch.zeros(1).cuda()
        l17_max_inp_ = torch.zeros(1).cuda()
        l20_max_inp_ = torch.zeros(1).cuda()
        l23_max_inp_ = torch.zeros(1).cuda()
        l26_max_inp_ = torch.zeros(1).cuda()
        l29_max_inp_ = torch.zeros(1).cuda()
        l32_max_inp_ = torch.zeros(1).cuda()
        l35_max_inp_ = torch.zeros(1).cuda()
        l38_max_inp_ = torch.zeros(1).cuda()
        for i, (inp, target) in enumerate(train_loader):
            if i == 4:  break
            outp,l2_max_inp,l5_max_inp,l8_max_inp,l11_max_inp,l14_max_inp,l17_max_inp,l20_max_inp,l23_max_inp,l26_max_inp,l29_max_inp,l32_max_inp,l35_max_inp,l38_max_inp,spike_count = model_spike_probe(inp)
            l2_max_inp_ = torch.max(l2_max_inp_,torch.max(l2_max_inp))
        model_spike_probe.module.features[2].set_thres(float(l2_max_inp_))
        f.write('\tl2 threshold balancing {:.3f}\ttime {:.3f}\n'.format(float(torch.max(l2_max_inp_)),time.time()-start_time)); start_time = time.time()
        
        for i, (inp, target) in enumerate(train_loader):
            if i == 4:  break
            outp,l2_max_inp,l5_max_inp,l8_max_inp,l11_max_inp,l14_max_inp,l17_max_inp,l20_max_inp,l23_max_inp,l26_max_inp,l29_max_inp,l32_max_inp,l35_max_inp,l38_max_inp,spike_count = model_spike_probe(inp)
            l5_max_inp_ = torch.max(l5_max_inp_,torch.max(l5_max_inp))
        model_spike_probe.module.features[5].set_thres(float(l5_max_inp_))
        f.write('\tl5 threshold balancing {:.3f}\ttime {:.3f}\n'.format(float(torch.max(l5_max_inp_)),time.time()-start_time)); start_time = time.time()
        
        for i, (inp, target) in enumerate(train_loader):
            if i == 4:  break
            outp,l2_max_inp,l5_max_inp,l8_max_inp,l11_max_inp,l14_max_inp,l17_max_inp,l20_max_inp,l23_max_inp,l26_max_inp,l29_max_inp,l32_max_inp,l35_max_inp,l38_max_inp,spike_count = model_spike_probe(inp)
            l8_max_inp_ = torch.max(l8_max_inp_,torch.max(l8_max_inp))
        model_spike_probe.module.features[8].set_thres(float(l8_max_inp_))
        f.write('\tl8 threshold balancing {:.3f}\ttime {:.3f}\n'.format(float(torch.max(l8_max_inp_)),time.time()-start_time)); start_time = time.time()
        
        for i, (inp, target) in enumerate(train_loader):
            if i == 4:  break
            outp,l2_max_inp,l5_max_inp,l8_max_inp,l11_max_inp,l14_max_inp,l17_max_inp,l20_max_inp,l23_max_inp,l26_max_inp,l29_max_inp,l32_max_inp,l35_max_inp,l38_max_inp,spike_count = model_spike_probe(inp)
            l11_max_inp_ = torch.max(l11_max_inp_,torch.max(l11_max_inp))
        model_spike_probe.module.features[11].set_thres(float(l11_max_inp_))
        f.write('\tl11 threshold balancing {:.3f}\ttime {:.3f}\n'.format(float(torch.max(l11_max_inp_)),time.time()-start_time)); start_time = time.time()
        
        for i, (inp, target) in enumerate(train_loader):
            if i == 4:  break
            outp,l2_max_inp,l5_max_inp,l8_max_inp,l11_max_inp,l14_max_inp,l17_max_inp,l20_max_inp,l23_max_inp,l26_max_inp,l29_max_inp,l32_max_inp,l35_max_inp,l38_max_inp,spike_count = model_spike_probe(inp)
            l14_max_inp_ = torch.max(l14_max_inp_,torch.max(l14_max_inp))
        model_spike_probe.module.features[14].set_thres(float(l14_max_inp_))
        f.write('\tl14 threshold balancing {:.3f}\ttime {:.3f}\n'.format(float(torch.max(l14_max_inp_)),time.time()-start_time)); start_time = time.time()
        
        for i, (inp, target) in enumerate(train_loader):
            if i == 4:  break
            outp,l2_max_inp,l5_max_inp,l8_max_inp,l11_max_inp,l14_max_inp,l17_max_inp,l20_max_inp,l23_max_inp,l26_max_inp,l29_max_inp,l32_max_inp,l35_max_inp,l38_max_inp,spike_count = model_spike_probe(inp)
            l17_max_inp_ = torch.max(l17_max_inp_,torch.max(l17_max_inp))
        model_spike_probe.module.features[17].set_thres(float(l17_max_inp_))
        f.write('\tl17 threshold balancing {:.3f}\ttime {:.3f}\n'.format(float(torch.max(l17_max_inp_)),time.time()-start_time)); start_time = time.time()
        
        for i, (inp, target) in enumerate(train_loader):
            if i == 4:  break
            outp,l2_max_inp,l5_max_inp,l8_max_inp,l11_max_inp,l14_max_inp,l17_max_inp,l20_max_inp,l23_max_inp,l26_max_inp,l29_max_inp,l32_max_inp,l35_max_inp,l38_max_inp,spike_count = model_spike_probe(inp)
            l20_max_inp_ = torch.max(l20_max_inp_,torch.max(l20_max_inp))
        model_spike_probe.module.features[20].set_thres(float(l20_max_inp_))
        f.write('\tl20 threshold balancing {:.3f}\ttime {:.3f}\n'.format(float(torch.max(l20_max_inp_)),time.time()-start_time)); start_time = time.time()
        
        for i, (inp, target) in enumerate(train_loader):
            if i == 4:  break
            outp,l2_max_inp,l5_max_inp,l8_max_inp,l11_max_inp,l14_max_inp,l17_max_inp,l20_max_inp,l23_max_inp,l26_max_inp,l29_max_inp,l32_max_inp,l35_max_inp,l38_max_inp,spike_count = model_spike_probe(inp)
            l23_max_inp_ = torch.max(l23_max_inp_,torch.max(l23_max_inp))
        model_spike_probe.module.features[23].set_thres(float(l23_max_inp_))
        f.write('\tl23 threshold balancing {:.3f}\ttime {:.3f}\n'.format(float(torch.max(l23_max_inp_)),time.time()-start_time)); start_time = time.time()
        
        for i, (inp, target) in enumerate(train_loader):
            if i == 4:  break
            outp,l2_max_inp,l5_max_inp,l8_max_inp,l11_max_inp,l14_max_inp,l17_max_inp,l20_max_inp,l23_max_inp,l26_max_inp,l29_max_inp,l32_max_inp,l35_max_inp,l38_max_inp,spike_count = model_spike_probe(inp)
            l26_max_inp_ = torch.max(l26_max_inp_,torch.max(l26_max_inp))
        model_spike_probe.module.features[26].set_thres(float(l26_max_inp_))
        f.write('\tl26 threshold balancing {:.3f}\ttime {:.3f}\n'.format(float(torch.max(l26_max_inp_)),time.time()-start_time)); start_time = time.time()
        
        for i, (inp, target) in enumerate(train_loader):
            if i == 4:  break
            outp,l2_max_inp,l5_max_inp,l8_max_inp,l11_max_inp,l14_max_inp,l17_max_inp,l20_max_inp,l23_max_inp,l26_max_inp,l29_max_inp,l32_max_inp,l35_max_inp,l38_max_inp,spike_count = model_spike_probe(inp)
            l29_max_inp_ = torch.max(l29_max_inp_,torch.max(l29_max_inp))
        model_spike_probe.module.features[29].set_thres(float(l29_max_inp_))
        f.write('\tl29 threshold balancing {:.3f}\ttime {:.3f}\n'.format(float(torch.max(l29_max_inp_)),time.time()-start_time)); start_time = time.time()
        
        for i, (inp, target) in enumerate(train_loader):
            if i == 4:  break
            outp,l2_max_inp,l5_max_inp,l8_max_inp,l11_max_inp,l14_max_inp,l17_max_inp,l20_max_inp,l23_max_inp,l26_max_inp,l29_max_inp,l32_max_inp,l35_max_inp,l38_max_inp,spike_count = model_spike_probe(inp)
            l32_max_inp_ = torch.max(l32_max_inp_,torch.max(l32_max_inp))
        model_spike_probe.module.features[32].set_thres(float(l32_max_inp_))
        f.write('\tl32 threshold balancing {:.3f}\ttime {:.3f}\n'.format(float(torch.max(l32_max_inp_)),time.time()-start_time)); start_time = time.time()
        
        for i, (inp, target) in enumerate(train_loader):
            if i == 4:  break
            outp,l2_max_inp,l5_max_inp,l8_max_inp,l11_max_inp,l14_max_inp,l17_max_inp,l20_max_inp,l23_max_inp,l26_max_inp,l29_max_inp,l32_max_inp,l35_max_inp,l38_max_inp,spike_count = model_spike_probe(inp)
            l35_max_inp_ = torch.max(l35_max_inp_,torch.max(l35_max_inp))
        model_spike_probe.module.features[35].set_thres(float(l35_max_inp_))
        f.write('\tl35 threshold balancing {:.3f}\ttime {:.3f}\n'.format(float(torch.max(l35_max_inp_)),time.time()-start_time)); start_time = time.time()
        
        for i, (inp, target) in enumerate(train_loader):
            if i == 4:  break
            outp,l2_max_inp,l5_max_inp,l8_max_inp,l11_max_inp,l14_max_inp,l17_max_inp,l20_max_inp,l23_max_inp,l26_max_inp,l29_max_inp,l32_max_inp,l35_max_inp,l38_max_inp,spike_count = model_spike_probe(inp)
            l38_max_inp_ = torch.max(l38_max_inp_,torch.max(l38_max_inp))
        model_spike_probe.module.features[38].set_thres(float(l38_max_inp_))
        f.write('\tl38 threshold balancing {:.3f}\ttime {:.3f}\n'.format(float(torch.max(l38_max_inp_)),time.time()-start_time)); start_time = time.time() 
       
    """
    print('Use pre-computed thresholds for SNN')

    if args.snn_TTS <= 64:
        l2_max_inp_ = 4.667
        l5_max_inp_ = 4.033
        l8_max_inp_ = 0.695
        l11_max_inp_ = 1.989 
        l14_max_inp_ = 0.359
        l17_max_inp_ = 0.881
        l20_max_inp_ = 1.629
        l23_max_inp_ = 0.262
        l26_max_inp_ = 0.978
        l29_max_inp_ = 1.422
        l32_max_inp_ = 0.887
        l35_max_inp_ = 2.588
        l38_max_inp_ = 3.88

    elif args.snn_TTS == 128:
        l2_max_inp_ = 5.398
        l5_max_inp_ = 4.807
        l8_max_inp_ = 0.85
        l11_max_inp_ = 2.365
        l14_max_inp_ = 0.343
        l17_max_inp_ = 1.109
        l20_max_inp_ = 0.966
        l23_max_inp_ = 0.207
        l26_max_inp_ = 1.009
        l29_max_inp_ = 1.28
        l32_max_inp_ = 0.783
        l35_max_inp_ = 2.204
        l38_max_inp_ = 3.099

    elif args.snn_TTS == 256:
        l2_max_inp_ = 5.444
        l5_max_inp_ = 5.129
        l8_max_inp_ = 0.811
        l11_max_inp_ = 2.537
        l14_max_inp_ = 0.341
        l17_max_inp_ = 1.029
        l20_max_inp_ = 1.167
        l23_max_inp_ = 0.227
        l26_max_inp_ = 1.024
        l29_max_inp_ = 1.267
        l32_max_inp_ = 0.686
        l35_max_inp_ = 2.811
        l38_max_inp_ = 3.472

    elif args.snn_TTS == 512:
        l2_max_inp_ = 5.634
        l5_max_inp_ = 4.985
        l8_max_inp_ = 0.97
        l11_max_inp_ = 2.751
        l14_max_inp_ = 0.321
        l17_max_inp_ = 1.087
        l20_max_inp_ = 1.149
        l23_max_inp_ = 0.21
        l26_max_inp_ = 0.939
        l29_max_inp_ = 1.521
        l32_max_inp_ = 0.735
        l35_max_inp_ = 2.106
        l38_max_inp_ = 4.843

    elif args.snn_TTS == 768:
        l2_max_inp_ = 5.809
        l5_max_inp_ = 4.763
        l8_max_inp_ = 1.016
        l11_max_inp_ = 2.219
        l14_max_inp_ = 0.344
        l17_max_inp_ = 1.108
        l20_max_inp_ = 1.27
        l23_max_inp_ = 0.237
        l26_max_inp_ = 0.771
        l29_max_inp_ = 1.897
        l32_max_inp_ = 0.581
        l35_max_inp_ = 2.803
        l38_max_inp_ = 3.761

    elif args.snn_TTS == 1024:
        l2_max_inp_ = 5.937
        l5_max_inp_ = 4.776
        l8_max_inp_ = 0.966
        l11_max_inp_ = 2.77
        l14_max_inp_ = 0.329
        l17_max_inp_ = 0.924
        l20_max_inp_ = 1.36
        l23_max_inp_ = 0.229
        l26_max_inp_ = 0.89
        l29_max_inp_ = 1.668
        l32_max_inp_ = 0.569
        l35_max_inp_ = 3.063
        l38_max_inp_ = 3.637

    elif args.snn_TTS == 1536:
        l2_max_inp_ = 5.715
        l5_max_inp_ = 5.294
        l8_max_inp_ = 0.98
        l11_max_inp_ = 2.59
        l14_max_inp_ = 0.335
        l17_max_inp_ = 0.957
        l20_max_inp_ = 1.304
        l23_max_inp_ = 0.217
        l26_max_inp_ = 0.886
        l29_max_inp_ = 1.973
        l32_max_inp_ = 0.568
        l35_max_inp_ = 2.604
        l38_max_inp_ = 3.896

    elif args.snn_TTS == 2048:
        l2_max_inp_ = 5.746
        l5_max_inp_ = 5.214
        l8_max_inp_ = 1.22
        l11_max_inp_ = 2.229
        l14_max_inp_ = 0.367
        l17_max_inp_ = 1.115
        l20_max_inp_ = 1.138
        l23_max_inp_ = 0.224
        l26_max_inp_ = 0.839
        l29_max_inp_ = 1.782
        l32_max_inp_ = 0.687
        l35_max_inp_ = 2.314
        l38_max_inp_ = 4.407

    f.write('\tl2 threshold balancing {:.3f} \n '.format(float(l2_max_inp_)))
    f.write('\tl5 threshold balancing {:.3f} \n '.format(float(l5_max_inp_)))
    f.write('\tl8 threshold balancing {:.3f} \n '.format(float(l8_max_inp_)))
    f.write('\tl11 threshold balancing {:.3f} \n '.format(float(l11_max_inp_)))
    f.write('\tl14 threshold balancing {:.3f} \n'.format(float(l14_max_inp_)))
    f.write('\tl17 threshold balancing {:.3f} \n '.format(float(l17_max_inp_)))
    f.write('\tl20 threshold balancing {:.3f} \n '.format(float(l20_max_inp_)))
    f.write('\tl23 threshold balancing {:.3f} \n '.format(float(l23_max_inp_)))
    f.write('\tl26 threshold balancing {:.3f} \n '.format(float(l26_max_inp_)))
    f.write('\tl29 threshold balancing {:.3f} \n '.format(float(l29_max_inp_)))
    f.write('\tl32 threshold balancing {:.3f} \n '.format(float(l32_max_inp_)))
    f.write('\tl35 threshold balancing {:.3f} \n '.format(float(l35_max_inp_)))
    f.write('\tl38 threshold balancing {:.3f} \n '.format(float(l38_max_inp_)))


    model_spike = model_vgg16_cifar10.VGGSpike(dt=args.dt, t_end=args.t_end, in_coding=args.in_coding, snn_mode=args.snn_mode, if_mode=args.if_mode, TTS=args.snn_TTS, fpi=args.snn_fpi)
    model_spike = torch.nn.DataParallel(model_spike).cuda()
    model_rate_dict = model_rate.state_dict()
    model_spike_dict = model_spike.state_dict()
    for source,target in weight_mapping:
        model_spike_dict[target].copy_(model_rate_dict[source])

    # Set threshold value manually
    model_spike.module.features[2].set_thres(l2_max_inp_*V_b+V_u)
    model_spike.module.features[5].set_thres(l5_max_inp_*V_b+V_u)
    model_spike.module.features[8].set_thres(l8_max_inp_*V_b+V_u)
    model_spike.module.features[11].set_thres(l11_max_inp_*V_b+V_u)
    model_spike.module.features[14].set_thres(l14_max_inp_*V_b+V_u)
    model_spike.module.features[17].set_thres(l17_max_inp_*V_b+V_u)
    model_spike.module.features[20].set_thres(l20_max_inp_*V_b+V_u)
    model_spike.module.features[23].set_thres(l23_max_inp_*V_b+V_u)
    model_spike.module.features[26].set_thres(l26_max_inp_*V_b+V_u)
    model_spike.module.features[29].set_thres(l29_max_inp_*V_b+V_u)
    model_spike.module.features[32].set_thres(l32_max_inp_*V_b+V_u)
    model_spike.module.features[35].set_thres(l35_max_inp_*V_b+V_u)
    model_spike.module.features[38].set_thres(l38_max_inp_*V_b+V_u)
    

    # Evaluate on validation set
    validate_spike(test_loader, model_spike, criterion, f)

    if not args.log is None:
        f.close()

def train_rate(train_loader, model, criterion, optimizer, epoch, f):
    """
        Run one train epoch
    """
    # switch to train mode
    model.train()

    start_time = time.time()
    acc_top1 = []
    acc_top5 = []
    acc_loss = []

    for i, (inp, target) in enumerate(train_loader):
        target = target.cuda(non_blocking=True)

        # compute outp
        outp = model(inp)
        loss = criterion(outp, target)

        # measure accuracy and record loss
        prec1, prec5 = accuracy(outp, target, topk=(1, 5))
        acc_top1.append(float(prec1))
        acc_top5.append(float(prec5))
        acc_loss.append(float(loss))

        # compute gradient and do SGD step
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

    f.write('Epoch {:>3}\t/\tTrain:\tTime {:.3f}\tPrec@1 {:.3f}\tPrec@5 {:.3f}\tLoss {:.3f}\t'.format(epoch,time.time()-start_time, np.mean(acc_top1), np.mean(acc_top5), np.mean(acc_loss)))

def validate_spike(test_loader, model, criterion, f):
    """
    Run evaluation
    """
    # switch to evaluate mode
    model.eval()
    
    start_time = time.time()
    acc_top1 = []
    acc_top5 = []
    spike_count = []    

    inp_neuron_count = 32*32*3
    l2_neuron_count  = 64*32*32
    l5_neuron_count  = 64*32*32
    l8_neuron_count  = 128*16*16
    l11_neuron_count = 128*16*16
    l14_neuron_count = 256*8*8
    l17_neuron_count = 256*8*8
    l20_neuron_count = 256*8*8
    l23_neuron_count = 512*4*4
    l26_neuron_count = 512*4*4
    l29_neuron_count = 512*4*4
    l32_neuron_count = 512*2*2
    l35_neuron_count = 512*2*2
    l38_neuron_count = 512*2*2
    spike_total = torch.zeros(1,200).cuda()

    with torch.no_grad():
        for i, (inp, target) in enumerate(tqdm(test_loader)):
            target = target.cuda(non_blocking=True)
            outp,l2_max_inp,l5_max_inp,l8_max_inp,l11_max_inp,l14_max_inp,l17_max_inp,l20_max_inp,l23_max_inp,l26_max_inp,l29_max_inp,l32_max_inp,l35_max_inp,l38_max_inp,spike_count = model(inp)
            loss = criterion(outp, target)
            # measure accuracy and record loss
            prec1, prec5 = accuracy(outp, target, topk=(1, 5))
            acc_top1.append(float(prec1))
            acc_top5.append(float(prec5))
            spike_total += torch.sum(spike_count, dim=0)
            if (i!=0) and (i%1==0):         
                f.write('\tTest {:>5} :\tTime {:.3f}\tPrec@1 {:.3f}\tPrec@5 {:.3f}\n'.format(i, time.time()-start_time, np.mean(acc_top1), np.mean(acc_top5)))

        f.write('\t*****************************************************************************\n')
        f.write('\tSummary:\tTotal Time {:.3f}\tPrec@1 {:.3f}\tPrec@5 {:.3f}\n'.format(time.time()-start_time, np.mean(acc_top1), np.mean(acc_top5)))

        f.write('\t*****************************************************************************\n')
        f.write('\tFull-Frame Temporal RMP-SNN spike activities:\n')
        f.write('\tLayer IN  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format( spike_total[0,1]/10000., inp_neuron_count))
        f.write('\tLayer  2  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format( spike_total[0,2]/10000., l2_neuron_count))
        f.write('\tLayer  5  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format( spike_total[0,5]/10000., l5_neuron_count))
        f.write('\tLayer  8  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format( spike_total[0,8]/10000., l8_neuron_count))
        f.write('\tLayer 11  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,11]/10000., l11_neuron_count))
        f.write('\tLayer 14  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,14]/10000., l14_neuron_count))
        f.write('\tLayer 17  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,17]/10000., l17_neuron_count))
        f.write('\tLayer 20  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,20]/10000., l20_neuron_count))
        f.write('\tLayer 23  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,23]/10000., l23_neuron_count))
        f.write('\tLayer 26  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,26]/10000., l26_neuron_count))
        f.write('\tLayer 29  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,29]/10000., l29_neuron_count))
        f.write('\tLayer 32  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,32]/10000., l32_neuron_count))
        f.write('\tLayer 35  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,35]/10000., l35_neuron_count))
        f.write('\tLayer 38  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,38]/10000., l38_neuron_count))

        f.write('\t*****************************************************************************\n')
        f.write('\tDelta-Frame Temporal RMP-SNN spike activities:\n')
        f.write('\tLayer IN  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,101]/10000., inp_neuron_count))
        f.write('\tLayer  2  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,102]/10000., l2_neuron_count))
        f.write('\tLayer  5  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,105]/10000., l5_neuron_count))
        f.write('\tLayer  8  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,108]/10000., l8_neuron_count))
        f.write('\tLayer 11  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,111]/10000., l11_neuron_count))
        f.write('\tLayer 14  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,114]/10000., l14_neuron_count))
        f.write('\tLayer 17  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,117]/10000., l17_neuron_count))
        f.write('\tLayer 20  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,120]/10000., l20_neuron_count))
        f.write('\tLayer 23  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,123]/10000., l23_neuron_count))
        f.write('\tLayer 26  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,126]/10000., l26_neuron_count))
        f.write('\tLayer 29  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,129]/10000., l29_neuron_count))
        f.write('\tLayer 32  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,132]/10000., l32_neuron_count))
        f.write('\tLayer 35  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,135]/10000., l35_neuron_count))
        f.write('\tLayer 38  spikes_ttl/image: {0:1.4f}, neurons_ttl: {1:1.0f}\n'.format(spike_total[0,138]/10000., l38_neuron_count)) 
    return np.mean(acc_top1)

def validate_rate(test_loader, model, criterion, f):
    """
    Run evaluation
    """
    # switch to evaluate mode
    model.eval()
    
    start_time = time.time()
    acc_top1 = []
    acc_top5 = []

    with torch.no_grad():
        for i, (inp, target) in enumerate(test_loader):

            inp = inp.cuda(non_blocking=True)
            target = target.cuda(non_blocking=True)

            # compute outp
            # outp = model(inp)

            outp = model.features.module[0](inp)
            # print('l0_max_outp_pre', torch.max(outp), torch.min(outp))
            outp = model.features.module[1](outp)
            outp = model.features.module[2](outp)

            outp = model.features.module[3](outp)
            # print('l3_max_outp_pre', torch.max(outp), torch.min(outp))
            outp = model.features.module[4](outp)
            outp = model.features.module[5](outp)

            outp = model.features.module[6](outp)
            # print('l6_max_outp', torch.max(outp), torch.min(outp))
            outp = model.features.module[7](outp)
            outp = model.features.module[8](outp)

            outp = model.features.module[9](outp)
            # print('l9_max_outp', torch.max(outp), torch.min(outp))
            outp = model.features.module[10](outp)
            outp = model.features.module[11](outp)

            outp = model.features.module[12](outp)
            # print('l12_max_outp', torch.max(outp), torch.min(outp))
            outp = model.features.module[13](outp)
            outp = model.features.module[14](outp)

            outp = model.features.module[15](outp)
            # print('l15_max_outp', torch.max(outp), torch.min(outp))
            outp = model.features.module[16](outp)
            outp = model.features.module[17](outp)

            outp = model.features.module[18](outp)
	    # print('l18_max_outp', torch.max(outp), torch.min(outp))
            outp = model.features.module[19](outp)
            outp = model.features.module[20](outp)

            outp = model.features.module[21](outp)
            # print('l21_max_outp', torch.max(outp), torch.min(outp))
            outp = model.features.module[22](outp)
            outp = model.features.module[23](outp)

            outp = model.features.module[24](outp)
            # print('l24_max_outp', torch.max(outp), torch.min(outp))
            outp = model.features.module[25](outp)
            outp = model.features.module[26](outp)

            outp = model.features.module[27](outp)
            # print('l27_max_outp', torch.max(outp), torch.min(outp))
            outp = model.features.module[28](outp)
            outp = model.features.module[29](outp)

            outp = model.features.module[30](outp)
            # print('l30_max_outp', torch.max(outp), torch.min(outp))
            outp = model.features.module[31](outp)
            outp = model.features.module[32](outp)

            outp = model.features.module[33](outp)
            # print('l33_max_outp', torch.max(outp), torch.min(outp))
            outp = model.features.module[34](outp)
            outp = model.features.module[35](outp)

            outp = model.features.module[36](outp)
            # print('l36_max_outp', torch.max(outp), torch.min(outp))
            outp = model.features.module[37](outp)
            outp = model.features.module[38](outp)

            outp = outp.view(outp.size(0), -1)
            outp = model.classifier(outp)

            loss = criterion(outp, target)

            # measure accuracy and record loss
            prec1, prec5 = accuracy(outp, target, topk=(1, 5))
            acc_top1.append(float(prec1))
            acc_top5.append(float(prec5))

    f.write('/\tTest:\tTime {:.3f}\tPrec@1 {:.3f}\tPrec@5 {:.3f}\n'.format(time.time()-start_time, np.mean(acc_top1), np.mean(acc_top5)))

    return np.mean(acc_top1)

def save_checkpoint(state, is_best, filename='checkpoint.tar'):
    """
    Save the training model
    """
    torch.save(state, filename)

def adjust_learning_rate(optimizer, cur_epoch):
    # Reduce learning rate by 10 twice at epoch 81 and 122
    if cur_epoch == 81 or cur_epoch == 122:
        for param_group in optimizer.param_groups:
            param_group['lr'] /= 10


def accuracy(outp, target, topk=(1,)):
    """Computes the precision@k for the specified values of k"""
    with torch.no_grad():
        maxk = max(topk)
        batch_size = target.size(0)

        _, pred = outp.topk(maxk, 1, True, True)
        pred = pred.t()
        correct = pred.eq(target.view(1, -1).expand_as(pred))

        res = []
        for k in topk:
            correct_k = correct[:k].view(-1).float().sum(0, keepdim=True)
            res.append(correct_k.mul_(100.0 / batch_size))
        return res

if __name__ == '__main__':
    main()
