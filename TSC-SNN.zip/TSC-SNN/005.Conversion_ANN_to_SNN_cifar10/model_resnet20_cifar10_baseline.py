
import torch
import torch.nn as nn
import math

# Poisson spike generator
#   This module generates spike based on assumption that input is between 1 and -1
#   Positive spike is generated (i.e. 1 is return) if rand()<abs(input) and sign(input)=1
#   Negative spike is generated (i.e. -1 is return) if rand()<abs(input) and sign(input)=-1
#   This method is corresponding to Method 1 on Page 5 of lecture note http://www.cns.nyu.edu/~david/handouts/poisson.pdf
class PoissonGen(nn.Module):
    def __init__(self):
        super(PoissonGen, self).__init__()
    def forward(self, inp, t, N, en_IN):
        # nbits = 32
        # inp_disc= torch.round(inp*(2^nbits-1))/(2^nbits-1)
        # return torch.mul(torch.le(torch.rand_like(inp), torch.abs(inp_disc)).float(), torch.sign(inp))
        return torch.mul(torch.le(torch.rand_like(inp), torch.abs(inp)).float(), torch.sign(inp))


# Temporal spikes generator
class TemporalGen(nn.Module):
    def __init__(self):
        super(TemporalGen, self).__init__()
    def forward(self, inp, t, N, en_IN):
        DoS_Pos = 0.0
        DoS_Neg = 0.0

        shift_pos = (N/2)*(1-torch.abs(inp))*DoS_Pos
        shift_neg = (N/2)*(1-torch.abs(inp))*DoS_Neg
        if en_IN:
            op=1.0
        else:
            op=0.0
        return op * torch.mul(torch.mul( torch.ge(inp*0+t, shift_pos + (N/2)*(1-torch.abs(inp))).float(),
                                         torch.le(inp*0+t, shift_neg + (N/2)*(1+torch.abs(inp))).float()), torch.sign(inp))


# Integrate-and-fire neuron (IFNeuron)
#   This module is slightly from IFNeuron module in the script that I have sent to Gopal and Priya earlier.
#   This module models simple IFNeuron without any refractory period
#   This modeule does not have state information, thus allowing it to be parallelized across GPUs when torch.nn.DataParallel is wrapped around
#   As a result, this module takes two arguments: input and previous IFNeuron membrane potential
#   Spike is generated if IFNeuron membrane potential reachs defined threshold
#   Spike output is return with new IFNeuron membrane potential
class IFNeuron(nn.Module):
    # Argument inplace does not have any use. You can ignore it. 
    def __init__(self, inplace=True, thres=1.0):
        super(IFNeuron, self).__init__()
        self.thres = thres
    def forward(self, inp, mem_potential, IF_spiking, IF_residual):
        mem_potential += inp
	outp = mem_potential*0.0
	if IF_spiking:
	    outp = torch.ge(mem_potential, self.thres)
            if IF_residual:
                mem_potential[outp] = (mem_potential[outp] - self.thres)*1.0  # Residual-IF neuron
            else:
                mem_potential[outp] = (mem_potential[outp] - self.thres)*0.0  # IF neuron
        return outp.float(), mem_potential 
    def set_thres(self, thres):
        self.thres = thres
    def get_thres(self):
        return self.thres
    def extra_repr(self):
        return 'thres={}'.format(self.thres)

# Identity module
#   This module returns whatever it recieves
class Identity(nn.Module):
    def __init__(self):
        super(Identity, self).__init__()
    def forward(self, inp):
        return inp

# Following are dummy modules
#   Those modules do not have any function
class DelayMark(nn.Module):
    def __init__(self):
        super(DelayMark, self).__init__()
class ResidueMark(nn.Module):
    def __init__(self):
        super(ResidueMark, self).__init__()
class MergeMark0(nn.Module):
    def __init__(self):
        super(MergeMark0, self).__init__()
class MergeMark1(nn.Module):
    def __init__(self):
        super(MergeMark1, self).__init__()

# Basic block in ResNet-20
class BasicBlock1(nn.Module):
    def __init__(self, in_channels, out_channels, stride, dropout_prob):
        super(BasicBlock1, self).__init__()
        # Construct delay path
        self.delay_path = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=(3,3), stride=(stride,stride), padding=(1,1), bias=False),
            nn.ReLU(),
            nn.Dropout(p=dropout_prob),
            nn.Conv2d(out_channels, out_channels, kernel_size=(3,3), stride=(1,1), padding=(1,1), bias=False)
        )
        # Construt residue path
        self.residual_path = Identity()
        self.relu = nn.ReLU(inplace=True)
    def forward(self, inp):
        # Output of basic block is sum of value from residue path and delay path
        outp = self.delay_path(inp)
        outp += self.residual_path(inp)
        outp = self.relu(outp)
        return outp

class BasicBlock0(nn.Module):
    def __init__(self, in_channels, out_channels, stride, dropout_prob):
        super(BasicBlock0, self).__init__()
        # Construct delay path
        self.delay_path = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=(3,3), stride=(stride,stride), padding=(1,1), bias=False),
            nn.ReLU(),
            nn.Dropout(p=dropout_prob),
            nn.Conv2d(out_channels, out_channels, kernel_size=(3,3), stride=(1,1), padding=(1,1), bias=False)
        )
        # Construt residue path
        self.residual_path = nn.AvgPool2d(kernel_size=(1,1), stride=(stride,stride), padding=(0,0))
        self.relu = nn.ReLU(inplace=True)
        self.pad_channels = out_channels - in_channels
    def forward(self, inp):
        # Output of basic block is sum of value from residue path and delay path
        outp = self.delay_path(inp)
        outp_res = self.delay_path(inp)
        outp += torch.cat((self.residual_path(inp),torch.zeros(inp.size(0), self.pad_channels, outp.size(2), outp.size(3)).cuda()), 1)
        outp = self.relu(outp)
        return outp

# Make basic block in specially for spiking ResNet
#   forward path of ResNet will be automatically generated with script in __main__ 
def make_basic_block(is_spike, in_channels, out_channels, stride, dropout_prob):
    if is_spike:
        delay_path = [nn.Conv2d(in_channels, out_channels, kernel_size=(3,3), stride=(stride,stride), padding=(1,1), bias=False),
                      IFNeuron(inplace=True),
                      nn.Dropout(p=dropout_prob),
                      nn.Conv2d(out_channels, out_channels, kernel_size=(3,3), stride=(1,1), padding=(1,1), bias=False)]
        if in_channels == out_channels:
            residual_path = [Identity()]
            return [ResidueMark()] + delay_path + [DelayMark()] + residual_path + [MergeMark1()] + [IFNeuron(inplace=True)]
        else:
            residual_path = [nn.AvgPool2d(kernel_size=(1,1), stride=(stride,stride), padding=(0,0))]
            return [ResidueMark()] + delay_path + [DelayMark()] + residual_path + [MergeMark0()] + [IFNeuron(inplace=True)]
    else:
        if in_channels == out_channels:
            return [BasicBlock1(in_channels, out_channels, stride, dropout_prob)]
        else:
            return [BasicBlock0(in_channels, out_channels, stride, dropout_prob)]

# Function to create convolutional layer
#   When is_spike=False, this function creates convolutional layer for rate-based ResNet
#   When is_spike=True, this function creates convolutional layer for spiking ResNet
def make_features(is_spike, is_temp, dropout_prob_list):
    list_m = []
    in_channels = 3
    if is_spike:
        if is_temp:
            list_m.append(TemporalGen())
        else:
            list_m.append(PoissonGen())
        act_func = IFNeuron
    else:
        act_func = nn.ReLU

    list_m += [nn.Conv2d(in_channels, 128, kernel_size=(3,3), stride=(1,1), padding=(1,1), bias=False)]
    list_m += [act_func(inplace=True)]
    list_m += [nn.Dropout(p=dropout_prob_list[0])]
    list_m += [nn.Conv2d(128, 128, kernel_size=(3,3), stride=(1,1), padding=(1,1), bias=False)]
    list_m += [act_func(inplace=True)]
    list_m += [nn.Dropout(p=dropout_prob_list[1])]
    list_m += [nn.Conv2d(128, 128, kernel_size=(3,3), stride=(1,1), padding=(1,1), bias=False)]
    list_m += [act_func(inplace=True)]
    list_m += [nn.Dropout(p=dropout_prob_list[2])]
    in_channels = 128

    for out_channels,strides in zip([128, 256, 512],[1, 2, 2]):
        strides = [strides] + [1]*2
        for j,stride in zip(range(3),strides):
            list_m.extend(make_basic_block(is_spike, in_channels, out_channels, stride, dropout_prob_list[3]))
            in_channels = out_channels
    list_m += [nn.AvgPool2d(kernel_size=(8,8), stride=(1,1))]
    return make_hierarchy(list_m,is_spike)

# Make fully connected layer 
#   When is_spike=False, this function creates fully-connected layer for rate-based ResNet network
#   When is_spike=True, this function creates fully-connected layer for spiking ResNet network 
def make_classifier(is_spike):
    list_m = []
    list_m += [nn.Linear(512, 100, bias=False)]
    return make_hierarchy(list_m,is_spike)

# Convert list of modules into torch.nn.ModuleList or torch.nn.Sequentual
#   For spiking simulation, we prefer modules to be stacked in torch.nn.ModuleList because output of modules are accessed at multiple points
#   During threshold balancing, we, for example, need to get maximum input to a particular IFNeuron. Having module in torch.nn.Sequential does allow us to access intermediate values easily 
def make_hierarchy(list_m,is_spike):
    if is_spike:
        return nn.ModuleList(list_m)
    else:
        return nn.Sequential(*list_m)

# Spiking version of simple network
class ResNetSpike(nn.Module):
    def __init__(self, dt=0.001, t_end=2.000, in_coding='temp', snn_mode='snn', if_mode='if', TTS=256, fpi=128, dropout_prob_list=[0.1,0.1,0.1,0.1]):
        super(ResNetSpike, self).__init__()
        # Save network parameters
        self.dt = dt
        self.t_end = t_end
        self.TTS = TTS
        self.fpi = fpi
        self.in_coding = in_coding
        self.snn_mode = snn_mode
        self.if_mode = if_mode

        if self.snn_mode == 'vthc':
            self.en_IN = False
            self.en_IF = True
            
        elif self.snn_mode == 'snn':
            self.en_IN = True
            self.en_IF = True

        if self.if_mode == 'residual':
            self.is_residual = True
        elif self.if_mode == 'if':
            self.is_residual = False

        if self.in_coding == 'temp':
            is_temp = True
        elif self.in_coding == 'rate':
            is_temp = False

        # Instantiate layers
        self.features = make_features(is_spike=True, is_temp=is_temp, dropout_prob_list=dropout_prob_list)
        self.classifier = make_classifier(is_spike=True)
    def forward(self, inp):
        # Code in this forward function is automatically generated by running this script
        #   $ python model_resnet20_cifar10.py
        # XX_mem_potential stores membrane potential of IFNeuron at layer XX
        # XX_max_inp stores maximum input to IFNeuon at layer XX 
        outp_sum = torch.zeros(inp.size(0),100).cuda()

        l2_mem_potential = torch.zeros(inp.size(0),128,32,32).cuda()
        l2_max_inp = torch.zeros(inp.size(0),1).cuda()
        l5_mem_potential = torch.zeros(inp.size(0),128,32,32).cuda()
        l5_max_inp = torch.zeros(inp.size(0),1).cuda()
        l8_mem_potential = torch.zeros(inp.size(0),128,32,32).cuda()
        l8_max_inp = torch.zeros(inp.size(0),1).cuda()

        l12_mem_potential = torch.zeros(inp.size(0),128,32,32).cuda()
        l18_mem_potential = torch.zeros(inp.size(0),128,32,32).cuda()
        l21_mem_potential = torch.zeros(inp.size(0),128,32,32).cuda()
        l27_mem_potential = torch.zeros(inp.size(0),128,32,32).cuda()
        l30_mem_potential = torch.zeros(inp.size(0),128,32,32).cuda()
        l36_mem_potential = torch.zeros(inp.size(0),128,32,32).cuda()
        l39_mem_potential = torch.zeros(inp.size(0),256,16,16).cuda()
        l45_mem_potential = torch.zeros(inp.size(0),256,16,16).cuda()
        l48_mem_potential = torch.zeros(inp.size(0),256,16,16).cuda()
        l54_mem_potential = torch.zeros(inp.size(0),256,16,16).cuda()
        l57_mem_potential = torch.zeros(inp.size(0),256,16,16).cuda()
        l63_mem_potential = torch.zeros(inp.size(0),256,16,16).cuda()
        l66_mem_potential = torch.zeros(inp.size(0),512,8,8).cuda()
        l72_mem_potential = torch.zeros(inp.size(0),512,8,8).cuda()
        l75_mem_potential = torch.zeros(inp.size(0),512,8,8).cuda()
        l81_mem_potential = torch.zeros(inp.size(0),512,8,8).cuda()
        l84_mem_potential = torch.zeros(inp.size(0),512,8,8).cuda()
        l90_mem_potential = torch.zeros(inp.size(0),512,8,8).cuda()

        spike_count = torch.zeros(100,1).cuda()
        # Simulating spiking network over time inside the module, thus allow simulation to be parallelized across GPUs when torch.nn.DataParallel is wrapped around
        
        count = torch.zeros(1).cuda()
        for ts in range(self.TTS+1):
            
            if torch.fmod(count, self.fpi+1, out=None) == 0: 
                
                if self.snn_mode == 'vthc':
                    if self.en_IF == True:
                        self.en_IF = False
                    elif self.en_IF == False:
                        self.en_IF = True

                    if self.en_IN == True:
                        self.en_IN = False
                    elif self.en_IN == False:
                        self.en_IN = True
                
            count = count + 1

            # print('timestep ', ts, 'en_IN = ', self.en_IN, 'en_IF = ', self.en_IF, 'fpi = ', self.fpi) 
            outp = self.features[1](self.features[0](inp, count, self.fpi,self.en_IN))
            l2_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l2_max_inp)
            outp,l2_mem_potential = self.features[2](outp,l2_mem_potential, self.en_IF, self.is_residual)
            # print('timestep', ts, 'l2_mem_potential', l2_mem_potential.shape, torch.max(l2_mem_potential), torch.min(l2_mem_potential))
            spike_count[2] += torch.sum(outp) 
            outp = self.features[4](self.features[3](outp))

            l5_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l5_max_inp)
            outp,l5_mem_potential = self.features[5](outp,l5_mem_potential, self.en_IF, self.is_residual)
            # print('timestep', ts, 'l5_mem_potential', l5_mem_potential.shape, torch.max(l5_mem_potential), torch.min(l5_mem_potential))
            spike_count[5] += torch.sum(outp)
            outp = self.features[7](self.features[6](outp))
            
            l8_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l8_max_inp)
            outp,l8_mem_potential = self.features[8](outp,l8_mem_potential, self.en_IF, self.is_residual)
            # print('timestep', ts, 'l8_mem_potential', l8_mem_potential.shape, torch.max(l8_mem_potential), torch.min(l8_mem_potential))
            spike_count[8] += torch.sum(outp)
            outp = self.features[9](outp)


            outp_r = self.features[11](outp)   # <-------
            outp_r,l12_mem_potential = self.features[12](outp_r,l12_mem_potential, self.en_IF, self.is_residual)
            # print('timestep', ts, 'l12_mem_potential', l12_mem_potential.shape, torch.max(l12_mem_potential), torch.min(l12_mem_potential))
            spike_count[12] += torch.sum(outp_r)
            # print('timestep', ts, 'outp_r: spiking layer l16,  max = ', outp_r.max(), '  min = ', outp_r.min())
            outp_r = self.features[14](self.features[13](outp_r))
            outp_d = self.features[16](outp)   # <-------
            # print('timestep', ts, 'outp_d: spiking layer l16,  max = ', outp_d.max(), '  min = ', outp_d.min())
            outp = torch.add(outp_d, outp_r)   # ------->
            # print('timestep', ts, 'outp: spiking layer l16,  max = ', outp.max(), '  min = ', outp.min())
            outp,l18_mem_potential = self.features[18](outp,l18_mem_potential, self.en_IF, self.is_residual)
            # print('timestep', ts, 'l18_mem_potential', l18_mem_potential.shape, torch.max(l18_mem_potential), torch.min(l18_mem_potential))
            spike_count[18] += torch.sum(outp)


            outp_r = self.features[20](outp)  # <-------
            outp_r,l21_mem_potential = self.features[21](outp_r,l21_mem_potential, self.en_IF, self.is_residual)
            # print('timestep', ts, 'l21_mem_potential', l21_mem_potential.shape, torch.max(l21_mem_potential), torch.min(l21_mem_potential))
            spike_count[21] += torch.sum(outp_r)
            outp_r = self.features[23](self.features[22](outp_r))
            outp_d = self.features[25](outp)  # <-------
            outp = torch.add(outp_d, outp_r)  # ------->
            outp,l27_mem_potential = self.features[27](outp,l27_mem_potential, self.en_IF, self.is_residual)
            # print('timestep', ts, 'l27_mem_potential', l27_mem_potential.shape, torch.max(l27_mem_potential), torch.min(l27_mem_potential))
            spike_count[27] += torch.sum(outp)


            outp_r = self.features[29](outp)  # <-------
            outp_r,l30_mem_potential = self.features[30](outp_r,l30_mem_potential, self.en_IF, self.is_residual)
            # print('timestep', ts, 'l30_mem_potential', l30_mem_potential.shape, torch.max(l30_mem_potential), torch.min(l30_mem_potential))
            spike_count[30] += torch.sum(outp_r)
            outp_r = self.features[32](self.features[31](outp_r))
            outp_d = self.features[34](outp)  # <-------
            outp = torch.add(outp_d, outp_r)  # ------->
            outp,l36_mem_potential = self.features[36](outp,l36_mem_potential, self.en_IF, self.is_residual)
            # print('timestep', ts, 'l36_mem_potential', l36_mem_potential.shape, torch.max(l36_mem_potential), torch.min(l36_mem_potential))
            spike_count[36] += torch.sum(outp)


            outp_r = self.features[38](outp)
            outp_r,l39_mem_potential = self.features[39](outp_r,l39_mem_potential, self.en_IF, self.is_residual)
            # print('timestep', ts, 'l39_mem_potential', l39_mem_potential.shape, torch.max(l39_mem_potential), torch.min(l39_mem_potential))
            spike_count[39] += torch.sum(outp_r)
            outp_r = self.features[41](self.features[40](outp_r))
            outp_d = torch.cat((self.features[43](outp),torch.zeros(outp_r.size(0),128,outp_r.size(2),outp_r.size(3)).cuda()),1)
            outp = torch.add(outp_d, outp_r)
            outp,l45_mem_potential = self.features[45](outp,l45_mem_potential, self.en_IF, self.is_residual)
            # print('timestep', ts, 'l45_mem_potential', l45_mem_potential.shape, torch.max(l45_mem_potential), torch.min(l45_mem_potential))
            spike_count[45] += torch.sum(outp)


            outp_r = self.features[47](outp)
            outp_r,l48_mem_potential = self.features[48](outp_r,l48_mem_potential, self.en_IF, self.is_residual)
            # print('timestep', ts, 'l48_mem_potential', l48_mem_potential.shape, torch.max(l48_mem_potential), torch.min(l48_mem_potential))
            spike_count[48] += torch.sum(outp_r)
            outp_r = self.features[50](self.features[49](outp_r))
            outp_d = self.features[52](outp)
            outp = torch.add(outp_d, outp_r)
            outp,l54_mem_potential = self.features[54](outp,l54_mem_potential, self.en_IF, self.is_residual)
            # print('timestep', ts, 'l54_mem_potential', l54_mem_potential.shape, torch.max(l54_mem_potential), torch.min(l54_mem_potential))
            spike_count[54] += torch.sum(outp)


            outp_r = self.features[56](outp)
            outp_r,l57_mem_potential = self.features[57](outp_r,l57_mem_potential, self.en_IF, self.is_residual)
            # print('timestep', ts, 'l57_mem_potential', l57_mem_potential.shape, torch.max(l57_mem_potential), torch.min(l57_mem_potential))
            spike_count[57] += torch.sum(outp_r)
            outp_r = self.features[59](self.features[58](outp_r))
            outp_d = self.features[61](outp)
            outp = torch.add(outp_d, outp_r)
            outp,l63_mem_potential = self.features[63](outp,l63_mem_potential, self.en_IF, self.is_residual)
            # print('timestep', ts, 'l63_mem_potential', l63_mem_potential.shape, torch.max(l63_mem_potential), torch.min(l63_mem_potential))
            spike_count[63] += torch.sum(outp)


            outp_r = self.features[65](outp)
            outp_r,l66_mem_potential = self.features[66](outp_r,l66_mem_potential, self.en_IF, self.is_residual)
            # print('timestep', ts, 'l66_mem_potential', l66_mem_potential.shape, torch.max(l66_mem_potential), torch.min(l66_mem_potential))
            spike_count[66] += torch.sum(outp_r)
            outp_r = self.features[68](self.features[67](outp_r))
            outp_d = torch.cat((self.features[70](outp),torch.zeros(outp_r.size(0),256,outp_r.size(2),outp_r.size(3)).cuda()),1)
            outp = torch.add(outp_d, outp_r)
            outp,l72_mem_potential = self.features[72](outp,l72_mem_potential, self.en_IF, self.is_residual)
            # print('timestep', ts, 'l72_mem_potential', l72_mem_potential.shape, torch.max(l72_mem_potential), torch.min(l72_mem_potential))
            spike_count[72] += torch.sum(outp)


            outp_r = self.features[74](outp)
            outp_r,l75_mem_potential = self.features[75](outp_r,l75_mem_potential, self.en_IF, self.is_residual)
            # print('timestep', ts, 'l75_mem_potential', l75_mem_potential.shape, torch.max(l75_mem_potential), torch.min(l75_mem_potential))
            spike_count[75] += torch.sum(outp_r)
            outp_r = self.features[77](self.features[76](outp_r))
            outp_d = self.features[79](outp)
            outp = torch.add(outp_d, outp_r)
            outp,l81_mem_potential = self.features[81](outp,l81_mem_potential, self.en_IF, self.is_residual)
            # print('timestep', ts, 'l81_mem_potential', l81_mem_potential.shape, torch.max(l81_mem_potential), torch.min(l81_mem_potential))
            spike_count[81] += torch.sum(outp)


            outp_r = self.features[83](outp)
            outp_r,l84_mem_potential = self.features[84](outp_r,l84_mem_potential, self.en_IF, self.is_residual)
            # print('timestep', ts, 'l84_mem_potential', l84_mem_potential.shape, torch.max(l84_mem_potential), torch.min(l84_mem_potential))
            spike_count[84] += torch.sum(outp_r)
            outp_r = self.features[86](self.features[85](outp_r))
            outp_d = self.features[88](outp)
            outp = torch.add(outp_d, outp_r)
            outp,l90_mem_potential = self.features[90](outp,l90_mem_potential, self.en_IF, self.is_residual)
            # print('timestep', ts, 'l90_mem_potential', l90_mem_potential.shape, torch.max(l90_mem_potential), torch.min(l90_mem_potential))
            spike_count[90] += torch.sum(outp)


            outp = self.features[91](outp)
            outp = outp.view(outp.size(0), -1)
            outp = self.classifier[0](outp)
            outp_sum += outp
        return outp_sum, l2_max_inp,l5_max_inp,l8_max_inp, spike_count
    

# Rate version of simple network
class ResNetRate(nn.Module):
    def __init__(self, dropout_prob_list=[0.1,0.1,0.1,0.1]):
        super(ResNetRate, self).__init__()
        # Instantiate layers
        self.features = make_features(is_spike=False, is_temp=False, dropout_prob_list=dropout_prob_list)
        self.classifier = make_classifier(is_spike=False)
        print('Dropout Probability: {}'.format(dropout_prob_list))
        # Initialize weights in the MSR style (http://arxiv.org/pdf/1502.01852v1.pdf) which is more suitable for deep network than Xavier initialization (default initialization of convolutional layer in PyTorch)
        self.initialize_weights()
    def forward(self, inp):
        # outp = self.features(inp)
        # outp = outp.view(outp.size(0), -1)
        # outp = self.classifier(outp)
       	l1_max_outp = torch.zeros(inp.size(0),1).cuda()
        l4_max_outp = torch.zeros(inp.size(0),1).cuda()
        l7_max_outp = torch.zeros(inp.size(0),1).cuda()
        l11_max_outp = torch.zeros(inp.size(0),1).cuda()
        l14_max_outp = torch.zeros(inp.size(0),1).cuda()
        l20_max_outp = torch.zeros(inp.size(0),1).cuda()
        l23_max_outp = torch.zeros(inp.size(0),1).cuda()
        l29_max_outp = torch.zeros(inp.size(0),1).cuda()
        l32_max_outp = torch.zeros(inp.size(0),1).cuda()
        l38_max_outp = torch.zeros(inp.size(0),1).cuda()
        l41_max_outp = torch.zeros(inp.size(0),1).cuda()
        l47_max_outp = torch.zeros(inp.size(0),1).cuda()
        l50_max_outp = torch.zeros(inp.size(0),1).cuda()
        l56_max_outp = torch.zeros(inp.size(0),1).cuda()
        l59_max_outp = torch.zeros(inp.size(0),1).cuda()
        l65_max_outp = torch.zeros(inp.size(0),1).cuda()
        l68_max_outp = torch.zeros(inp.size(0),1).cuda()
        l74_max_outp = torch.zeros(inp.size(0),1).cuda()
        l77_max_outp = torch.zeros(inp.size(0),1).cuda()
        l83_max_outp = torch.zeros(inp.size(0),1).cuda()
        l86_max_outp = torch.zeros(inp.size(0),1).cuda()
        
        outp = self.features[0](inp)
        outp = self.features[1](outp)
        l1_max_outp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l1_max_outp)
        outp = self.features[2](outp)

        outp = self.features[3](outp)
        outp = self.features[4](outp)
        l4_max_outp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l4_max_outp)
        outp = self.features[5](outp)

        outp = self.features[6](outp)
        outp = self.features[7](outp)
        l7_max_outp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l7_max_outp)
        outp = self.features[8](outp)

        outp_r = self.features[9].delay_path[0](outp)   # <-------
        l11_max_outp = torch.max(torch.max(outp_r.view(outp_r.size(0),-1), keepdim=True, dim=1)[0],l11_max_outp)
        outp_r = self.features[9].delay_path[1](outp_r)
        outp_r = self.features[9].delay_path[2](outp_r)
        outp_r = self.features[9].delay_path[3](outp_r)
        outp_d = self.features[9].residual_path(outp)   # <-------
        outp = torch.add(outp_d, outp_r)                # ------->
        l14_max_outp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l14_max_outp)
        outp = self.features[9].relu(outp)

        outp_r = self.features[10].delay_path[0](outp)   # <-------
        l20_max_outp = torch.max(torch.max(outp_r.view(outp_r.size(0),-1), keepdim=True, dim=1)[0],l20_max_outp)
        outp_r = self.features[10].delay_path[1](outp_r)
        outp_r = self.features[10].delay_path[2](outp_r)
        outp_r = self.features[10].delay_path[3](outp_r)
        outp_d = self.features[10].residual_path(outp)   # <-------
        outp = torch.add(outp_d, outp_r)                # ------->
        l23_max_outp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l23_max_outp)
        outp = self.features[10].relu(outp)

        outp_r = self.features[11].delay_path[0](outp)   # <-------
        l29_max_outp = torch.max(torch.max(outp_r.view(outp_r.size(0),-1), keepdim=True, dim=1)[0],l29_max_outp)
        outp_r = self.features[11].delay_path[1](outp_r)
        outp_r = self.features[11].delay_path[2](outp_r)
        outp_r = self.features[11].delay_path[3](outp_r)
        outp_d = self.features[11].residual_path(outp)   # <-------
        outp = torch.add(outp_d, outp_r)                # ------->
        l32_max_outp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l32_max_outp)
        outp = self.features[11].relu(outp)

        outp_r = self.features[12].delay_path[0](outp)   # <-------
        l38_max_outp = torch.max(torch.max(outp_r.view(outp_r.size(0),-1), keepdim=True, dim=1)[0],l38_max_outp)
        outp_r = self.features[12].delay_path[1](outp_r)
        outp_r = self.features[12].delay_path[2](outp_r)
        outp_r = self.features[12].delay_path[3](outp_r)
        outp_d = self.features[12].residual_path(outp)   # <-------
        outp_d = torch.cat((outp_d,torch.zeros(outp_r.size(0),32,outp_r.size(2),outp_r.size(3)).cuda()),1)
        outp = torch.add(outp_d, outp_r)                # ------->
        l41_max_outp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l41_max_outp)
        outp = self.features[12].relu(outp)

        outp_r = self.features[13].delay_path[0](outp)   # <-------    
        l47_max_outp = torch.max(torch.max(outp_r.view(outp_r.size(0),-1), keepdim=True, dim=1)[0],l47_max_outp)
        outp_r = self.features[13].delay_path[1](outp_r)
        outp_r = self.features[13].delay_path[2](outp_r)
        outp_r = self.features[13].delay_path[3](outp_r)
        outp_d = self.features[13].residual_path(outp)   # <-------
        outp = torch.add(outp_d, outp_r)                # ------->
        l50_max_outp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l50_max_outp)
        outp = self.features[13].relu(outp)

        outp_r = self.features[14].delay_path[0](outp)   # <-------
        l56_max_outp = torch.max(torch.max(outp_r.view(outp_r.size(0),-1), keepdim=True, dim=1)[0],l59_max_outp)
        outp_r = self.features[14].delay_path[1](outp_r)
        outp_r = self.features[14].delay_path[2](outp_r)
        outp_r = self.features[14].delay_path[3](outp_r)
        outp_d = self.features[14].residual_path(outp)   # <-------
        outp = torch.add(outp_d, outp_r)                # ------->
        l59_max_outp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l59_max_outp)
        outp = self.features[14].relu(outp)

        outp_r = self.features[15].delay_path[0](outp)   # <-------
        l65_max_outp = torch.max(torch.max(outp_r.view(outp_r.size(0),-1), keepdim=True, dim=1)[0],l65_max_outp)
        outp_r = self.features[15].delay_path[1](outp_r)
        outp_r = self.features[15].delay_path[2](outp_r)
        outp_r = self.features[15].delay_path[3](outp_r)
        outp_d = self.features[15].residual_path(outp)   # <-------
        outp_d = torch.cat((outp_d,torch.zeros(outp_r.size(0),64,outp_r.size(2),outp_r.size(3)).cuda()),1)
        outp = torch.add(outp_d, outp_r)                # ------->
        l68_max_outp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l68_max_outp)    
        outp = self.features[15].relu(outp)

        outp_r = self.features[16].delay_path[0](outp)   # <-------
        l74_max_outp = torch.max(torch.max(outp_r.view(outp_r.size(0),-1), keepdim=True, dim=1)[0],l74_max_outp)
        outp_r = self.features[16].delay_path[1](outp_r)
        outp_r = self.features[16].delay_path[2](outp_r)
        outp_r = self.features[16].delay_path[3](outp_r)
        outp_d = self.features[16].residual_path(outp)   # <-------
        outp = torch.add(outp_d, outp_r)                # ------->
        l77_max_outp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l77_max_outp)
        outp = self.features[16].relu(outp)

        outp_r = self.features[17].delay_path[0](outp)   # <-------
        l83_max_outp = torch.max(torch.max(outp_r.view(outp_r.size(0),-1), keepdim=True, dim=1)[0],l83_max_outp)
        outp_r = self.features[17].delay_path[1](outp_r)
        outp_r = self.features[17].delay_path[2](outp_r)
        outp_r = self.features[17].delay_path[3](outp_r)
        outp_d = self.features[17].residual_path(outp)   # <-------
        outp = torch.add(outp_d, outp_r)                # ------->
        l86_max_outp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l86_max_outp)
        outp = self.features[17].relu(outp)

        outp = self.features[18](outp)
        outp = outp.view(outp.size(0), -1)
        outp = self.classifier(outp) 
        return outp,l1_max_outp,l4_max_outp,l7_max_outp,l11_max_outp,l14_max_outp,l20_max_outp,l23_max_outp,l29_max_outp,l32_max_outp,l38_max_outp,l41_max_outp,l47_max_outp,l50_max_outp,l56_max_outp,l59_max_outp,l65_max_outp,l68_max_outp,l74_max_outp,l77_max_outp,l83_max_outp,l86_max_outp


    def initialize_weights(self):
        # Initialize all convolutional layers
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                m.weight.data.normal_(0, math.sqrt(2./n))
                if m.bias is not None:
                    m.bias.data.zero_()
        # Reinitialize convolutional residual layer 
        for m in self.modules():
            if isinstance(m, BasicBlock0) or isinstance(m, BasicBlock1):
                for sm in m.modules():
                    if isinstance(sm, nn.Conv2d):
                        n = sm.kernel_size[0] * sm.kernel_size[1] * sm.out_channels
                        sm.weight.data.normal_(0, math.sqrt(2.)/float(n))
                        if sm.bias is not None:
                            sm.bias.data.zero_()

if __name__ == '__main__':

    # Test rate model with random input (batchsize of 4)
    inp = torch.rand(4,3,32,32) 
    print('-'*40)
    # Instantiate rate-baed ResNet model and parallelize model across GPUs, but only for convolutional layers (check this out https://arxiv.org/pdf/1404.5997.pdf)
    model_rate = ResNetRate()
    model_rate = torch.nn.DataParallel(model_rate).cuda()
    # Print model
    print(model_rate)
    # Compute output
    # outp = model_rate(inp)
    # print('Test successful!')
    # input('...')
    
    # Test spiking model with random input (batchsize of 4)
    print('-'*40)
    # Instantiate spiking ResNet model and parallel model across multiple GPUs
    model_spike = ResNetSpike()
    model_spike = torch.nn.DataParallel(model_spike).cuda()
    # Print model
    print(model_spike)
    # Compute output
    model_spike.eval()
    # with torch.no_grad():
    #     outp = model_spike(inp)
    # print('Test successful!')
    # Automatically generate weight mapping list and forward statement
    print('-'*40)
    # After training rate-based model, weight of convolutional layers in the rate-based model is copied to that in the spiking model
    print(len(list(model_rate.state_dict().keys())))
    print(len(list(model_spike.state_dict().keys())))
    print(list(zip(list(model_rate.state_dict().keys()),list(model_spike.state_dict().keys()))))
    # Forward statement for spiking model
    print()
    print('    for j in range(int(self.t_end/self.dt)):')
    inp_dim = 3
    inp_size = 32
    pad_dim = None
    outstr = 'inp'
    initstr1 = '    outp_sum = torch.zeros(inp.size(0),10).cuda()\n'
    initstr2 = ''
    returnstr = '    return outp_sum'
    set1str = '    outp'
    set2str = []
    conv_count = 0
    delay_path = False
    residue_path = False
    # Forward statement for convolutional layers
    for i,m in enumerate(model_spike.module.features):
        if isinstance(m,PoissonGen):
            outstr = 'self.features[{}]({})'.format(i,outstr)
        elif isinstance(m,ResidueMark):
            if outstr != 'outp':
                print('        outp = {}'.format(outstr))
                outstr = 'outp'
            residue_path = True
            rpathstr = 'outp'
        elif isinstance(m,DelayMark):
            residue_path = False
            delay_path = True
            dpathstr = 'outp'
        elif isinstance(m,MergeMark1):
            delay_path = False
            print('        outp_r = {}'.format(rpathstr))
            print('        outp_d = {}'.format(dpathstr))
            print('        outp = torch.add(outp_d, outp_r)')
        elif isinstance(m,MergeMark0):
            delay_path = False
            print('        outp_r = {}'.format(rpathstr))
            print('        outp_d = torch.cat(({},torch.zeros(outp_r.size(0),{},outp_r.size(2),outp_r.size(3)).cuda()),1)'.format(dpathstr,pad_dim))
            print('        outp = torch.add(outp_d, outp_r)')
        elif isinstance(m,nn.Conv2d):
            if residue_path:
                if int(m.in_channels) != int(m.out_channels):
                    pad_dim = int(m.out_channels) - int(m.in_channels)
                inp_dim = int(m.out_channels)
                inp_size = math.floor((inp_size-m.kernel_size[0]+2*m.padding[0])/m.stride[0])+1
                rpathstr = 'self.features[{}]({})'.format(i,rpathstr)
            else:
                inp_dim = int(m.out_channels)
                inp_size = math.floor((inp_size-m.kernel_size[0]+2*m.padding[0])/m.stride[0])+1
                outstr = 'self.features[{}]({})'.format(i,outstr)
        elif isinstance(m,Identity):
            dpathstr = 'self.features[{}]({})'.format(i,dpathstr)
        elif isinstance(m,nn.Dropout):
            if residue_path: 
                rpathstr = 'self.features[{}]({})'.format(i,rpathstr)
            else: 
                outstr = 'self.features[{}]({})'.format(i,outstr)
        elif isinstance(m,nn.AvgPool2d):
            if delay_path: 
                dpathstr = 'self.features[{}]({})'.format(i,dpathstr)
            else:
                outstr = 'self.features[{}]({})'.format(i,outstr)
                inp_size = int((inp_size-m.kernel_size[0])/m.stride[0]+1)
        elif isinstance(m,IFNeuron):
            if residue_path: 
                # rpathstr = 'self.features[{}]({})'.format(i,rpathstr)
                print('        outp_r = {}'.format(rpathstr))
                rpathstr = 'outp_r'
                print('        outp_r,l{}_mem_potential = self.features[{}](outp_r,l{}_mem_potential)'.format(i,i,i))
                initstr1 += '    l{}_mem_potential = torch.zeros(inp.size(0),{},{},{}).cuda()\n'.format(i,inp_dim,inp_size,inp_size)
            else:
                if outstr != 'outp':
                    print('        outp = {}'.format(outstr))
                    outstr = 'outp'
                if conv_count < 3:
                    print('        l{}_max_inp = torch.max(torch.max(outp.view(outp.size(0),-1), keepdim=True, dim=1)[0],l{}_max_inp)'.format(i,i))
                    print('        outp,l{}_mem_potential = self.features[{}](outp,l{}_mem_potential)'.format(i,i,i))
                    initstr1 += '    l{}_mem_potential = torch.zeros(inp.size(0),{},{},{}).cuda()\n'.format(i,inp_dim,inp_size,inp_size)
                    initstr1 += '    l{}_max_inp = torch.zeros(inp.size(0),1).cuda()\n'.format(i)
                    initstr2 += '    l{}_max_inp_ = torch.zeros(1).cuda()\n'.format(i)
                    returnstr += ',l{}_max_inp'.format(i) 
                    set1str += ',l{}_max_inp'.format(i) 
                    # set2str.append('model_spike.module.features[{}].set_thres(float(torch.max(l{}_max_inp)))\n'.format(i,i))
                    set2str.append('    l{}_max_inp_ = torch.max(l{}_max_inp_,torch.max(l{}_max_inp))\nmodel_spike.module.features[{}].set_thres(float(l{}_max_inp_))\n'.format(i,i,i,i,i))
                    conv_count += 1
                else:
                    print('        outp,l{}_mem_potential = self.features[{}](outp,l{}_mem_potential)'.format(i,i,i))
                    initstr1 += '    l{}_mem_potential = torch.zeros(inp.size(0),{},{},{}).cuda()\n'.format(i,inp_dim,inp_size,inp_size)

        else: 
            assert False, 'Unrecognized module {}'.format(m)
    print('        outp = {}'.format(outstr))
    # Forward statement for reshaping
    outstr = 'outp'
    print('        outp = outp.view(outp.size(0), -1)')
    inp_dim = (inp_dim * inp_size * inp_size)
    # Forward statement for fully connected-layer
    for i,m in enumerate(model_spike.module.classifier):
        if isinstance(m,nn.Linear):
            outstr = 'self.classifier[{}]({})'.format(i,outstr)
        else: 
            assert False, 'Unrecognized module {}'.format(m)
    print('        outp = {}'.format(outstr))
    print('        outp_sum += outp')
    print()
    print(returnstr)
    # Print initialization statement
    print(initstr1)
    print()
    print(initstr2)
    set1str += ' = model_spike(inp)'
    for each in set2str:
        print(set1str)
        print(each)
